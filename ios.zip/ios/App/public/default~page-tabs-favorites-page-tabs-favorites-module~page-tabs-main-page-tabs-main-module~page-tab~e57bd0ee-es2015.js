(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee"],{

/***/ "7mVc":
/*!************************************************************!*\
  !*** ./src/app/@core/services/recognition-info.service.ts ***!
  \************************************************************/
/*! exports provided: RecognitionInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecognitionInfoService", function() { return RecognitionInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _user_info_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-info.service */ "tTdR");
/* harmony import */ var _api_api_recognition_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api/api-recognition.service */ "p0lb");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");





let RecognitionInfoService = class RecognitionInfoService {
    constructor(userInfoService, apiRecognitionService) {
        this.userInfoService = userInfoService;
        this.apiRecognitionService = apiRecognitionService;
        this.recommendCards$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]([null, null, null]);
    }
    textResultMapper(result) {
        var _a;
        return {
            scoreId: result === null || result === void 0 ? void 0 : result.id,
            previews: (_a = result === null || result === void 0 ? void 0 : result.searchResults) !== null && _a !== void 0 ? _a : [],
        };
    }
    getStartReco() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const gender = yield this.userInfoService.getInitialGender();
            return yield this.apiRecognitionService.getStartScreenReco(gender);
        });
    }
    getMainRecommends() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.isMainRecommendsLoaded()) {
                return;
            }
            const res = yield this.apiRecognitionService.getMainRecommends();
            this.recommendCards$.next(res);
        });
    }
    isMainRecommendsLoaded() {
        return !this.recommendCards$.getValue().every(x => x === null);
    }
};
RecognitionInfoService.ctorParameters = () => [
    { type: _user_info_service__WEBPACK_IMPORTED_MODULE_2__["UserInfoService"] },
    { type: _api_api_recognition_service__WEBPACK_IMPORTED_MODULE_3__["ApiRecognitionService"] }
];
RecognitionInfoService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RecognitionInfoService);



/***/ }),

/***/ "8jGz":
/*!**************************************************************!*\
  !*** ./src/app/pages/page-product/page-product.component.ts ***!
  \**************************************************************/
/*! exports provided: PageProductComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageProductComponent", function() { return PageProductComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_product_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-product.component.html */ "FRye");
/* harmony import */ var _page_product_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-product.component.scss */ "gVPk");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../@core/services/api/api-user.service */ "lA1K");
/* harmony import */ var _shared_classes_favorites_class__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../@shared/classes/favorites.class */ "mVaD");
/* harmony import */ var _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../@core/services/platform/mobile-share.service */ "lAEh");










let PageProductComponent = class PageProductComponent {
    constructor(modalCtrl, recognitionInfoService, shareService, apiUserService) {
        this.modalCtrl = modalCtrl;
        this.recognitionInfoService = recognitionInfoService;
        this.shareService = shareService;
        this.data$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](null);
        this.sharedData = this.data$;
        this.favoritesController = new _shared_classes_favorites_class__WEBPACK_IMPORTED_MODULE_8__["FavoritesController"](apiUserService);
    }
    ngOnInit() {
        var _a, _b, _c;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = yield ((_b = (_a = this.recognitionInfoService).recognitionFeedFunction) === null || _b === void 0 ? void 0 : _b.call(_a));
            res.infoList = (_c = res.infoList) !== null && _c !== void 0 ? _c : [];
            this.data$.next(res);
        });
    }
    setFavorite() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const product = this.data$.getValue();
            const isFavorite = yield this.favoritesController.setFavourite(product.id, !product.isFavorite);
            this.data$.next(Object.assign(Object.assign({}, product), { isFavorite }));
        });
    }
    closePage() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.modalCtrl.dismiss();
        });
    }
    shareProduct() {
        const product = this.data$.getValue();
        if (!product) {
            return;
        }
        this.shareService.shareData('Отправленно из приложения LUC', `Посмотри что нашел в LUC в магазине ${product.shopTitle}:`, product.shopUrl);
    }
};
PageProductComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_6__["RecognitionInfoService"] },
    { type: _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_9__["MobileShareService"] },
    { type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_7__["ApiUserService"] }
];
PageProductComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-product',
        template: _raw_loader_page_product_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_product_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageProductComponent);



/***/ }),

/***/ "9jac":
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/page-product/page-product-header/page-product-header.component.scss ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n  padding: 0 2.2vh;\n  box-sizing: border-box;\n}\n.header > * {\n  margin: auto 0;\n}\n.header__brand {\n  text-align: center;\n  font-size: 2.1vh;\n  font-weight: 600;\n  color: #222222;\n}\n.header .icon {\n  width: 2.43vh;\n  height: 2.43vh;\n}\n.header .icon__back {\n  color: #2CB172;\n}\n.header .icon__share {\n  color: #99A0AB;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC1oZWFkZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtBQUNGO0FBQ0U7RUFDRSxjQUFBO0FBQ0o7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFBSjtBQUdFO0VBQ0UsYUFBQTtFQUNBLGNBQUE7QUFESjtBQUdJO0VBQ0UsY0FBQTtBQUROO0FBSUk7RUFDRSxjQUFBO0FBRk4iLCJmaWxlIjoicGFnZS1wcm9kdWN0LWhlYWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICB3aWR0aDogMTAwJTtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBwYWRkaW5nOiAwIDIuMnZoO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuXG4gICYgPiAqIHtcbiAgICBtYXJnaW46IGF1dG8gMDtcbiAgfVxuXG4gICZfX2JyYW5kIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyLjF2aDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiAjMjIyMjIyO1xuICB9XG5cbiAgLmljb24ge1xuICAgIHdpZHRoOiAyLjQzdmg7XG4gICAgaGVpZ2h0OiAyLjQzdmg7XG5cbiAgICAmX19iYWNrIHtcbiAgICAgIGNvbG9yOiAjMkNCMTcyO1xuICAgIH1cblxuICAgICZfX3NoYXJlIHtcbiAgICAgIGNvbG9yOiAjOTlBMEFCOztcbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "A6qN":
/*!***********************************************************!*\
  !*** ./src/app/pages/page-product/page-product.module.ts ***!
  \***********************************************************/
/*! exports provided: PageProductModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageProductModule", function() { return PageProductModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _page_product_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-product.component */ "8jGz");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../@shared/shared.module */ "pk6O");
/* harmony import */ var _page_product_info_page_product_info_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./page-product-info/page-product-info.component */ "PkOX");
/* harmony import */ var _page_product_buttons_page_product_buttons_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./page-product-buttons/page-product-buttons.component */ "VS1G");
/* harmony import */ var _page_product_header_page_product_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./page-product-header/page-product-header.component */ "u7xx");
/* harmony import */ var _page_product_price_page_product_price_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./page-product-price/page-product-price.component */ "bimA");









let PageProductModule = class PageProductModule {
};
PageProductModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _page_product_component__WEBPACK_IMPORTED_MODULE_3__["PageProductComponent"],
            _page_product_info_page_product_info_component__WEBPACK_IMPORTED_MODULE_5__["PageProductInfoComponent"],
            _page_product_buttons_page_product_buttons_component__WEBPACK_IMPORTED_MODULE_6__["PageProductButtonsComponent"],
            _page_product_header_page_product_header_component__WEBPACK_IMPORTED_MODULE_7__["PageProductHeaderComponent"],
            _page_product_price_page_product_price_component__WEBPACK_IMPORTED_MODULE_8__["PageProductPriceComponent"]
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
        ]
    })
], PageProductModule);



/***/ }),

/***/ "FRye":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <app-page-product-header\n    [label]=\"(sharedData | async)?.shopTitle\"\n    (back)=\"closePage()\"\n    (share)=\"shareProduct()\"\n  ></app-page-product-header>\n  <div class=\"scroll-wrapper\">\n    <div class=\"img-container\">\n      <img class=\"image\" alt=\"\" [src]=\"(sharedData | async)?.imageUrl\">\n<!--      TODO: add img scroller-->\n    </div>\n    <app-page-product-price [data]=\"(sharedData | async)\" (favouriteClick)=\"setFavorite()\"></app-page-product-price>\n    <app-page-product-buttons [modalController]=\"modalCtrl\" [shopUrl]=\"(sharedData | async)?.shopUrl\"></app-page-product-buttons>\n    <app-page-product-info [data]=\"(sharedData | async)?.infoList\"></app-page-product-info>\n  </div>\n</div>\n\n<ng-template #productContainerEmpty>\n  <span class=\"text-empty\"> К сожалению, поиск не дал результатов </span>\n</ng-template>\n");

/***/ }),

/***/ "J1eq":
/*!*********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product-header/page-product-header.component.html ***!
  \*********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header\">\n  <svg-icon (click)=\"backClick()\" class=\"icon icon__back\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n  <span *ngIf=\"label else skeletonProductHeader\" class=\"header__brand flex-free-space\"> {{ label }} </span>\n  <svg-icon (click)=\"shareClick()\" class=\"icon icon__share\" src=\"assets/icon/svg/share.svg\"></svg-icon>\n</div>\n\n<ng-template #skeletonProductHeader>\n  <ion-skeleton-text animated style=\"width:40%; height: 2.1vh\"></ion-skeleton-text>\n</ng-template>\n");

/***/ }),

/***/ "JJls":
/*!***********************************************************!*\
  !*** ./src/app/@shared/functions/base64-file.function.ts ***!
  \***********************************************************/
/*! exports provided: dataURLtoFile, urlToDataUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dataURLtoFile", function() { return dataURLtoFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "urlToDataUrl", function() { return urlToDataUrl; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");

function dataURLtoFile(dataUrl, filename = 'default') {
    const arr = dataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
}
function urlToDataUrl(imageUrl) {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
        const proxy = 'https://api.codetabs.com/v1/proxy?quest=';
        let res;
        try {
            res = yield fetch(imageUrl);
        }
        catch (e) {
            res = yield fetch(proxy + imageUrl);
        }
        const blob = yield res.blob();
        console.log(res);
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                resolve(reader.result);
            };
            reader.readAsDataURL(blob);
        });
    });
}


/***/ }),

/***/ "Oemk":
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/page-product/page-product-buttons/page-product-buttons.component.scss ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  flex-flow: column;\n  gap: 2vh;\n}\n.container .sub-container {\n  display: flex;\n  flex-flow: row;\n  gap: 1.85vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC1idXR0b25zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsUUFBQTtBQUNGO0FBQ0U7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUFDSiIsImZpbGUiOiJwYWdlLXByb2R1Y3QtYnV0dG9ucy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgZ2FwOiAydmg7XG5cbiAgLnN1Yi1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1mbG93OiByb3c7XG4gICAgZ2FwOiAxLjg1dmg7XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "PkOX":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/page-product/page-product-info/page-product-info.component.ts ***!
  \*************************************************************************************/
/*! exports provided: PageProductInfoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageProductInfoComponent", function() { return PageProductInfoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_product_info_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-product-info.component.html */ "n87u");
/* harmony import */ var _page_product_info_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-product-info.component.scss */ "v1AG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PageProductInfoComponent = class PageProductInfoComponent {
    constructor() {
        this.data = null;
    }
    ngOnInit() { }
};
PageProductInfoComponent.ctorParameters = () => [];
PageProductInfoComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageProductInfoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-product-info',
        template: _raw_loader_page_product_info_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_product_info_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageProductInfoComponent);



/***/ }),

/***/ "VS1G":
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/page-product/page-product-buttons/page-product-buttons.component.ts ***!
  \*******************************************************************************************/
/*! exports provided: PageProductButtonsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageProductButtonsComponent", function() { return PageProductButtonsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_product_buttons_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-product-buttons.component.html */ "WqHo");
/* harmony import */ var _page_product_buttons_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-product-buttons.component.scss */ "Oemk");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/core */ "gcOT");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");




const { Browser } = _capacitor_core__WEBPACK_IMPORTED_MODULE_3__["Plugins"];


let PageProductButtonsComponent = class PageProductButtonsComponent {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        this.mainScreenUrl = '/main';
        this.shopUrl = null;
        this.modalController = null;
    }
    ngOnInit() {
    }
    goToMainScreen() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.navCtrl.navigateRoot(this.mainScreenUrl);
            yield ((_a = this.modalController) === null || _a === void 0 ? void 0 : _a.dismiss());
        });
    }
    openShopUrl() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield Browser.open({ url: this.shopUrl });
        });
    }
};
PageProductButtonsComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] }
];
PageProductButtonsComponent.propDecorators = {
    shopUrl: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }],
    modalController: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
};
PageProductButtonsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-page-product-buttons',
        template: _raw_loader_page_product_buttons_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_product_buttons_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageProductButtonsComponent);



/***/ }),

/***/ "WqHo":
/*!***********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product-buttons/page-product-buttons.component.html ***!
  \***********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngIf=\"shopUrl; else skeletonPageButtons\">\n  <div class=\"container\">\n    <app-shared-button (click)=\"openShopUrl()\" type=\"main\" style=\"width: 100%\">\n      Перейти в магазин\n    </app-shared-button>\n    <div class=\"sub-container\">\n      <app-shared-button (click)=\"goToMainScreen()\" type=\"main-sub\" style=\"width: 100%\">\n        На главный экран\n      </app-shared-button>\n    </div>\n  </div>\n</ng-container>\n\n<ng-template #skeletonPageButtons>\n  <div class=\"container\">\n    <app-shared-button type=\"skeleton\" style=\"width: 100%\"></app-shared-button>\n    <div class=\"sub-container\">\n      <app-shared-button type=\"skeleton\" style=\"width: 100%\"></app-shared-button>\n    </div>\n  </div>\n</ng-template>\n");

/***/ }),

/***/ "Zveh":
/*!*******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product-price/page-product-price.component.html ***!
  \*******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"titles-container\" *ngIf=\"data; else skeletonProductPrice\">\n  <div class=\"title__brand\">\n    <span> {{ data?.brand || 'Brand' }} </span>\n    <svg-icon class=\"favorite\" [class.favorite__active]=\"data.isFavorite\" (click)=\"favouriteClickButton()\" src=\"assets/icon/svg/like.svg\"></svg-icon>\n  </div>\n  <div class=\"title__type\"> {{ data?.type || '---' }} </div>\n  <div class=\"title__price\">\n    <ng-container *ngIf=\"data?.oldPrice; else productPriceNormal\">\n      <span class=\"title__price__old\"> {{ (data?.oldPrice || 0) | number : '' : 'fr' }} ₽ </span>\n      <span class=\"title__price__sale\"> {{ (data?.price || 0) | number : '' : 'fr' }} ₽ </span>\n    </ng-container>\n    <ng-template #productPriceNormal>\n      <span class=\"title__price__normal\"> {{ (data?.price || 0) | number : '' : 'fr' }} ₽ </span>\n    </ng-template>\n  </div>\n</div>\n\n<ng-template #skeletonProductPrice>\n  <div class=\"titles-container\">\n    <div class=\"title__brand\">\n      <ion-skeleton-text animated style=\"width:40%; height: 3vh\"></ion-skeleton-text>\n    </div>\n    <ion-skeleton-text animated style=\"width:60%; height: 1.97vh\"></ion-skeleton-text>\n    <div class=\"title__price\">\n      <ion-skeleton-text animated style=\"width:70%; height: 2.9vh\"></ion-skeleton-text>\n    </div>\n  </div>\n</ng-template>\n");

/***/ }),

/***/ "bimA":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/page-product/page-product-price/page-product-price.component.ts ***!
  \***************************************************************************************/
/*! exports provided: PageProductPriceComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageProductPriceComponent", function() { return PageProductPriceComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_product_price_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-product-price.component.html */ "Zveh");
/* harmony import */ var _page_product_price_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-product-price.component.scss */ "sHuU");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PageProductPriceComponent = class PageProductPriceComponent {
    constructor() {
        this.data = null;
        this.favouriteClick = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    ngOnInit() {
    }
    favouriteClickButton() {
        this.favouriteClick.emit();
    }
};
PageProductPriceComponent.ctorParameters = () => [];
PageProductPriceComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    favouriteClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }]
};
PageProductPriceComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-product-price',
        template: _raw_loader_page_product_price_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_product_price_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageProductPriceComponent);



/***/ }),

/***/ "gVPk":
/*!****************************************************************!*\
  !*** ./src/app/pages/page-product/page-product.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  padding: 3.7vh 0 0 0;\n  box-sizing: border-box;\n  background: #FFFFFF;\n  overflow: hidden;\n  gap: 2.37vh;\n}\n.container .scroll-wrapper {\n  flex-grow: 1;\n  overflow: auto;\n  padding: 0 2.46vh;\n}\n.container .img-container {\n  height: 55.54vh;\n  margin: 0 -2.46vh;\n  background: #DCE0EB;\n}\n.container .image {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0FBREY7QUFHRTtFQUNFLFlBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFESjtBQUlFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFGSjtBQUtFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBSEoiLCJmaWxlIjoicGFnZS1wcm9kdWN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJHBhZGRpbmctdzogMi40NnZoO1xuXG4uY29udGFpbmVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIHBhZGRpbmc6IDMuN3ZoIDAgMCAwO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBiYWNrZ3JvdW5kOiAjRkZGRkZGO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBnYXA6IDIuMzd2aDtcblxuICAuc2Nyb2xsLXdyYXBwZXIge1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBvdmVyZmxvdzogYXV0bztcbiAgICBwYWRkaW5nOiAwICRwYWRkaW5nLXc7XG4gIH1cblxuICAuaW1nLWNvbnRhaW5lciB7XG4gICAgaGVpZ2h0OiA1NS41NHZoO1xuICAgIG1hcmdpbjogMCAoLSRwYWRkaW5nLXcpO1xuICAgIGJhY2tncm91bmQ6ICNEQ0UwRUI7XG4gIH1cblxuICAuaW1hZ2Uge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "lAEh":
/*!*****************************************************************!*\
  !*** ./src/app/@core/services/platform/mobile-share.service.ts ***!
  \*****************************************************************/
/*! exports provided: MobileShareService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobileShareService", function() { return MobileShareService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ "gcOT");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");




const { Share } = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"];
let MobileShareService = class MobileShareService {
    constructor(platform) {
        this.platform = platform;
    }
    shareApp() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const androidUrl = 'https://play.google.com/store/apps/details?id=com.luc.app';
            this.shareData('LUC', `Привет! Хочешь найти подходящую тебе одежду и стиль, тогда скачивай скорее приложение LUC: Android - ${androidUrl}, iOS - уже скоро`);
        });
    }
    shareData(title, text, url = null) {
        this.share({
            title,
            text,
            url,
            dialogTitle: title,
        }).then();
    }
    share(options) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.platform.is('android') || this.platform.is('ios')) {
                const shareRes = yield Share.share(options);
            }
            else {
                console.warn('your system not supported');
            }
        });
    }
};
MobileShareService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] }
];
MobileShareService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], MobileShareService);



/***/ }),

/***/ "mVaD":
/*!****************************************************!*\
  !*** ./src/app/@shared/classes/favorites.class.ts ***!
  \****************************************************/
/*! exports provided: FavoritesController */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FavoritesController", function() { return FavoritesController; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");

class FavoritesController {
    constructor(apiUserService) {
        this.apiUserService = apiUserService;
        this.isLoading = false;
    }
    setFavourite(id, isFavorite) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.isLoading) {
                return !isFavorite;
            }
            this.isLoading = true;
            try {
                if (isFavorite) {
                    yield this.addFavourite(id);
                    return true;
                }
                else {
                    yield this.deleteFavourite(id);
                    return false;
                }
            }
            catch (e) {
                console.error('setFavourite', e);
                return isFavorite;
            }
            finally {
                this.isLoading = false;
            }
        });
    }
    addFavourite(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = yield this.apiUserService.addFavorites(id);
            return res === null || res === void 0 ? void 0 : res.feed;
        });
    }
    deleteFavourite(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = yield this.apiUserService.deleteFavorites(id);
            return res;
        });
    }
}


/***/ }),

/***/ "n87u":
/*!*****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product-info/page-product-info.component.html ***!
  \*****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngIf=\"data; else skeletonProductInfo\">\n  <div class=\"container\">\n    <span class=\"label\"> О товаре </span>\n    <p class=\"list\">\n      <ng-container *ngFor=\"let li of data\">\n        {{ li?.title || '-' }}: <b>{{ li?.value || '-' }}</b> <br>\n      </ng-container>\n    </p>\n  </div>\n</ng-container>\n\n<ng-template #skeletonProductInfo>\n  <div class=\"container\">\n    <span class=\"label\">\n      <ion-skeleton-text animated style=\"width:40%; height: 2.9vh\"></ion-skeleton-text>\n    </span>\n    <p class=\"list\">\n      <ion-skeleton-text animated style=\"width:80%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:90%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:70%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:80%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:60%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:70%; height: 1.97vh\"></ion-skeleton-text>\n    </p>\n  </div>\n</ng-template>\n");

/***/ }),

/***/ "p0lb":
/*!***************************************************************!*\
  !*** ./src/app/@core/services/api/api-recognition.service.ts ***!
  \***************************************************************/
/*! exports provided: ApiRecognitionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiRecognitionService", function() { return ApiRecognitionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../platform/app-config.service */ "ophu");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../@shared/functions/base64-file.function */ "JJls");





let ApiRecognitionService = class ApiRecognitionService {
    constructor(appConfigService, http) {
        this.http = http;
        this.restUrl = appConfigService.recognitionUrl;
    }
    getMainRecommends() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                const url = `${this.restUrl}/api/MainScreen/feeds`;
                return yield this.http.get(url).toPromise();
            }
            catch (e) {
                console.error('getMainRecommends', e);
                return [];
            }
        });
    }
    getStartScreenReco(gender) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/StartScreenReco?gender=${gender}`).toPromise();
            }
            catch (e) {
                console.error('getStartScreenReco', e);
                return [];
            }
        });
    }
    searchByPhoto(dataUrl) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const imgFile = Object(_shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_4__["dataURLtoFile"])(dataUrl);
            const body = new FormData();
            body.append('imageFile', imgFile, imgFile.name);
            try {
                return yield this.http.post(`${this.restUrl}/api/Reco`, body).toPromise();
            }
            catch (e) {
                console.error('searchByPhoto', e);
                return null;
            }
        });
    }
    searchByDot(searchId, dot) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.post(`${this.restUrl}/api/Reco/search/${searchId}`, dot).toPromise();
            }
            catch (e) {
                console.error('searchByDot', e);
                return null;
            }
        });
    }
    searchByText(search) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/Text?query=${search}`).toPromise();
            }
            catch (e) {
                console.error('searchByText', e);
                return null;
            }
        });
    }
    getFullItem(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                const url = `${this.restUrl} /api/Reco/feed/${id}`;
                return yield this.http.get(`${this.restUrl}/api/Reco/feed/${id}`).toPromise();
            }
            catch (e) {
                console.error('getFullItem', e);
                return null;
            }
        });
    }
};
ApiRecognitionService.ctorParameters = () => [
    { type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
ApiRecognitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApiRecognitionService);



/***/ }),

/***/ "sHuU":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/page-product/page-product-price/page-product-price.component.scss ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".titles-container {\n  margin: 2.95vh 0 4.92vh 0;\n  display: flex;\n  flex-flow: column;\n}\n.titles-container .title__brand {\n  display: flex;\n  justify-content: space-between;\n  font-size: 2.96vh;\n  font-weight: 700;\n  color: #2F3441;\n  margin-bottom: 0.62vh;\n}\n.titles-container .title__brand .favorite {\n  width: 2.46vh;\n  height: 2.46vh;\n  color: #99A0AB;\n}\n.titles-container .title__brand .favorite__active {\n  color: #FF3B30;\n}\n.titles-container .title__type {\n  font-size: 1.97vh;\n  font-weight: 400;\n  color: #6B7683;\n  margin-bottom: 1.72vh;\n}\n.titles-container .title__price {\n  font-size: 2.96vh;\n  font-weight: 700;\n}\n.titles-container .title__price__old {\n  font-size: 1.97vh;\n  font-weight: 500;\n  color: #6B7683;\n  -webkit-text-decoration-line: line-through;\n          text-decoration-line: line-through;\n}\n.titles-container .title__price__sale {\n  color: #3A83F1;\n}\n.titles-container .title__price__normal {\n  color: #202D3D;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC1wcmljZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBQ0Y7QUFHSTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EscUJBQUE7QUFETjtBQUdNO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0FBRFI7QUFHUTtFQUNFLGNBQUE7QUFEVjtBQU1JO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtBQUpOO0FBT0k7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0FBTE47QUFPTTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsMENBQUE7VUFBQSxrQ0FBQTtBQUxSO0FBUU07RUFDRSxjQUFBO0FBTlI7QUFTTTtFQUNFLGNBQUE7QUFQUiIsImZpbGUiOiJwYWdlLXByb2R1Y3QtcHJpY2UuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGl0bGVzLWNvbnRhaW5lciB7XG4gIG1hcmdpbjogMi45NXZoIDAgNC45MnZoIDA7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuXG4gIC50aXRsZSB7XG5cbiAgICAmX19icmFuZCB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgZm9udC1zaXplOiAyLjk2dmg7XG4gICAgICBmb250LXdlaWdodDogNzAwO1xuICAgICAgY29sb3I6ICMyRjM0NDE7XG4gICAgICBtYXJnaW4tYm90dG9tOiAwLjYydmg7XG5cbiAgICAgIC5mYXZvcml0ZSB7XG4gICAgICAgIHdpZHRoOiAyLjQ2dmg7XG4gICAgICAgIGhlaWdodDogMi40NnZoO1xuICAgICAgICBjb2xvcjogIzk5QTBBQjtcblxuICAgICAgICAmX19hY3RpdmUge1xuICAgICAgICAgIGNvbG9yOiAjRkYzQjMwO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgJl9fdHlwZSB7XG4gICAgICBmb250LXNpemU6IDEuOTd2aDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICBjb2xvcjogIzZCNzY4MztcbiAgICAgIG1hcmdpbi1ib3R0b206IDEuNzJ2aDtcbiAgICB9XG5cbiAgICAmX19wcmljZSB7XG4gICAgICBmb250LXNpemU6IDIuOTZ2aDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG5cbiAgICAgICZfX29sZCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICBjb2xvcjogIzZCNzY4MztcbiAgICAgICAgdGV4dC1kZWNvcmF0aW9uLWxpbmU6IGxpbmUtdGhyb3VnaDtcbiAgICAgIH1cblxuICAgICAgJl9fc2FsZSB7XG4gICAgICAgIGNvbG9yOiAjM0E4M0YxO1xuICAgICAgfVxuXG4gICAgICAmX19ub3JtYWwge1xuICAgICAgICBjb2xvcjogIzIwMkQzRDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "u7xx":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/page-product/page-product-header/page-product-header.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: PageProductHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageProductHeaderComponent", function() { return PageProductHeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_product_header_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-product-header.component.html */ "J1eq");
/* harmony import */ var _page_product_header_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-product-header.component.scss */ "9jac");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PageProductHeaderComponent = class PageProductHeaderComponent {
    constructor() {
        this.label = null;
        this.back = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.share = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    ngOnInit() {
    }
    backClick() {
        this.back.emit();
    }
    shareClick() {
        this.share.emit();
    }
};
PageProductHeaderComponent.ctorParameters = () => [];
PageProductHeaderComponent.propDecorators = {
    label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    back: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    share: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }]
};
PageProductHeaderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-product-header',
        template: _raw_loader_page_product_header_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_product_header_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageProductHeaderComponent);



/***/ }),

/***/ "v1AG":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/page-product/page-product-info/page-product-info.component.scss ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  margin-top: 3.94vh;\n}\n.container .label {\n  font-size: 2.95vh;\n  font-weight: 700;\n  color: #2F3441;\n}\n.container .list {\n  color: black;\n  line-height: 2.95vh;\n  font-size: 1.97vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC1pbmZvLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7QUFDRjtBQUNFO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFDSjtBQUVFO0VBQ0UsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFBSiIsImZpbGUiOiJwYWdlLXByb2R1Y3QtaW5mby5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBtYXJnaW4tdG9wOiAzLjk0dmg7XG5cbiAgLmxhYmVsIHtcbiAgICBmb250LXNpemU6IDIuOTV2aDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGNvbG9yOiAjMkYzNDQxO1xuICB9XG5cbiAgLmxpc3Qge1xuICAgIGNvbG9yOiBibGFjaztcbiAgICBsaW5lLWhlaWdodDogMi45NXZoO1xuICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICB9XG59XG4iXX0= */");

/***/ })

}]);
//# sourceMappingURL=default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee-es2015.js.map