(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["page-tabs-favorites-page-tabs-favorites-module"],{

/***/ "/f9K":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favorites.component.html ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"header\"> Избранное </div>\n  <div class=\"subheader\"> Ваша персональная коллекция </div>\n  <ion-content>\n    <ion-refresher #refresher slot=\"fixed\" style=\"z-index: 999\" (ionRefresh)=\"doRefresh($event)\">\n      <ion-refresher-content></ion-refresher-content>\n    </ion-refresher>\n    <div class=\"content-wrapper\">\n      <app-page-tabs-favourites-item [data]=\"item\" *ngFor=\"let item of data$ | async\" (click)=\"itemClick(item)\" class=\"item\"></app-page-tabs-favourites-item>\n    </div>\n  </ion-content>\n</div>\n\n");

/***/ }),

/***/ "0t7m":
/*!**************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favourites-item/page-tabs-favourites-item.component.html ***!
  \**************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect></ion-ripple-effect>\n  <img class=\"image\" [ngClass]=\"'image__' + (!!image ? 'active' : 'disable')\" alt=\"\" [src]=\"image\">\n</div>\n");

/***/ }),

/***/ "Aidc":
/*!****************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favorites.component.scss ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  flex-flow: column;\n  width: 100%;\n  height: 100%;\n  gap: 1.97vh;\n  box-sizing: border-box;\n  overflow: scroll;\n  background: white;\n}\n.container .header {\n  font-size: 2.71vh;\n  font-weight: 700;\n  color: #222222;\n  margin-top: 2.46vh;\n  padding: 0 4.27vw;\n}\n.container .subheader {\n  font-size: 1.9vh;\n  font-weight: 400;\n  color: #222222;\n  padding: 0 4.27vw;\n}\n.container .content-wrapper {\n  display: flex;\n  max-height: 100%;\n  flex-wrap: wrap;\n  row-gap: 4vw;\n  -moz-column-gap: 4vw;\n       column-gap: 4vw;\n  overflow: auto;\n  padding: 0 4.27vw;\n  padding-top: 0.5vh;\n}\n.container .content-wrapper .item {\n  width: 27.6vw;\n  height: 34.13vw;\n}\nion-content {\n  flex-grow: 1;\n  overflow: hidden;\n  --overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1mYXZvcml0ZXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFFQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFGRjtBQUlFO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQWxCUTtBQWdCWjtBQUtFO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkF6QlE7QUFzQlo7QUFNRTtFQUNFLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7T0FBQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQW5DUTtFQW9DUixrQkFBQTtBQUpKO0FBTUk7RUFDRSxhQUFBO0VBQ0EsZUFBQTtBQUpOO0FBU0E7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQU5GIiwiZmlsZSI6InBhZ2UtdGFicy1mYXZvcml0ZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIkcGFkZGluZy13OiAwIDQuMjd2dztcblxuLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBnYXA6IDEuOTd2aDtcbiAgLy9wYWRkaW5nOiAwIDQuMjd2dztcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG5cbiAgLmhlYWRlciB7XG4gICAgZm9udC1zaXplOiAyLjcxdmg7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgICBtYXJnaW4tdG9wOiAyLjQ2dmg7XG4gICAgcGFkZGluZzogJHBhZGRpbmctdztcbiAgfVxuXG4gIC5zdWJoZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogMS45dmg7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgICBwYWRkaW5nOiAkcGFkZGluZy13O1xuICB9XG5cbiAgLmNvbnRlbnQtd3JhcHBlciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBtYXgtaGVpZ2h0OiAxMDAlO1xuICAgIGZsZXgtd3JhcDogd3JhcDtcbiAgICByb3ctZ2FwOiA0dnc7XG4gICAgY29sdW1uLWdhcDogNHZ3O1xuICAgIG92ZXJmbG93OiBhdXRvO1xuICAgIHBhZGRpbmc6ICRwYWRkaW5nLXc7XG4gICAgcGFkZGluZy10b3A6IDAuNXZoO1xuXG4gICAgLml0ZW0ge1xuICAgICAgd2lkdGg6IDI3LjZ2dztcbiAgICAgIGhlaWdodDogMzQuMTN2dztcbiAgICB9XG4gIH1cbn1cblxuaW9uLWNvbnRlbnQge1xuICBmbGV4LWdyb3c6IDE7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIC0tb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbiJdfQ== */");

/***/ }),

/***/ "EkPg":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favorites.component.ts ***!
  \**************************************************************************************/
/*! exports provided: PageTabsFavoritesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsFavoritesComponent", function() { return PageTabsFavoritesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_favorites_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-favorites.component.html */ "/f9K");
/* harmony import */ var _page_tabs_favorites_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-favorites.component.scss */ "Aidc");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _page_tabs_favorites_popup_page_tabs_favorites_popup_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./page-tabs-favorites-popup/page-tabs-favorites-popup.component */ "r0gJ");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../@core/services/api/api-user.service */ "lA1K");








let PageTabsFavoritesComponent = class PageTabsFavoritesComponent {
    constructor(modalController, apiUserService) {
        this.modalController = modalController;
        this.apiUserService = apiUserService;
        this.tabName = 'like';
        this.data$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([]);
    }
    ngOnInit() {
        this.loadFavorites().then();
    }
    itemClick(item) {
        this.modalOpen(item).then();
    }
    doRefresh(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.loadFavorites();
            setTimeout(() => {
                event.srcElement.complete();
            }, 300);
        });
    }
    loadFavorites() {
        var _a, _b;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = (_b = (_a = (yield this.apiUserService.getFavorites())) === null || _a === void 0 ? void 0 : _a.map(x => x.feed)) !== null && _b !== void 0 ? _b : [];
            if (JSON.stringify(this.data$.getValue()) === JSON.stringify(res)) {
                return;
            }
            this.data$.next(res);
        });
    }
    modalOpen(item) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _page_tabs_favorites_popup_page_tabs_favorites_popup_component__WEBPACK_IMPORTED_MODULE_5__["PageTabsFavoritesPopupComponent"],
                componentProps: { data: { item, delete: () => this.deleteItem(item) } }
            });
            modal.onDidDismiss().then(() => this.loadFavorites());
            return yield modal.present();
        });
    }
    deleteItem(item) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.apiUserService.deleteFavorites(item.id);
        });
    }
};
PageTabsFavoritesComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_7__["ApiUserService"] }
];
PageTabsFavoritesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-favorites',
        template: _raw_loader_page_tabs_favorites_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_favorites_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsFavoritesComponent);



/***/ }),

/***/ "H0kr":
/*!**************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favorites-popup/page-tabs-favorites-popup.component.html ***!
  \**************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div (click)=\"switchVisible()\" class=\"container\">\n  <img class=\"image\" alt=\"\" [src]=\"imgSrc\">\n  <div class=\"ui-wrapper\" [@enterTrigger] *ngIf=\"isInterface$ | async\">\n    <div class=\"buttons-container\">\n      <div (click)=\"close($event)\" class=\"small-icon-container\">\n        <svg-icon class=\"icon\" [src]=\"'assets/icon/svg/back.svg'\"></svg-icon>\n      </div>\n      <div class=\"small-icon-container\" (click)=\"delete($event)\">\n        <svg-icon class=\"icon\" [src]=\"'assets/icon/svg/trash.svg'\"></svg-icon>\n      </div>\n    </div>\n    <div class=\"buttons-container buttons-container__big\">\n      <ng-container *ngTemplateOutlet=\"circleButton; context:{src: 'share', event: share.bind(this)}\"></ng-container>\n      <div (click)=\"openProduct($event)\" class=\"shop\">\n        <svg-icon src=\"assets/icon/svg/shopping-cart.svg\"></svg-icon>\n      </div>\n      <ng-container *ngTemplateOutlet=\"circleButton context:{src: 'search', event: search.bind(this)}\"></ng-container>\n    </div>\n  </div>\n</div>\n\n<ng-template #circleButton let-src=\"src\" let-event=\"event\">\n  <div (click)=\"event($event)\" class=\"circle-button ion-activatable ripple-parent\">\n    <ion-ripple-effect></ion-ripple-effect>\n    <div class=\"icon-container\">\n      <svg-icon class=\"icon\" [src]=\"'assets/icon/svg/' + src + '.svg'\"></svg-icon>\n    </div>\n  </div>\n</ng-template>\n");

/***/ }),

/***/ "Hvu6":
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favourites-item/page-tabs-favourites-item.component.ts ***!
  \**********************************************************************************************************************/
/*! exports provided: PageTabsFavouritesItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsFavouritesItemComponent", function() { return PageTabsFavouritesItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_favourites_item_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-favourites-item.component.html */ "0t7m");
/* harmony import */ var _page_tabs_favourites_item_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-favourites-item.component.scss */ "I4wg");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PageTabsFavouritesItemComponent = class PageTabsFavouritesItemComponent {
    constructor() {
        this.item = null;
        this.image = null;
    }
    set data(value) {
        this.item = value;
        this.image = value.imageUrl;
    }
    ngOnInit() { }
};
PageTabsFavouritesItemComponent.ctorParameters = () => [];
PageTabsFavouritesItemComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageTabsFavouritesItemComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-favourites-item',
        template: _raw_loader_page_tabs_favourites_item_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_favourites_item_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsFavouritesItemComponent);



/***/ }),

/***/ "I4wg":
/*!************************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favourites-item/page-tabs-favourites-item.component.scss ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  width: inherit;\n  height: inherit;\n  overflow: hidden;\n  background: #DCE0EB;\n  border-radius: 3.2vw;\n  box-shadow: rgba(0, 0, 0, 0.1) 0 0 0.5vh 0;\n}\n.container .image {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.container .image__active {\n  opacity: 1;\n  transition: 0.5s;\n}\n.container .image__disable {\n  opacity: 0;\n  transition: 0.5s;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1mYXZvdXJpdGVzLWl0ZW0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSwwQ0FBQTtBQUNGO0FBQ0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7QUFDSjtBQUNJO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0FBQ047QUFFSTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtBQUFOIiwiZmlsZSI6InBhZ2UtdGFicy1mYXZvdXJpdGVzLWl0ZW0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgd2lkdGg6IGluaGVyaXQ7XG4gIGhlaWdodDogaW5oZXJpdDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYmFja2dyb3VuZDogI0RDRTBFQjtcbiAgYm9yZGVyLXJhZGl1czogMy4ydnc7XG4gIGJveC1zaGFkb3c6IHJnYigwIDAgMCAvIDEwJSkgMCAwIDAuNXZoIDA7XG5cbiAgLmltYWdlIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG5cbiAgICAmX19hY3RpdmUge1xuICAgICAgb3BhY2l0eTogMTtcbiAgICAgIHRyYW5zaXRpb246LjVzO1xuICAgIH1cblxuICAgICZfX2Rpc2FibGUge1xuICAgICAgb3BhY2l0eTogMDtcbiAgICAgIHRyYW5zaXRpb246IC41cztcbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "dhg9":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favorites.module.ts ***!
  \***********************************************************************************/
/*! exports provided: PageTabsFavoritesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsFavoritesModule", function() { return PageTabsFavoritesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _page_tabs_favorites_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-tabs-favorites.component */ "EkPg");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _page_tabs_favourites_item_page_tabs_favourites_item_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./page-tabs-favourites-item/page-tabs-favourites-item.component */ "Hvu6");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../@shared/shared.module */ "pk6O");
/* harmony import */ var _page_tabs_favorites_popup_page_tabs_favorites_popup_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./page-tabs-favorites-popup/page-tabs-favorites-popup.component */ "r0gJ");
/* harmony import */ var _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../page-product/page-product.module */ "A6qN");









let PageTabsFavoritesModule = class PageTabsFavoritesModule {
};
PageTabsFavoritesModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_tabs_favorites_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsFavoritesComponent"], _page_tabs_favourites_item_page_tabs_favourites_item_component__WEBPACK_IMPORTED_MODULE_5__["PageTabsFavouritesItemComponent"], _page_tabs_favorites_popup_page_tabs_favorites_popup_component__WEBPACK_IMPORTED_MODULE_7__["PageTabsFavoritesPopupComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{ path: '', component: _page_tabs_favorites_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsFavoritesComponent"] }]),
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__["SharedModule"],
            _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_8__["PageProductModule"],
        ]
    })
], PageTabsFavoritesModule);



/***/ }),

/***/ "qcVO":
/*!************************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favorites-popup/page-tabs-favorites-popup.component.scss ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  position: relative;\n  display: flex;\n  width: 100%;\n  height: 100%;\n  background: #2F3441;\n}\n.container .image {\n  width: 100%;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\n.container .ui-wrapper {\n  position: absolute;\n  display: flex;\n  flex-flow: column;\n  justify-content: space-between;\n  width: 100%;\n  height: 100%;\n  padding: 4.9vh 5vw;\n  transition: 1s;\n}\n.container .ui-wrapper__disabled {\n  visibility: hidden;\n  transition: 1s;\n}\n.container .ui-wrapper .buttons-container {\n  display: flex;\n  justify-content: space-between;\n}\n.container .ui-wrapper .buttons-container__big {\n  padding: 0 5vw;\n}\n.container .ui-wrapper .buttons-container .small-icon-container {\n  width: 2.2vh;\n  height: 2.2vh;\n  color: #FFFFFF;\n}\n.container .ui-wrapper .buttons-container .shop {\n  width: 11.7vw;\n  height: 11.7vw;\n  margin: auto 0;\n  padding: 3vw;\n  border-radius: 50%;\n  background: #2CB172;\n  color: #FFFFFF;\n}\n.container .ui-wrapper .circle-button {\n  display: flex;\n  width: 16vw;\n  height: 16vw;\n  border-radius: 50%;\n  background: #41485D;\n}\n.container .ui-wrapper .circle-button .icon-container {\n  margin: auto;\n  width: 30%;\n  height: 30%;\n}\n.container .ui-wrapper .circle-button .icon {\n  color: #DADADA;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1mYXZvcml0ZXMtcG9wdXAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBQ0Y7QUFDRTtFQUNFLFdBQUE7RUFDQSxzQkFBQTtLQUFBLG1CQUFBO0FBQ0o7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsOEJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQUFKO0FBRUk7RUFDRSxrQkFBQTtFQUNBLGNBQUE7QUFBTjtBQUdJO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0FBRE47QUFHTTtFQUNFLGNBQUE7QUFEUjtBQUlNO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0FBRlI7QUFLTTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQUhSO0FBT0k7RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBTE47QUFPTTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQUxSO0FBUU07RUFDRSxjQUFBO0FBTlIiLCJmaWxlIjoicGFnZS10YWJzLWZhdm9yaXRlcy1wb3B1cC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJhY2tncm91bmQ6ICMyRjM0NDE7XG5cbiAgLmltYWdlIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBvYmplY3QtZml0OiBjb250YWluO1xuICB9XG5cbiAgLnVpLXdyYXBwZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZmxvdzogY29sdW1uO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgcGFkZGluZzogNC45dmggNXZ3O1xuICAgIHRyYW5zaXRpb246IDFzO1xuXG4gICAgJl9fZGlzYWJsZWQge1xuICAgICAgdmlzaWJpbGl0eTogaGlkZGVuO1xuICAgICAgdHJhbnNpdGlvbjogMXM7XG4gICAgfVxuXG4gICAgLmJ1dHRvbnMtY29udGFpbmVyIHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cbiAgICAgICZfX2JpZyB7XG4gICAgICAgIHBhZGRpbmc6IDAgNXZ3O1xuICAgICAgfVxuXG4gICAgICAuc21hbGwtaWNvbi1jb250YWluZXIge1xuICAgICAgICB3aWR0aDogMi4ydmg7XG4gICAgICAgIGhlaWdodDogMi4ydmg7XG4gICAgICAgIGNvbG9yOiAjRkZGRkZGO1xuICAgICAgfVxuXG4gICAgICAuc2hvcCB7XG4gICAgICAgIHdpZHRoOiAxMS43dnc7XG4gICAgICAgIGhlaWdodDogMTEuN3Z3O1xuICAgICAgICBtYXJnaW46IGF1dG8gMDtcbiAgICAgICAgcGFkZGluZzogM3Z3O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgIGJhY2tncm91bmQ6ICMyQ0IxNzI7XG4gICAgICAgIGNvbG9yOiAjRkZGRkZGO1xuICAgICAgfVxuICAgIH1cblxuICAgIC5jaXJjbGUtYnV0dG9uIHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICB3aWR0aDogMTZ2dztcbiAgICAgIGhlaWdodDogMTZ2dztcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIGJhY2tncm91bmQ6ICM0MTQ4NUQ7XG5cbiAgICAgIC5pY29uLWNvbnRhaW5lciB7XG4gICAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgICAgd2lkdGg6IDMwJTtcbiAgICAgICAgaGVpZ2h0OiAzMCU7XG4gICAgICB9XG5cbiAgICAgIC5pY29uIHtcbiAgICAgICAgY29sb3I6ICNEQURBREE7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "r0gJ":
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-favorites/page-tabs-favorites-popup/page-tabs-favorites-popup.component.ts ***!
  \**********************************************************************************************************************/
/*! exports provided: PageTabsFavoritesPopupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsFavoritesPopupComponent", function() { return PageTabsFavoritesPopupComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_favorites_popup_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-favorites-popup.component.html */ "H0kr");
/* harmony import */ var _page_tabs_favorites_popup_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-favorites-popup.component.scss */ "qcVO");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/animations */ "R0Ic");
/* harmony import */ var _shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../@shared/functions/base64-file.function */ "JJls");
/* harmony import */ var _core_services_platform_status_bar_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../@core/services/platform/status-bar.service */ "qCjG");
/* harmony import */ var _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../@core/services/platform/mobile-share.service */ "lAEh");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../@core/services/api/api-recognition.service */ "p0lb");
/* harmony import */ var _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../page-product/page-product.component */ "8jGz");













let PageTabsFavoritesPopupComponent = class PageTabsFavoritesPopupComponent {
    constructor(statusBarService, modalController, navCtrl, shareService, recognitionInfoService, apiRecognitionService) {
        this.statusBarService = statusBarService;
        this.modalController = modalController;
        this.navCtrl = navCtrl;
        this.shareService = shareService;
        this.recognitionInfoService = recognitionInfoService;
        this.apiRecognitionService = apiRecognitionService;
        this.nextRouteUrl = '/main/camera';
        this.imgSrc = null;
        this.isInterface$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"](true);
        this.item = null;
        this.isSetDefault = true;
    }
    set data(value) {
        this.imgSrc = value.item.imageUrl;
        this.item = Object.assign({}, value.item);
        this.deleteFn = value.delete;
    }
    ngOnInit() {
        this.statusBarService.hide().then();
    }
    ngOnDestroy() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.isSetDefault) {
                return;
            }
            yield this.statusBarService.setDefault();
        });
    }
    switchVisible() {
        this.isInterface$.next(!this.isInterface$.value);
    }
    close(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            event.stopPropagation();
            yield this.closeModal();
        });
    }
    delete(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            event.stopPropagation();
            yield this.deleteFn();
            yield this.closeModal();
        });
    }
    search(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            event.stopPropagation();
            const img = yield Object(_shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_7__["urlToDataUrl"])(this.imgSrc);
            this.isSetDefault = false;
            yield this.navCtrl.navigateForward(this.nextRouteUrl, { queryParams: { img } });
            yield this.closeModal();
        });
    }
    share(event) {
        event.stopPropagation();
        const product = this.item;
        if (!product) {
            return;
        }
        this.shareService.shareData('Отправленно из приложения LUC', `Посмотри что нашел в LUC в магазине ${product.shopTitle}:`, product.shopUrl);
    }
    openProduct(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            event.stopPropagation();
            const productId = this.item.id;
            if (!productId) {
                return;
            }
            this.recognitionInfoService.recognitionFeedFunction = () => this.apiRecognitionService.getFullItem(productId);
            yield this.presentModalInfo();
        });
    }
    presentModalInfo() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_12__["PageProductComponent"],
            });
            return yield modal.present();
        });
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.modalController.dismiss();
        });
    }
};
PageTabsFavoritesPopupComponent.ctorParameters = () => [
    { type: _core_services_platform_status_bar_service__WEBPACK_IMPORTED_MODULE_8__["StatusBarService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_9__["MobileShareService"] },
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_10__["RecognitionInfoService"] },
    { type: _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_11__["ApiRecognitionService"] }
];
PageTabsFavoritesPopupComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageTabsFavoritesPopupComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-favorites-popup',
        template: _raw_loader_page_tabs_favorites_popup_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        animations: [
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["trigger"])('enterTrigger', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["transition"])('void => *', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["style"])({ opacity: 0 }),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["animate"])('300ms', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["style"])({ opacity: 1 }))
                ]),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["transition"])('* => void', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["style"])({ opacity: 1 }),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["animate"])('300ms', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_6__["style"])({ opacity: 0 }))
                ]),
            ])
        ],
        styles: [_page_tabs_favorites_popup_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsFavoritesPopupComponent);



/***/ })

}]);
//# sourceMappingURL=page-tabs-favorites-page-tabs-favorites-module-es2015.js.map