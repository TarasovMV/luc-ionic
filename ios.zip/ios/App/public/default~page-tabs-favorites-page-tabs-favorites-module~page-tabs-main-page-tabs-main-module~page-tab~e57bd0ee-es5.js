(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee"], {
    /***/
    "7mVc":
    /*!************************************************************!*\
      !*** ./src/app/@core/services/recognition-info.service.ts ***!
      \************************************************************/

    /*! exports provided: RecognitionInfoService */

    /***/
    function mVc(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RecognitionInfoService", function () {
        return RecognitionInfoService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _user_info_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./user-info.service */
      "tTdR");
      /* harmony import */


      var _api_api_recognition_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./api/api-recognition.service */
      "p0lb");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "qCKp");

      var RecognitionInfoService = /*#__PURE__*/function () {
        function RecognitionInfoService(userInfoService, apiRecognitionService) {
          _classCallCheck(this, RecognitionInfoService);

          this.userInfoService = userInfoService;
          this.apiRecognitionService = apiRecognitionService;
          this.recommendCards$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]([null, null, null]);
        }

        _createClass(RecognitionInfoService, [{
          key: "textResultMapper",
          value: function textResultMapper(result) {
            var _a;

            return {
              scoreId: result === null || result === void 0 ? void 0 : result.id,
              previews: (_a = result === null || result === void 0 ? void 0 : result.searchResults) !== null && _a !== void 0 ? _a : []
            };
          }
        }, {
          key: "getStartReco",
          value: function getStartReco() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var gender;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.userInfoService.getInitialGender();

                    case 2:
                      gender = _context.sent;
                      _context.next = 5;
                      return this.apiRecognitionService.getStartScreenReco(gender);

                    case 5:
                      return _context.abrupt("return", _context.sent);

                    case 6:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "getMainRecommends",
          value: function getMainRecommends() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var res;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      if (!this.isMainRecommendsLoaded()) {
                        _context2.next = 2;
                        break;
                      }

                      return _context2.abrupt("return");

                    case 2:
                      _context2.next = 4;
                      return this.apiRecognitionService.getMainRecommends();

                    case 4:
                      res = _context2.sent;
                      this.recommendCards$.next(res);

                    case 6:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "isMainRecommendsLoaded",
          value: function isMainRecommendsLoaded() {
            return !this.recommendCards$.getValue().every(function (x) {
              return x === null;
            });
          }
        }]);

        return RecognitionInfoService;
      }();

      RecognitionInfoService.ctorParameters = function () {
        return [{
          type: _user_info_service__WEBPACK_IMPORTED_MODULE_2__["UserInfoService"]
        }, {
          type: _api_api_recognition_service__WEBPACK_IMPORTED_MODULE_3__["ApiRecognitionService"]
        }];
      };

      RecognitionInfoService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], RecognitionInfoService);
      /***/
    },

    /***/
    "8jGz":
    /*!**************************************************************!*\
      !*** ./src/app/pages/page-product/page-product.component.ts ***!
      \**************************************************************/

    /*! exports provided: PageProductComponent */

    /***/
    function jGz(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageProductComponent", function () {
        return PageProductComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_product_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-product.component.html */
      "FRye");
      /* harmony import */


      var _page_product_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-product.component.scss */
      "gVPk");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../@core/services/recognition-info.service */
      "7mVc");
      /* harmony import */


      var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../@core/services/api/api-user.service */
      "lA1K");
      /* harmony import */


      var _shared_classes_favorites_class__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../@shared/classes/favorites.class */
      "mVaD");
      /* harmony import */


      var _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../@core/services/platform/mobile-share.service */
      "lAEh");

      var PageProductComponent = /*#__PURE__*/function () {
        function PageProductComponent(modalCtrl, recognitionInfoService, shareService, apiUserService) {
          _classCallCheck(this, PageProductComponent);

          this.modalCtrl = modalCtrl;
          this.recognitionInfoService = recognitionInfoService;
          this.shareService = shareService;
          this.data$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](null);
          this.sharedData = this.data$;
          this.favoritesController = new _shared_classes_favorites_class__WEBPACK_IMPORTED_MODULE_8__["FavoritesController"](apiUserService);
        }

        _createClass(PageProductComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _a, _b, _c;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var res;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return (_b = (_a = this.recognitionInfoService).recognitionFeedFunction) === null || _b === void 0 ? void 0 : _b.call(_a);

                    case 2:
                      res = _context3.sent;
                      res.infoList = (_c = res.infoList) !== null && _c !== void 0 ? _c : [];
                      this.data$.next(res);

                    case 5:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "setFavorite",
          value: function setFavorite() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var product, isFavorite;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      product = this.data$.getValue();
                      _context4.next = 3;
                      return this.favoritesController.setFavourite(product.id, !product.isFavorite);

                    case 3:
                      isFavorite = _context4.sent;
                      this.data$.next(Object.assign(Object.assign({}, product), {
                        isFavorite: isFavorite
                      }));

                    case 5:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "closePage",
          value: function closePage() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      _context5.next = 2;
                      return this.modalCtrl.dismiss();

                    case 2:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "shareProduct",
          value: function shareProduct() {
            var product = this.data$.getValue();

            if (!product) {
              return;
            }

            this.shareService.shareData('Отправленно из приложения LUC', "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0438 \u0447\u0442\u043E \u043D\u0430\u0448\u0435\u043B \u0432 LUC \u0432 \u043C\u0430\u0433\u0430\u0437\u0438\u043D\u0435 ".concat(product.shopTitle, ":"), product.shopUrl);
          }
        }]);

        return PageProductComponent;
      }();

      PageProductComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }, {
          type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_6__["RecognitionInfoService"]
        }, {
          type: _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_9__["MobileShareService"]
        }, {
          type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_7__["ApiUserService"]
        }];
      };

      PageProductComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-product',
        template: _raw_loader_page_product_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_product_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageProductComponent);
      /***/
    },

    /***/
    "9jac":
    /*!*******************************************************************************************!*\
      !*** ./src/app/pages/page-product/page-product-header/page-product-header.component.scss ***!
      \*******************************************************************************************/

    /*! exports provided: default */

    /***/
    function jac(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".header {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n  padding: 0 2.2vh;\n  box-sizing: border-box;\n}\n.header > * {\n  margin: auto 0;\n}\n.header__brand {\n  text-align: center;\n  font-size: 2.1vh;\n  font-weight: 600;\n  color: #222222;\n}\n.header .icon {\n  width: 2.43vh;\n  height: 2.43vh;\n}\n.header .icon__back {\n  color: #2CB172;\n}\n.header .icon__share {\n  color: #99A0AB;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC1oZWFkZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtBQUNGO0FBQ0U7RUFDRSxjQUFBO0FBQ0o7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFBSjtBQUdFO0VBQ0UsYUFBQTtFQUNBLGNBQUE7QUFESjtBQUdJO0VBQ0UsY0FBQTtBQUROO0FBSUk7RUFDRSxjQUFBO0FBRk4iLCJmaWxlIjoicGFnZS1wcm9kdWN0LWhlYWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICB3aWR0aDogMTAwJTtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBwYWRkaW5nOiAwIDIuMnZoO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuXG4gICYgPiAqIHtcbiAgICBtYXJnaW46IGF1dG8gMDtcbiAgfVxuXG4gICZfX2JyYW5kIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyLjF2aDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiAjMjIyMjIyO1xuICB9XG5cbiAgLmljb24ge1xuICAgIHdpZHRoOiAyLjQzdmg7XG4gICAgaGVpZ2h0OiAyLjQzdmg7XG5cbiAgICAmX19iYWNrIHtcbiAgICAgIGNvbG9yOiAjMkNCMTcyO1xuICAgIH1cblxuICAgICZfX3NoYXJlIHtcbiAgICAgIGNvbG9yOiAjOTlBMEFCOztcbiAgICB9XG4gIH1cbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "A6qN":
    /*!***********************************************************!*\
      !*** ./src/app/pages/page-product/page-product.module.ts ***!
      \***********************************************************/

    /*! exports provided: PageProductModule */

    /***/
    function A6qN(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageProductModule", function () {
        return PageProductModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _page_product_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./page-product.component */
      "8jGz");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../@shared/shared.module */
      "pk6O");
      /* harmony import */


      var _page_product_info_page_product_info_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./page-product-info/page-product-info.component */
      "PkOX");
      /* harmony import */


      var _page_product_buttons_page_product_buttons_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./page-product-buttons/page-product-buttons.component */
      "VS1G");
      /* harmony import */


      var _page_product_header_page_product_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./page-product-header/page-product-header.component */
      "u7xx");
      /* harmony import */


      var _page_product_price_page_product_price_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./page-product-price/page-product-price.component */
      "bimA");

      var PageProductModule = function PageProductModule() {
        _classCallCheck(this, PageProductModule);
      };

      PageProductModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_product_component__WEBPACK_IMPORTED_MODULE_3__["PageProductComponent"], _page_product_info_page_product_info_component__WEBPACK_IMPORTED_MODULE_5__["PageProductInfoComponent"], _page_product_buttons_page_product_buttons_component__WEBPACK_IMPORTED_MODULE_6__["PageProductButtonsComponent"], _page_product_header_page_product_header_component__WEBPACK_IMPORTED_MODULE_7__["PageProductHeaderComponent"], _page_product_price_page_product_price_component__WEBPACK_IMPORTED_MODULE_8__["PageProductPriceComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"]]
      })], PageProductModule);
      /***/
    },

    /***/
    "FRye":
    /*!******************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product.component.html ***!
      \******************************************************************************************************/

    /*! exports provided: default */

    /***/
    function FRye(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container\">\n  <app-page-product-header\n    [label]=\"(sharedData | async)?.shopTitle\"\n    (back)=\"closePage()\"\n    (share)=\"shareProduct()\"\n  ></app-page-product-header>\n  <div class=\"scroll-wrapper\">\n    <div class=\"img-container\">\n      <img class=\"image\" alt=\"\" [src]=\"(sharedData | async)?.imageUrl\">\n<!--      TODO: add img scroller-->\n    </div>\n    <app-page-product-price [data]=\"(sharedData | async)\" (favouriteClick)=\"setFavorite()\"></app-page-product-price>\n    <app-page-product-buttons [modalController]=\"modalCtrl\" [shopUrl]=\"(sharedData | async)?.shopUrl\"></app-page-product-buttons>\n    <app-page-product-info [data]=\"(sharedData | async)?.infoList\"></app-page-product-info>\n  </div>\n</div>\n\n<ng-template #productContainerEmpty>\n  <span class=\"text-empty\"> К сожалению, поиск не дал результатов </span>\n</ng-template>\n";
      /***/
    },

    /***/
    "J1eq":
    /*!*********************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product-header/page-product-header.component.html ***!
      \*********************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function J1eq(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"header\">\n  <svg-icon (click)=\"backClick()\" class=\"icon icon__back\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n  <span *ngIf=\"label else skeletonProductHeader\" class=\"header__brand flex-free-space\"> {{ label }} </span>\n  <svg-icon (click)=\"shareClick()\" class=\"icon icon__share\" src=\"assets/icon/svg/share.svg\"></svg-icon>\n</div>\n\n<ng-template #skeletonProductHeader>\n  <ion-skeleton-text animated style=\"width:40%; height: 2.1vh\"></ion-skeleton-text>\n</ng-template>\n";
      /***/
    },

    /***/
    "JJls":
    /*!***********************************************************!*\
      !*** ./src/app/@shared/functions/base64-file.function.ts ***!
      \***********************************************************/

    /*! exports provided: dataURLtoFile, urlToDataUrl */

    /***/
    function JJls(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "dataURLtoFile", function () {
        return dataURLtoFile;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "urlToDataUrl", function () {
        return urlToDataUrl;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");

      function dataURLtoFile(dataUrl) {
        var filename = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'default';
        var arr = dataUrl.split(',');
        var mime = arr[0].match(/:(.*?);/)[1];
        var bstr = atob(arr[1]);
        var n = bstr.length;
        var u8arr = new Uint8Array(n);

        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }

        return new File([u8arr], filename, {
          type: mime
        });
      }

      function urlToDataUrl(imageUrl) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
          var proxy, res, blob;
          return regeneratorRuntime.wrap(function _callee6$(_context6) {
            while (1) {
              switch (_context6.prev = _context6.next) {
                case 0:
                  proxy = 'https://api.codetabs.com/v1/proxy?quest=';
                  _context6.prev = 1;
                  _context6.next = 4;
                  return fetch(imageUrl);

                case 4:
                  res = _context6.sent;
                  _context6.next = 12;
                  break;

                case 7:
                  _context6.prev = 7;
                  _context6.t0 = _context6["catch"](1);
                  _context6.next = 11;
                  return fetch(proxy + imageUrl);

                case 11:
                  res = _context6.sent;

                case 12:
                  _context6.next = 14;
                  return res.blob();

                case 14:
                  blob = _context6.sent;
                  console.log(res);
                  return _context6.abrupt("return", new Promise(function (resolve, reject) {
                    var reader = new FileReader();

                    reader.onload = function () {
                      resolve(reader.result);
                    };

                    reader.readAsDataURL(blob);
                  }));

                case 17:
                case "end":
                  return _context6.stop();
              }
            }
          }, _callee6, null, [[1, 7]]);
        }));
      }
      /***/

    },

    /***/
    "Oemk":
    /*!*********************************************************************************************!*\
      !*** ./src/app/pages/page-product/page-product-buttons/page-product-buttons.component.scss ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function Oemk(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  display: flex;\n  flex-flow: column;\n  gap: 2vh;\n}\n.container .sub-container {\n  display: flex;\n  flex-flow: row;\n  gap: 1.85vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC1idXR0b25zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsUUFBQTtBQUNGO0FBQ0U7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUFDSiIsImZpbGUiOiJwYWdlLXByb2R1Y3QtYnV0dG9ucy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgZ2FwOiAydmg7XG5cbiAgLnN1Yi1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1mbG93OiByb3c7XG4gICAgZ2FwOiAxLjg1dmg7XG4gIH1cbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "PkOX":
    /*!*************************************************************************************!*\
      !*** ./src/app/pages/page-product/page-product-info/page-product-info.component.ts ***!
      \*************************************************************************************/

    /*! exports provided: PageProductInfoComponent */

    /***/
    function PkOX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageProductInfoComponent", function () {
        return PageProductInfoComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_product_info_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-product-info.component.html */
      "n87u");
      /* harmony import */


      var _page_product_info_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-product-info.component.scss */
      "v1AG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var PageProductInfoComponent = /*#__PURE__*/function () {
        function PageProductInfoComponent() {
          _classCallCheck(this, PageProductInfoComponent);

          this.data = null;
        }

        _createClass(PageProductInfoComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return PageProductInfoComponent;
      }();

      PageProductInfoComponent.ctorParameters = function () {
        return [];
      };

      PageProductInfoComponent.propDecorators = {
        data: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      PageProductInfoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-product-info',
        template: _raw_loader_page_product_info_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_product_info_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageProductInfoComponent);
      /***/
    },

    /***/
    "VS1G":
    /*!*******************************************************************************************!*\
      !*** ./src/app/pages/page-product/page-product-buttons/page-product-buttons.component.ts ***!
      \*******************************************************************************************/

    /*! exports provided: PageProductButtonsComponent */

    /***/
    function VS1G(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageProductButtonsComponent", function () {
        return PageProductButtonsComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_product_buttons_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-product-buttons.component.html */
      "WqHo");
      /* harmony import */


      var _page_product_buttons_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-product-buttons.component.scss */
      "Oemk");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @capacitor/core */
      "gcOT");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var Browser = _capacitor_core__WEBPACK_IMPORTED_MODULE_3__["Plugins"].Browser;

      var PageProductButtonsComponent = /*#__PURE__*/function () {
        function PageProductButtonsComponent(navCtrl) {
          _classCallCheck(this, PageProductButtonsComponent);

          this.navCtrl = navCtrl;
          this.mainScreenUrl = '/main';
          this.shopUrl = null;
          this.modalController = null;
        }

        _createClass(PageProductButtonsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "goToMainScreen",
          value: function goToMainScreen() {
            var _a;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      _context7.next = 2;
                      return this.navCtrl.navigateRoot(this.mainScreenUrl);

                    case 2:
                      _context7.next = 4;
                      return (_a = this.modalController) === null || _a === void 0 ? void 0 : _a.dismiss();

                    case 4:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }, {
          key: "openShopUrl",
          value: function openShopUrl() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
              return regeneratorRuntime.wrap(function _callee8$(_context8) {
                while (1) {
                  switch (_context8.prev = _context8.next) {
                    case 0:
                      _context8.next = 2;
                      return Browser.open({
                        url: this.shopUrl
                      });

                    case 2:
                    case "end":
                      return _context8.stop();
                  }
                }
              }, _callee8, this);
            }));
          }
        }]);

        return PageProductButtonsComponent;
      }();

      PageProductButtonsComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
        }];
      };

      PageProductButtonsComponent.propDecorators = {
        shopUrl: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        modalController: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }]
      };
      PageProductButtonsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-page-product-buttons',
        template: _raw_loader_page_product_buttons_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_product_buttons_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageProductButtonsComponent);
      /***/
    },

    /***/
    "WqHo":
    /*!***********************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product-buttons/page-product-buttons.component.html ***!
      \***********************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function WqHo(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ng-container *ngIf=\"shopUrl; else skeletonPageButtons\">\n  <div class=\"container\">\n    <app-shared-button (click)=\"openShopUrl()\" type=\"main\" style=\"width: 100%\">\n      Перейти в магазин\n    </app-shared-button>\n    <div class=\"sub-container\">\n      <app-shared-button (click)=\"goToMainScreen()\" type=\"main-sub\" style=\"width: 100%\">\n        На главный экран\n      </app-shared-button>\n    </div>\n  </div>\n</ng-container>\n\n<ng-template #skeletonPageButtons>\n  <div class=\"container\">\n    <app-shared-button type=\"skeleton\" style=\"width: 100%\"></app-shared-button>\n    <div class=\"sub-container\">\n      <app-shared-button type=\"skeleton\" style=\"width: 100%\"></app-shared-button>\n    </div>\n  </div>\n</ng-template>\n";
      /***/
    },

    /***/
    "Zveh":
    /*!*******************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product-price/page-product-price.component.html ***!
      \*******************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Zveh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"titles-container\" *ngIf=\"data; else skeletonProductPrice\">\n  <div class=\"title__brand\">\n    <span> {{ data?.brand || 'Brand' }} </span>\n    <svg-icon class=\"favorite\" [class.favorite__active]=\"data.isFavorite\" (click)=\"favouriteClickButton()\" src=\"assets/icon/svg/like.svg\"></svg-icon>\n  </div>\n  <div class=\"title__type\"> {{ data?.type || '---' }} </div>\n  <div class=\"title__price\">\n    <ng-container *ngIf=\"data?.oldPrice; else productPriceNormal\">\n      <span class=\"title__price__old\"> {{ (data?.oldPrice || 0) | number : '' : 'fr' }} ₽ </span>\n      <span class=\"title__price__sale\"> {{ (data?.price || 0) | number : '' : 'fr' }} ₽ </span>\n    </ng-container>\n    <ng-template #productPriceNormal>\n      <span class=\"title__price__normal\"> {{ (data?.price || 0) | number : '' : 'fr' }} ₽ </span>\n    </ng-template>\n  </div>\n</div>\n\n<ng-template #skeletonProductPrice>\n  <div class=\"titles-container\">\n    <div class=\"title__brand\">\n      <ion-skeleton-text animated style=\"width:40%; height: 3vh\"></ion-skeleton-text>\n    </div>\n    <ion-skeleton-text animated style=\"width:60%; height: 1.97vh\"></ion-skeleton-text>\n    <div class=\"title__price\">\n      <ion-skeleton-text animated style=\"width:70%; height: 2.9vh\"></ion-skeleton-text>\n    </div>\n  </div>\n</ng-template>\n";
      /***/
    },

    /***/
    "bimA":
    /*!***************************************************************************************!*\
      !*** ./src/app/pages/page-product/page-product-price/page-product-price.component.ts ***!
      \***************************************************************************************/

    /*! exports provided: PageProductPriceComponent */

    /***/
    function bimA(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageProductPriceComponent", function () {
        return PageProductPriceComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_product_price_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-product-price.component.html */
      "Zveh");
      /* harmony import */


      var _page_product_price_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-product-price.component.scss */
      "sHuU");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var PageProductPriceComponent = /*#__PURE__*/function () {
        function PageProductPriceComponent() {
          _classCallCheck(this, PageProductPriceComponent);

          this.data = null;
          this.favouriteClick = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        }

        _createClass(PageProductPriceComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "favouriteClickButton",
          value: function favouriteClickButton() {
            this.favouriteClick.emit();
          }
        }]);

        return PageProductPriceComponent;
      }();

      PageProductPriceComponent.ctorParameters = function () {
        return [];
      };

      PageProductPriceComponent.propDecorators = {
        data: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        favouriteClick: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      PageProductPriceComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-product-price',
        template: _raw_loader_page_product_price_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_product_price_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageProductPriceComponent);
      /***/
    },

    /***/
    "gVPk":
    /*!****************************************************************!*\
      !*** ./src/app/pages/page-product/page-product.component.scss ***!
      \****************************************************************/

    /*! exports provided: default */

    /***/
    function gVPk(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  padding: 3.7vh 0 0 0;\n  box-sizing: border-box;\n  background: #FFFFFF;\n  overflow: hidden;\n  gap: 2.37vh;\n}\n.container .scroll-wrapper {\n  flex-grow: 1;\n  overflow: auto;\n  padding: 0 2.46vh;\n}\n.container .img-container {\n  height: 55.54vh;\n  margin: 0 -2.46vh;\n  background: #DCE0EB;\n}\n.container .image {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0FBREY7QUFHRTtFQUNFLFlBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFESjtBQUlFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFGSjtBQUtFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBSEoiLCJmaWxlIjoicGFnZS1wcm9kdWN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJHBhZGRpbmctdzogMi40NnZoO1xuXG4uY29udGFpbmVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIHBhZGRpbmc6IDMuN3ZoIDAgMCAwO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBiYWNrZ3JvdW5kOiAjRkZGRkZGO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBnYXA6IDIuMzd2aDtcblxuICAuc2Nyb2xsLXdyYXBwZXIge1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBvdmVyZmxvdzogYXV0bztcbiAgICBwYWRkaW5nOiAwICRwYWRkaW5nLXc7XG4gIH1cblxuICAuaW1nLWNvbnRhaW5lciB7XG4gICAgaGVpZ2h0OiA1NS41NHZoO1xuICAgIG1hcmdpbjogMCAoLSRwYWRkaW5nLXcpO1xuICAgIGJhY2tncm91bmQ6ICNEQ0UwRUI7XG4gIH1cblxuICAuaW1hZ2Uge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgfVxufVxuIl19 */";
      /***/
    },

    /***/
    "lAEh":
    /*!*****************************************************************!*\
      !*** ./src/app/@core/services/platform/mobile-share.service.ts ***!
      \*****************************************************************/

    /*! exports provided: MobileShareService */

    /***/
    function lAEh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MobileShareService", function () {
        return MobileShareService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @capacitor/core */
      "gcOT");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var Share = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].Share;

      var MobileShareService = /*#__PURE__*/function () {
        function MobileShareService(platform) {
          _classCallCheck(this, MobileShareService);

          this.platform = platform;
        }

        _createClass(MobileShareService, [{
          key: "shareApp",
          value: function shareApp() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
              var androidUrl;
              return regeneratorRuntime.wrap(function _callee9$(_context9) {
                while (1) {
                  switch (_context9.prev = _context9.next) {
                    case 0:
                      androidUrl = 'https://play.google.com/store/apps/details?id=com.luc.app';
                      this.shareData('LUC', "\u041F\u0440\u0438\u0432\u0435\u0442! \u0425\u043E\u0447\u0435\u0448\u044C \u043D\u0430\u0439\u0442\u0438 \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0443\u044E \u0442\u0435\u0431\u0435 \u043E\u0434\u0435\u0436\u0434\u0443 \u0438 \u0441\u0442\u0438\u043B\u044C, \u0442\u043E\u0433\u0434\u0430 \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u0439 \u0441\u043A\u043E\u0440\u0435\u0435 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 LUC: Android - ".concat(androidUrl, ", iOS - \u0443\u0436\u0435 \u0441\u043A\u043E\u0440\u043E"));

                    case 2:
                    case "end":
                      return _context9.stop();
                  }
                }
              }, _callee9, this);
            }));
          }
        }, {
          key: "shareData",
          value: function shareData(title, text) {
            var url = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
            this.share({
              title: title,
              text: text,
              url: url,
              dialogTitle: title
            }).then();
          }
        }, {
          key: "share",
          value: function share(options) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
              var shareRes;
              return regeneratorRuntime.wrap(function _callee10$(_context10) {
                while (1) {
                  switch (_context10.prev = _context10.next) {
                    case 0:
                      if (!(this.platform.is('android') || this.platform.is('ios'))) {
                        _context10.next = 6;
                        break;
                      }

                      _context10.next = 3;
                      return Share.share(options);

                    case 3:
                      shareRes = _context10.sent;
                      _context10.next = 7;
                      break;

                    case 6:
                      console.warn('your system not supported');

                    case 7:
                    case "end":
                      return _context10.stop();
                  }
                }
              }, _callee10, this);
            }));
          }
        }]);

        return MobileShareService;
      }();

      MobileShareService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]
        }];
      };

      MobileShareService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], MobileShareService);
      /***/
    },

    /***/
    "mVaD":
    /*!****************************************************!*\
      !*** ./src/app/@shared/classes/favorites.class.ts ***!
      \****************************************************/

    /*! exports provided: FavoritesController */

    /***/
    function mVaD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FavoritesController", function () {
        return FavoritesController;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");

      var FavoritesController = /*#__PURE__*/function () {
        function FavoritesController(apiUserService) {
          _classCallCheck(this, FavoritesController);

          this.apiUserService = apiUserService;
          this.isLoading = false;
        }

        _createClass(FavoritesController, [{
          key: "setFavourite",
          value: function setFavourite(id, isFavorite) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
              return regeneratorRuntime.wrap(function _callee11$(_context11) {
                while (1) {
                  switch (_context11.prev = _context11.next) {
                    case 0:
                      if (!this.isLoading) {
                        _context11.next = 2;
                        break;
                      }

                      return _context11.abrupt("return", !isFavorite);

                    case 2:
                      this.isLoading = true;
                      _context11.prev = 3;

                      if (!isFavorite) {
                        _context11.next = 10;
                        break;
                      }

                      _context11.next = 7;
                      return this.addFavourite(id);

                    case 7:
                      return _context11.abrupt("return", true);

                    case 10:
                      _context11.next = 12;
                      return this.deleteFavourite(id);

                    case 12:
                      return _context11.abrupt("return", false);

                    case 13:
                      _context11.next = 19;
                      break;

                    case 15:
                      _context11.prev = 15;
                      _context11.t0 = _context11["catch"](3);
                      console.error('setFavourite', _context11.t0);
                      return _context11.abrupt("return", isFavorite);

                    case 19:
                      _context11.prev = 19;
                      this.isLoading = false;
                      return _context11.finish(19);

                    case 22:
                    case "end":
                      return _context11.stop();
                  }
                }
              }, _callee11, this, [[3, 15, 19, 22]]);
            }));
          }
        }, {
          key: "addFavourite",
          value: function addFavourite(id) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
              var res;
              return regeneratorRuntime.wrap(function _callee12$(_context12) {
                while (1) {
                  switch (_context12.prev = _context12.next) {
                    case 0:
                      _context12.next = 2;
                      return this.apiUserService.addFavorites(id);

                    case 2:
                      res = _context12.sent;
                      return _context12.abrupt("return", res === null || res === void 0 ? void 0 : res.feed);

                    case 4:
                    case "end":
                      return _context12.stop();
                  }
                }
              }, _callee12, this);
            }));
          }
        }, {
          key: "deleteFavourite",
          value: function deleteFavourite(id) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
              var res;
              return regeneratorRuntime.wrap(function _callee13$(_context13) {
                while (1) {
                  switch (_context13.prev = _context13.next) {
                    case 0:
                      _context13.next = 2;
                      return this.apiUserService.deleteFavorites(id);

                    case 2:
                      res = _context13.sent;
                      return _context13.abrupt("return", res);

                    case 4:
                    case "end":
                      return _context13.stop();
                  }
                }
              }, _callee13, this);
            }));
          }
        }]);

        return FavoritesController;
      }();
      /***/

    },

    /***/
    "n87u":
    /*!*****************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-product/page-product-info/page-product-info.component.html ***!
      \*****************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function n87u(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ng-container *ngIf=\"data; else skeletonProductInfo\">\n  <div class=\"container\">\n    <span class=\"label\"> О товаре </span>\n    <p class=\"list\">\n      <ng-container *ngFor=\"let li of data\">\n        {{ li?.title || '-' }}: <b>{{ li?.value || '-' }}</b> <br>\n      </ng-container>\n    </p>\n  </div>\n</ng-container>\n\n<ng-template #skeletonProductInfo>\n  <div class=\"container\">\n    <span class=\"label\">\n      <ion-skeleton-text animated style=\"width:40%; height: 2.9vh\"></ion-skeleton-text>\n    </span>\n    <p class=\"list\">\n      <ion-skeleton-text animated style=\"width:80%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:90%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:70%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:80%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:60%; height: 1.97vh\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width:70%; height: 1.97vh\"></ion-skeleton-text>\n    </p>\n  </div>\n</ng-template>\n";
      /***/
    },

    /***/
    "p0lb":
    /*!***************************************************************!*\
      !*** ./src/app/@core/services/api/api-recognition.service.ts ***!
      \***************************************************************/

    /*! exports provided: ApiRecognitionService */

    /***/
    function p0lb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiRecognitionService", function () {
        return ApiRecognitionService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../platform/app-config.service */
      "ophu");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../@shared/functions/base64-file.function */
      "JJls");

      var ApiRecognitionService = /*#__PURE__*/function () {
        function ApiRecognitionService(appConfigService, http) {
          _classCallCheck(this, ApiRecognitionService);

          this.http = http;
          this.restUrl = appConfigService.recognitionUrl;
        }

        _createClass(ApiRecognitionService, [{
          key: "getMainRecommends",
          value: function getMainRecommends() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
              var url;
              return regeneratorRuntime.wrap(function _callee14$(_context14) {
                while (1) {
                  switch (_context14.prev = _context14.next) {
                    case 0:
                      _context14.prev = 0;
                      url = "".concat(this.restUrl, "/api/MainScreen/feeds");
                      _context14.next = 4;
                      return this.http.get(url).toPromise();

                    case 4:
                      return _context14.abrupt("return", _context14.sent);

                    case 7:
                      _context14.prev = 7;
                      _context14.t0 = _context14["catch"](0);
                      console.error('getMainRecommends', _context14.t0);
                      return _context14.abrupt("return", []);

                    case 11:
                    case "end":
                      return _context14.stop();
                  }
                }
              }, _callee14, this, [[0, 7]]);
            }));
          }
        }, {
          key: "getStartScreenReco",
          value: function getStartScreenReco(gender) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
              return regeneratorRuntime.wrap(function _callee15$(_context15) {
                while (1) {
                  switch (_context15.prev = _context15.next) {
                    case 0:
                      _context15.prev = 0;
                      _context15.next = 3;
                      return this.http.get("".concat(this.restUrl, "/api/StartScreenReco?gender=").concat(gender)).toPromise();

                    case 3:
                      return _context15.abrupt("return", _context15.sent);

                    case 6:
                      _context15.prev = 6;
                      _context15.t0 = _context15["catch"](0);
                      console.error('getStartScreenReco', _context15.t0);
                      return _context15.abrupt("return", []);

                    case 10:
                    case "end":
                      return _context15.stop();
                  }
                }
              }, _callee15, this, [[0, 6]]);
            }));
          }
        }, {
          key: "searchByPhoto",
          value: function searchByPhoto(dataUrl) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
              var imgFile, body;
              return regeneratorRuntime.wrap(function _callee16$(_context16) {
                while (1) {
                  switch (_context16.prev = _context16.next) {
                    case 0:
                      imgFile = Object(_shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_4__["dataURLtoFile"])(dataUrl);
                      body = new FormData();
                      body.append('imageFile', imgFile, imgFile.name);
                      _context16.prev = 3;
                      _context16.next = 6;
                      return this.http.post("".concat(this.restUrl, "/api/Reco"), body).toPromise();

                    case 6:
                      return _context16.abrupt("return", _context16.sent);

                    case 9:
                      _context16.prev = 9;
                      _context16.t0 = _context16["catch"](3);
                      console.error('searchByPhoto', _context16.t0);
                      return _context16.abrupt("return", null);

                    case 13:
                    case "end":
                      return _context16.stop();
                  }
                }
              }, _callee16, this, [[3, 9]]);
            }));
          }
        }, {
          key: "searchByDot",
          value: function searchByDot(searchId, dot) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
              return regeneratorRuntime.wrap(function _callee17$(_context17) {
                while (1) {
                  switch (_context17.prev = _context17.next) {
                    case 0:
                      _context17.prev = 0;
                      _context17.next = 3;
                      return this.http.post("".concat(this.restUrl, "/api/Reco/search/").concat(searchId), dot).toPromise();

                    case 3:
                      return _context17.abrupt("return", _context17.sent);

                    case 6:
                      _context17.prev = 6;
                      _context17.t0 = _context17["catch"](0);
                      console.error('searchByDot', _context17.t0);
                      return _context17.abrupt("return", null);

                    case 10:
                    case "end":
                      return _context17.stop();
                  }
                }
              }, _callee17, this, [[0, 6]]);
            }));
          }
        }, {
          key: "searchByText",
          value: function searchByText(search) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee18() {
              return regeneratorRuntime.wrap(function _callee18$(_context18) {
                while (1) {
                  switch (_context18.prev = _context18.next) {
                    case 0:
                      _context18.prev = 0;
                      _context18.next = 3;
                      return this.http.get("".concat(this.restUrl, "/api/Text?query=").concat(search)).toPromise();

                    case 3:
                      return _context18.abrupt("return", _context18.sent);

                    case 6:
                      _context18.prev = 6;
                      _context18.t0 = _context18["catch"](0);
                      console.error('searchByText', _context18.t0);
                      return _context18.abrupt("return", null);

                    case 10:
                    case "end":
                      return _context18.stop();
                  }
                }
              }, _callee18, this, [[0, 6]]);
            }));
          }
        }, {
          key: "getFullItem",
          value: function getFullItem(id) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee19() {
              var url;
              return regeneratorRuntime.wrap(function _callee19$(_context19) {
                while (1) {
                  switch (_context19.prev = _context19.next) {
                    case 0:
                      _context19.prev = 0;
                      url = "".concat(this.restUrl, " /api/Reco/feed/").concat(id);
                      _context19.next = 4;
                      return this.http.get("".concat(this.restUrl, "/api/Reco/feed/").concat(id)).toPromise();

                    case 4:
                      return _context19.abrupt("return", _context19.sent);

                    case 7:
                      _context19.prev = 7;
                      _context19.t0 = _context19["catch"](0);
                      console.error('getFullItem', _context19.t0);
                      return _context19.abrupt("return", null);

                    case 11:
                    case "end":
                      return _context19.stop();
                  }
                }
              }, _callee19, this, [[0, 7]]);
            }));
          }
        }]);

        return ApiRecognitionService;
      }();

      ApiRecognitionService.ctorParameters = function () {
        return [{
          type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
        }];
      };

      ApiRecognitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ApiRecognitionService);
      /***/
    },

    /***/
    "sHuU":
    /*!*****************************************************************************************!*\
      !*** ./src/app/pages/page-product/page-product-price/page-product-price.component.scss ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function sHuU(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".titles-container {\n  margin: 2.95vh 0 4.92vh 0;\n  display: flex;\n  flex-flow: column;\n}\n.titles-container .title__brand {\n  display: flex;\n  justify-content: space-between;\n  font-size: 2.96vh;\n  font-weight: 700;\n  color: #2F3441;\n  margin-bottom: 0.62vh;\n}\n.titles-container .title__brand .favorite {\n  width: 2.46vh;\n  height: 2.46vh;\n  color: #99A0AB;\n}\n.titles-container .title__brand .favorite__active {\n  color: #FF3B30;\n}\n.titles-container .title__type {\n  font-size: 1.97vh;\n  font-weight: 400;\n  color: #6B7683;\n  margin-bottom: 1.72vh;\n}\n.titles-container .title__price {\n  font-size: 2.96vh;\n  font-weight: 700;\n}\n.titles-container .title__price__old {\n  font-size: 1.97vh;\n  font-weight: 500;\n  color: #6B7683;\n  -webkit-text-decoration-line: line-through;\n          text-decoration-line: line-through;\n}\n.titles-container .title__price__sale {\n  color: #3A83F1;\n}\n.titles-container .title__price__normal {\n  color: #202D3D;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC1wcmljZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBQ0Y7QUFHSTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EscUJBQUE7QUFETjtBQUdNO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0FBRFI7QUFHUTtFQUNFLGNBQUE7QUFEVjtBQU1JO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtBQUpOO0FBT0k7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0FBTE47QUFPTTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsMENBQUE7VUFBQSxrQ0FBQTtBQUxSO0FBUU07RUFDRSxjQUFBO0FBTlI7QUFTTTtFQUNFLGNBQUE7QUFQUiIsImZpbGUiOiJwYWdlLXByb2R1Y3QtcHJpY2UuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGl0bGVzLWNvbnRhaW5lciB7XG4gIG1hcmdpbjogMi45NXZoIDAgNC45MnZoIDA7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuXG4gIC50aXRsZSB7XG5cbiAgICAmX19icmFuZCB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgZm9udC1zaXplOiAyLjk2dmg7XG4gICAgICBmb250LXdlaWdodDogNzAwO1xuICAgICAgY29sb3I6ICMyRjM0NDE7XG4gICAgICBtYXJnaW4tYm90dG9tOiAwLjYydmg7XG5cbiAgICAgIC5mYXZvcml0ZSB7XG4gICAgICAgIHdpZHRoOiAyLjQ2dmg7XG4gICAgICAgIGhlaWdodDogMi40NnZoO1xuICAgICAgICBjb2xvcjogIzk5QTBBQjtcblxuICAgICAgICAmX19hY3RpdmUge1xuICAgICAgICAgIGNvbG9yOiAjRkYzQjMwO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgJl9fdHlwZSB7XG4gICAgICBmb250LXNpemU6IDEuOTd2aDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICBjb2xvcjogIzZCNzY4MztcbiAgICAgIG1hcmdpbi1ib3R0b206IDEuNzJ2aDtcbiAgICB9XG5cbiAgICAmX19wcmljZSB7XG4gICAgICBmb250LXNpemU6IDIuOTZ2aDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG5cbiAgICAgICZfX29sZCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICBjb2xvcjogIzZCNzY4MztcbiAgICAgICAgdGV4dC1kZWNvcmF0aW9uLWxpbmU6IGxpbmUtdGhyb3VnaDtcbiAgICAgIH1cblxuICAgICAgJl9fc2FsZSB7XG4gICAgICAgIGNvbG9yOiAjM0E4M0YxO1xuICAgICAgfVxuXG4gICAgICAmX19ub3JtYWwge1xuICAgICAgICBjb2xvcjogIzIwMkQzRDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "u7xx":
    /*!*****************************************************************************************!*\
      !*** ./src/app/pages/page-product/page-product-header/page-product-header.component.ts ***!
      \*****************************************************************************************/

    /*! exports provided: PageProductHeaderComponent */

    /***/
    function u7xx(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageProductHeaderComponent", function () {
        return PageProductHeaderComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_product_header_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-product-header.component.html */
      "J1eq");
      /* harmony import */


      var _page_product_header_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-product-header.component.scss */
      "9jac");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var PageProductHeaderComponent = /*#__PURE__*/function () {
        function PageProductHeaderComponent() {
          _classCallCheck(this, PageProductHeaderComponent);

          this.label = null;
          this.back = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.share = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        }

        _createClass(PageProductHeaderComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "backClick",
          value: function backClick() {
            this.back.emit();
          }
        }, {
          key: "shareClick",
          value: function shareClick() {
            this.share.emit();
          }
        }]);

        return PageProductHeaderComponent;
      }();

      PageProductHeaderComponent.ctorParameters = function () {
        return [];
      };

      PageProductHeaderComponent.propDecorators = {
        label: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        back: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        share: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      PageProductHeaderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-product-header',
        template: _raw_loader_page_product_header_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_product_header_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageProductHeaderComponent);
      /***/
    },

    /***/
    "v1AG":
    /*!***************************************************************************************!*\
      !*** ./src/app/pages/page-product/page-product-info/page-product-info.component.scss ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function v1AG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  margin-top: 3.94vh;\n}\n.container .label {\n  font-size: 2.95vh;\n  font-weight: 700;\n  color: #2F3441;\n}\n.container .list {\n  color: black;\n  line-height: 2.95vh;\n  font-size: 1.97vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJvZHVjdC1pbmZvLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7QUFDRjtBQUNFO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFDSjtBQUVFO0VBQ0UsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFBSiIsImZpbGUiOiJwYWdlLXByb2R1Y3QtaW5mby5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBtYXJnaW4tdG9wOiAzLjk0dmg7XG5cbiAgLmxhYmVsIHtcbiAgICBmb250LXNpemU6IDIuOTV2aDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGNvbG9yOiAjMkYzNDQxO1xuICB9XG5cbiAgLmxpc3Qge1xuICAgIGNvbG9yOiBibGFjaztcbiAgICBsaW5lLWhlaWdodDogMi45NXZoO1xuICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICB9XG59XG4iXX0= */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee-es5.js.map