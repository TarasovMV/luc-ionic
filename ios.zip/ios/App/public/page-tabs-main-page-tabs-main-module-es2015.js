(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["page-tabs-main-page-tabs-main-module"],{

/***/ "+mQK":
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-camera/page-tabs-main-camera.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: PageTabsMainCameraComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsMainCameraComponent", function() { return PageTabsMainCameraComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_main_camera_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-main-camera.component.html */ "B14K");
/* harmony import */ var _page_tabs_main_camera_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-main-camera.component.scss */ "6IQJ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let PageTabsMainCameraComponent = class PageTabsMainCameraComponent {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
    }
    clickCamera() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.navCtrl.navigateRoot('/main/camera');
        });
    }
};
PageTabsMainCameraComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] }
];
PageTabsMainCameraComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-main-camera',
        template: _raw_loader_page_tabs_main_camera_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_main_camera_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsMainCameraComponent);



/***/ }),

/***/ "6IQJ":
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-camera/page-tabs-main-camera.component.scss ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  width: 5.91vh;\n  height: 5.91vh;\n  padding: 1.6vh 1.6vh 1.81vh 1.6vh;\n  border-radius: 50%;\n  background: #2CB172;\n}\n\n.icon {\n  color: white;\n  width: 100%;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1tYWluLWNhbWVyYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGlDQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQ0YiLCJmaWxlIjoicGFnZS10YWJzLW1haW4tY2FtZXJhLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiA1Ljkxdmg7XG4gIGhlaWdodDogNS45MXZoO1xuICBwYWRkaW5nOiAxLjZ2aCAxLjZ2aCAxLjgxdmggMS42dmg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZDogIzJDQjE3Mjtcbn1cblxuLmljb24ge1xuICBjb2xvcjogd2hpdGU7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG59XG4iXX0= */");

/***/ }),

/***/ "7d0u":
/*!****************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main.component.ts ***!
  \****************************************************************************/
/*! exports provided: PageTabsMainComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsMainComponent", function() { return PageTabsMainComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_main_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-main.component.html */ "hYC4");
/* harmony import */ var _page_tabs_main_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-main.component.scss */ "EVcI");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _page_tabs_main_search_modal_page_tabs_main_search_modal_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./page-tabs-main-search-modal/page-tabs-main-search-modal.component */ "HHte");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../@core/services/user-info.service */ "tTdR");









let PageTabsMainComponent = class PageTabsMainComponent {
    constructor(modalController, recognitionInfoService, userInfoService) {
        this.modalController = modalController;
        this.recognitionInfoService = recognitionInfoService;
        this.userInfoService = userInfoService;
        this.tabName = 'search';
        this.recommends$ = this.recognitionInfoService.recommendCards$;
        this.articles$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["BehaviorSubject"](new Array(2));
    }
    ngOnInit() {
        this.getRecommendCards().then();
        this.getArticles().then();
    }
    ngOnDestroy() {
    }
    getRecommendCards() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.recognitionInfoService.getMainRecommends();
        });
    }
    getArticles() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = yield this.userInfoService.getAllArticles();
            console.log(res);
            this.articles$.next(res);
        });
    }
    presentModalSearch() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _page_tabs_main_search_modal_page_tabs_main_search_modal_component__WEBPACK_IMPORTED_MODULE_5__["PageTabsMainSearchModalComponent"],
            });
            yield modal.present();
        });
    }
};
PageTabsMainComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_6__["RecognitionInfoService"] },
    { type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_8__["UserInfoService"] }
];
PageTabsMainComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-main',
        template: _raw_loader_page_tabs_main_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_main_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsMainComponent);



/***/ }),

/***/ "AthP":
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-article/page-tabs-main-article.component.scss ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".wrapper {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  overflow: hidden;\n}\n.wrapper .header {\n  display: flex;\n  align-items: center;\n  height: 5.42vh;\n  max-height: 5.42vh;\n  min-height: 5.42vh;\n}\n.wrapper .header .close {\n  height: 1.48vh;\n  width: 1.48vh;\n  margin: 0 4.27vw 0 auto;\n  color: #99A0AB;\n}\n.wrapper .container {\n  width: 100%;\n  flex-grow: 1;\n  color: #222222;\n  overflow: auto;\n}\n.wrapper .container .padding {\n  padding: 0 5.3vw;\n}\n.wrapper .container .author {\n  font-size: 1.97vh;\n  margin-bottom: 5vh;\n}\n.wrapper .container .author span {\n  color: #3A83F1;\n}\n.wrapper .container .source {\n  margin-bottom: 1.97vh;\n  font-size: 1.72vh;\n  color: #99A0AB;\n}\n.wrapper .container .title {\n  margin-bottom: 3.94vh;\n  font-size: 2.71vh;\n  font-weight: 700;\n}\n.wrapper .container .subtitle {\n  margin: 3.94vh 0 2.34vh 0;\n  font-size: 2.21vh;\n  font-weight: 700;\n}\n.wrapper .container .text {\n  font-size: 1.97vh;\n  font-weight: 400;\n  color: #546173;\n}\n.wrapper .container .photo-wrapper {\n  height: 57vh;\n  margin-top: 3.94vh;\n  width: 100%;\n  background: #DCE0EB;\n  overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1tYWluLWFydGljbGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBQ0Y7QUFDRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBQ0o7QUFDSTtFQUNFLGNBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0FBQ047QUFHRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7QUFESjtBQUdJO0VBQ0UsZ0JBQUE7QUFETjtBQUlJO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtBQUZOO0FBSU07RUFDRSxjQUFBO0FBRlI7QUFNSTtFQUNFLHFCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBSk47QUFPSTtFQUNFLHFCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUxOO0FBUUk7RUFDRSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFOTjtBQVNJO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFQTjtBQVVJO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFSTiIsImZpbGUiOiJwYWdlLXRhYnMtbWFpbi1hcnRpY2xlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndyYXBwZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICAuaGVhZGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgaGVpZ2h0OiA1LjQydmg7XG4gICAgbWF4LWhlaWdodDogNS40MnZoO1xuICAgIG1pbi1oZWlnaHQ6IDUuNDJ2aDtcblxuICAgIC5jbG9zZSB7XG4gICAgICBoZWlnaHQ6IDEuNDh2aDtcbiAgICAgIHdpZHRoOiAxLjQ4dmg7XG4gICAgICBtYXJnaW46IDAgNC4yN3Z3IDAgYXV0bztcbiAgICAgIGNvbG9yOiAjOTlBMEFCO1xuICAgIH1cbiAgfVxuXG4gIC5jb250YWluZXIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgICBvdmVyZmxvdzogYXV0bztcblxuICAgIC5wYWRkaW5nIHtcbiAgICAgIHBhZGRpbmc6IDAgNS4zdnc7XG4gICAgfVxuXG4gICAgLmF1dGhvciB7XG4gICAgICBmb250LXNpemU6IDEuOTd2aDtcbiAgICAgIG1hcmdpbi1ib3R0b206IDV2aDtcblxuICAgICAgc3BhbiB7XG4gICAgICAgIGNvbG9yOiAjM0E4M0YxO1xuICAgICAgfVxuICAgIH1cblxuICAgIC5zb3VyY2Uge1xuICAgICAgbWFyZ2luLWJvdHRvbTogMS45N3ZoO1xuICAgICAgZm9udC1zaXplOiAxLjcydmg7XG4gICAgICBjb2xvcjogIzk5QTBBQjtcbiAgICB9XG5cbiAgICAudGl0bGUge1xuICAgICAgbWFyZ2luLWJvdHRvbTogMy45NHZoO1xuICAgICAgZm9udC1zaXplOiAyLjcxdmg7XG4gICAgICBmb250LXdlaWdodDogNzAwO1xuICAgIH1cblxuICAgIC5zdWJ0aXRsZSB7XG4gICAgICBtYXJnaW46IDMuOTR2aCAwIDIuMzR2aCAwO1xuICAgICAgZm9udC1zaXplOiAyLjIxdmg7XG4gICAgICBmb250LXdlaWdodDogNzAwO1xuICAgIH1cblxuICAgIC50ZXh0IHtcbiAgICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICAgIGNvbG9yOiAjNTQ2MTczO1xuICAgIH1cblxuICAgIC5waG90by13cmFwcGVyIHtcbiAgICAgIGhlaWdodDogNTd2aDtcbiAgICAgIG1hcmdpbi10b3A6IDMuOTR2aDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgYmFja2dyb3VuZDogI0RDRTBFQjtcbiAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "B14K":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-camera/page-tabs-main-camera.component.html ***!
  \*************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div (click)=\"clickCamera()\" class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect></ion-ripple-effect>\n  <svg-icon class=\"icon\" src=\"assets/icon/svg/photo.svg\"></svg-icon>\n</div>\n\n\n");

/***/ }),

/***/ "EVcI":
/*!******************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main.component.scss ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  padding: 3.7vh 5.33vw 0 5.33vw;\n  box-sizing: border-box;\n  background: white;\n  overflow: scroll;\n}\n\n.logo-wrapper {\n  display: flex;\n}\n\n.logo-wrapper .logo {\n  margin: auto;\n  height: 2.46vh;\n  width: 7.39vh;\n}\n\n.logo-wrapper .logo__icon {\n  color: #001424;\n  width: 100%;\n  height: 100%;\n}\n\n.content {\n  display: flex;\n  flex-flow: column;\n  flex-grow: 1;\n  padding-top: 3.7vh;\n  box-sizing: border-box;\n  gap: 4.93vh;\n}\n\n.content .buttons-container {\n  display: flex;\n  justify-content: center;\n  gap: 2.71vh;\n}\n\n.content .recommend-container {\n  display: flex;\n  flex-flow: column;\n}\n\n.content .recommend-container .cards {\n  display: flex;\n  margin-top: 2.46vh;\n  gap: 1.97vh;\n  overflow: scroll;\n  padding-left: 5.33vw;\n  margin-left: -5.33vw;\n  margin-right: -5.33vw;\n}\n\n.content .recommend-container .cards :last-child {\n  padding-right: 5.33vw;\n}\n\n.content .trend-container {\n  display: flex;\n  flex-flow: column;\n}\n\n.content .trend-container .cards {\n  display: flex;\n  flex-flow: column;\n  margin-top: 2.46vh;\n  gap: 2vh;\n}\n\n.title {\n  margin-bottom: 1.11vh;\n  color: #202D3D;\n  text-align: left;\n  font-size: 2.95vh;\n  font-weight: 700;\n}\n\n.subtitle {\n  text-align: left;\n  color: #6B7683;\n  font-size: 1.97vh;\n  font-weight: 400;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1tYWluLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQURGOztBQUlBO0VBQ0UsYUFBQTtBQURGOztBQUdFO0VBQ0UsWUFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0FBREo7O0FBR0k7RUFDRSxjQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFETjs7QUFNQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtBQUhGOztBQUtFO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtBQUhKOztBQU1FO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0FBSko7O0FBTUk7RUFDRSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFwRE07RUFxRE4sb0JBQUE7RUFDQSxxQkFBQTtBQUpOOztBQU1NO0VBQ0UscUJBekRJO0FBcURaOztBQVNFO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0FBUEo7O0FBU0k7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7QUFQTjs7QUFZQTtFQUNFLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQVRGOztBQVlBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQVRGIiwiZmlsZSI6InBhZ2UtdGFicy1tYWluLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJHBhZGRpbmctdzogNS4zM3Z3O1xuXG4uY29udGFpbmVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIHBhZGRpbmc6IDMuN3ZoICRwYWRkaW5nLXcgMCAkcGFkZGluZy13O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn1cblxuLmxvZ28td3JhcHBlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG5cbiAgLmxvZ28ge1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBoZWlnaHQ6IDIuNDZ2aDtcbiAgICB3aWR0aDogNy4zOXZoO1xuXG4gICAgJl9faWNvbiB7XG4gICAgICBjb2xvcjogIzAwMTQyNDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cbiAgfVxufVxuXG4uY29udGVudCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBmbGV4LWdyb3c6IDE7XG4gIHBhZGRpbmctdG9wOiAzLjd2aDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgZ2FwOiA0Ljkzdmg7XG5cbiAgLmJ1dHRvbnMtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGdhcDogMi43MXZoO1xuICB9XG5cbiAgLnJlY29tbWVuZC1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1mbG93OiBjb2x1bW47XG5cbiAgICAuY2FyZHMge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIG1hcmdpbi10b3A6IDIuNDZ2aDtcbiAgICAgIGdhcDogMS45N3ZoO1xuICAgICAgb3ZlcmZsb3c6IHNjcm9sbDtcbiAgICAgIHBhZGRpbmctbGVmdDogJHBhZGRpbmctdztcbiAgICAgIG1hcmdpbi1sZWZ0OiAtJHBhZGRpbmctdztcbiAgICAgIG1hcmdpbi1yaWdodDogLSRwYWRkaW5nLXc7XG5cbiAgICAgIDpsYXN0LWNoaWxkIHtcbiAgICAgICAgcGFkZGluZy1yaWdodDogJHBhZGRpbmctdztcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAudHJlbmQtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZmxvdzogY29sdW1uO1xuXG4gICAgLmNhcmRzIHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgICAgIG1hcmdpbi10b3A6IDIuNDZ2aDtcbiAgICAgIGdhcDogMnZoO1xuICAgIH1cbiAgfVxufVxuXG4udGl0bGUge1xuICBtYXJnaW4tYm90dG9tOiAxLjExdmg7XG4gIGNvbG9yOiAjMjAyRDNEO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LXNpemU6IDIuOTV2aDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cblxuLnN1YnRpdGxlIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICM2Qjc2ODM7XG4gIGZvbnQtc2l6ZTogMS45N3ZoO1xuICBmb250LXdlaWdodDogNDAwO1xufVxuIl19 */");

/***/ }),

/***/ "EuSP":
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-article/page-tabs-main-article.component.ts ***!
  \***********************************************************************************************************/
/*! exports provided: PageTabsMainArticleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsMainArticleComponent", function() { return PageTabsMainArticleComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_main_article_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-main-article.component.html */ "oNCp");
/* harmony import */ var _page_tabs_main_article_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-main-article.component.scss */ "AthP");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");








let PageTabsMainArticleComponent = class PageTabsMainArticleComponent {
    constructor(http, modalCtrl, params) {
        this.http = http;
        this.modalCtrl = modalCtrl;
        this.params = params;
        this.articleData$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"](null);
        this.sources$ = this.articleData$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["filter"])(x => !!x), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["map"])(x => x.sources.join(', ')));
    }
    set articleJson(value) {
        this.articleData$.next(value);
    }
    ngOnInit() {
        // this.init().then();
    }
    close() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.modalCtrl.dismiss();
        });
    }
    init() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // const res = await this.http.get('assets/article-example.json').toPromise();
            const res = this.params.get('articleJson');
            console.log(res);
            this.articleData$.next(res);
        });
    }
};
PageTabsMainArticleComponent.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavParams"] }
];
PageTabsMainArticleComponent.propDecorators = {
    articleJson: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageTabsMainArticleComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-main-article',
        template: _raw_loader_page_tabs_main_article_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_main_article_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsMainArticleComponent);



/***/ }),

/***/ "FCLQ":
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-search-modal/page-tabs-main-search-modal.component.scss ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  width: 100%;\n  height: 100%;\n  background: #FFFFFF;\n}\n.container .search-container {\n  display: flex;\n  gap: 2vh;\n  padding: 2vh 3vh;\n  box-sizing: border-box;\n  box-shadow: 0px -8px 10px 1px black;\n}\n.container .search-container > * {\n  margin: auto 0;\n}\n.container .search-container .icon {\n  width: 2.43vh;\n  height: 2.43vh;\n}\n.container .search-container .icon__back {\n  color: #41485D;\n}\n.container .search-container .input {\n  font-size: 1.8vh;\n  color: #41485D;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1tYWluLXNlYXJjaC1tb2RhbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFDRjtBQUNFO0VBQ0UsYUFBQTtFQUNBLFFBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUNBQUE7QUFDSjtBQUNJO0VBQ0UsY0FBQTtBQUNOO0FBRUk7RUFDRSxhQUFBO0VBQ0EsY0FBQTtBQUFOO0FBRU07RUFDRSxjQUFBO0FBQVI7QUFJSTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQUZOIiwiZmlsZSI6InBhZ2UtdGFicy1tYWluLXNlYXJjaC1tb2RhbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kOiAjRkZGRkZGO1xuXG4gIC5zZWFyY2gtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGdhcDogMnZoO1xuICAgIHBhZGRpbmc6IDJ2aCAzdmg7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBib3gtc2hhZG93OiAwcHggLThweCAxMHB4IDFweCBibGFjaztcblxuICAgICYgPiAqIHtcbiAgICAgIG1hcmdpbjogYXV0byAwO1xuICAgIH1cblxuICAgIC5pY29uIHtcbiAgICAgIHdpZHRoOiAyLjQzdmg7XG4gICAgICBoZWlnaHQ6IDIuNDN2aDtcblxuICAgICAgJl9fYmFjayB7XG4gICAgICAgIGNvbG9yOiAjNDE0ODVEO1xuICAgICAgfVxuICAgIH1cblxuICAgIC5pbnB1dCB7XG4gICAgICBmb250LXNpemU6IDEuOHZoO1xuICAgICAgY29sb3I6ICM0MTQ4NUQ7XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "FQ/J":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-search/page-tabs-main-search.component.html ***!
  \*************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div id=\"123\" class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect></ion-ripple-effect>\n  <svg-icon class=\"icon\" src=\"assets/icon/svg/search.svg\"></svg-icon>\n  <span class=\"label\"> Поиск по вашему запросу </span>\n</div>\n");

/***/ }),

/***/ "HHte":
/*!*********************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-search-modal/page-tabs-main-search-modal.component.ts ***!
  \*********************************************************************************************************************/
/*! exports provided: PageTabsMainSearchModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsMainSearchModalComponent", function() { return PageTabsMainSearchModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_main_search_modal_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-main-search-modal.component.html */ "e7Fz");
/* harmony import */ var _page_tabs_main_search_modal_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-main-search-modal.component.scss */ "FCLQ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../@core/services/api/api-recognition.service */ "p0lb");







let PageTabsMainSearchModalComponent = class PageTabsMainSearchModalComponent {
    constructor(navCtrl, modalCtrl, recognitionInfoService, apiRecognitionService) {
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.recognitionInfoService = recognitionInfoService;
        this.apiRecognitionService = apiRecognitionService;
        this.nextRouteUrl = '/main/scan';
    }
    ngAfterViewInit() {
        setTimeout(() => this.searchInput.setFocus(), 1000);
    }
    search() {
        const search = this.searchInput.value.toString();
        this.recognitionInfoService.recognitionSaveFunction = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = yield this.apiRecognitionService.searchByText(search);
            return this.recognitionInfoService.textResultMapper(res);
        });
        this.navCtrl.navigateRoot(this.nextRouteUrl).then();
        this.close().then();
    }
    close() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.modalCtrl.dismiss();
        });
    }
};
PageTabsMainSearchModalComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_5__["RecognitionInfoService"] },
    { type: _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_6__["ApiRecognitionService"] }
];
PageTabsMainSearchModalComponent.propDecorators = {
    searchInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['searchInput',] }]
};
PageTabsMainSearchModalComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-main-search-modal',
        template: _raw_loader_page_tabs_main_search_modal_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_main_search_modal_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsMainSearchModalComponent);



/***/ }),

/***/ "Tlwu":
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-search/page-tabs-main-search.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: PageTabsMainSearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsMainSearchComponent", function() { return PageTabsMainSearchComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_main_search_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-main-search.component.html */ "FQ/J");
/* harmony import */ var _page_tabs_main_search_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-main-search.component.scss */ "XNDu");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PageTabsMainSearchComponent = class PageTabsMainSearchComponent {
    constructor() {
    }
    ngOnInit() {
    }
};
PageTabsMainSearchComponent.ctorParameters = () => [];
PageTabsMainSearchComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-main-search',
        template: _raw_loader_page_tabs_main_search_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_main_search_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsMainSearchComponent);



/***/ }),

/***/ "UxYo":
/*!*************************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-recommend-card/page-tabs-main-recommend-card.component.ts ***!
  \*************************************************************************************************************************/
/*! exports provided: PageTabsMainRecommendCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsMainRecommendCardComponent", function() { return PageTabsMainRecommendCardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_main_recommend_card_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-main-recommend-card.component.html */ "jzfM");
/* harmony import */ var _page_tabs_main_recommend_card_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-main-recommend-card.component.scss */ "rL5x");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../page-product/page-product.component */ "8jGz");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../@core/services/api/api-recognition.service */ "p0lb");








let PageTabsMainRecommendCardComponent = class PageTabsMainRecommendCardComponent {
    constructor(recognitionInfoService, apiRecognitionService, modalController) {
        this.recognitionInfoService = recognitionInfoService;
        this.apiRecognitionService = apiRecognitionService;
        this.modalController = modalController;
        this.data = null;
    }
    ngOnInit() { }
    openProduct() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const productId = this.data.id;
            if (!productId) {
                return;
            }
            this.recognitionInfoService.recognitionFeedFunction = () => this.apiRecognitionService.getFullItem(productId);
            yield this.presentModalInfo();
        });
    }
    presentModalInfo() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_4__["PageProductComponent"],
            });
            return yield modal.present();
        });
    }
};
PageTabsMainRecommendCardComponent.ctorParameters = () => [
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_5__["RecognitionInfoService"] },
    { type: _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_7__["ApiRecognitionService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] }
];
PageTabsMainRecommendCardComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageTabsMainRecommendCardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-main-recommend-card',
        template: _raw_loader_page_tabs_main_recommend_card_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_main_recommend_card_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsMainRecommendCardComponent);



/***/ }),

/***/ "XNDu":
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-search/page-tabs-main-search.component.scss ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  gap: 1.23vh;\n  width: inherit;\n  height: 5.91vh;\n  padding: 0 1.85vh;\n  border-radius: 4.43vh;\n  background: #F3F7FA;\n}\n\n.icon {\n  width: 2.22vh;\n  height: 2.22vh;\n  margin: auto 0;\n  color: #41485D;\n}\n\n.label {\n  margin: auto 0;\n  color: #6B7683;\n  font-size: 1.48vh;\n  font-weight: 400;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1tYWluLXNlYXJjaC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUNGIiwiZmlsZSI6InBhZ2UtdGFicy1tYWluLXNlYXJjaC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBnYXA6IDEuMjN2aDtcbiAgd2lkdGg6IGluaGVyaXQ7XG4gIGhlaWdodDogNS45MXZoO1xuICBwYWRkaW5nOiAwIDEuODV2aDtcbiAgYm9yZGVyLXJhZGl1czogNC40M3ZoO1xuICBiYWNrZ3JvdW5kOiAjRjNGN0ZBO1xufVxuXG4uaWNvbiB7XG4gIHdpZHRoOiAyLjIydmg7XG4gIGhlaWdodDogMi4yMnZoO1xuICBtYXJnaW46IGF1dG8gMDtcbiAgY29sb3I6ICM0MTQ4NUQ7XG59XG5cbi5sYWJlbCB7XG4gIG1hcmdpbjogYXV0byAwO1xuICBjb2xvcjogIzZCNzY4MztcbiAgZm9udC1zaXplOiAxLjQ4dmg7XG4gIGZvbnQtd2VpZ2h0OiA0MDA7XG59XG4iXX0= */");

/***/ }),

/***/ "cdwp":
/*!*********************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-trend-card/page-tabs-main-trend-card.component.html ***!
  \*********************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"content\">\n  <ng-container *ngIf=\"!!data; else skeleton\">\n    <div (click)=\"presentModalArticle()\" class=\"image\"> <img [src]=\"data.imageUrl\"> </div>\n    <div (click)=\"presentModalArticle()\" class=\"label\">\n      <span> {{data.title}} </span>\n    </div>\n  </ng-container>\n  <ng-template #skeleton>\n    <div class=\"image\"></div>\n    <div class=\"label\">\n      <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n      <ion-skeleton-text animated style=\"width: 70%\"></ion-skeleton-text>\n    </div>\n  </ng-template>\n</div>\n");

/***/ }),

/***/ "e7Fz":
/*!*************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-search-modal/page-tabs-main-search-modal.component.html ***!
  \*************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"search-container\">\n    <svg-icon class=\"icon icon__back\" src=\"assets/icon/svg/back.svg\" (click)=\"close()\"></svg-icon>\n    <ion-input\n      #searchInput\n      class=\"input\"\n      placeholder=\"Введите поисковый запрос...\"\n      type=\"search\"\n      (search)=\"search()\">\n    </ion-input>\n  </div>\n</div>\n");

/***/ }),

/***/ "gU5r":
/*!*****************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-trend-card/page-tabs-main-trend-card.component.ts ***!
  \*****************************************************************************************************************/
/*! exports provided: PageTabsMainTrendCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsMainTrendCardComponent", function() { return PageTabsMainTrendCardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_main_trend_card_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-main-trend-card.component.html */ "cdwp");
/* harmony import */ var _page_tabs_main_trend_card_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-main-trend-card.component.scss */ "pYNW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _page_tabs_main_article_page_tabs_main_article_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../page-tabs-main-article/page-tabs-main-article.component */ "EuSP");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");






let PageTabsMainTrendCardComponent = class PageTabsMainTrendCardComponent {
    constructor(modalController) {
        this.modalController = modalController;
    }
    ngOnInit() { }
    presentModalArticle() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _page_tabs_main_article_page_tabs_main_article_component__WEBPACK_IMPORTED_MODULE_4__["PageTabsMainArticleComponent"],
                componentProps: { articleJson: this.data.jsonContent }
            });
            yield modal.present();
        });
    }
};
PageTabsMainTrendCardComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] }
];
PageTabsMainTrendCardComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageTabsMainTrendCardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-main-trend-card',
        template: _raw_loader_page_tabs_main_trend_card_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_main_trend_card_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsMainTrendCardComponent);



/***/ }),

/***/ "hYC4":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-main/page-tabs-main.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"logo-wrapper\">\n    <div class=\"logo\">\n      <svg-icon class=\"logo__icon\" src=\"assets/icon/svg/luc-logo.svg\"></svg-icon>\n    </div>\n  </div>\n  <div class=\"content\">\n    <div class=\"buttons-container\">\n      <app-page-tabs-main-search (click)=\"presentModalSearch()\" style=\"flex-grow: 1\"></app-page-tabs-main-search>\n      <app-page-tabs-main-camera></app-page-tabs-main-camera>\n    </div>\n    <div class=\"recommend-container\">\n      <div class=\"title\"> Рекомендации </div>\n      <div class=\"subtitle\"> Подборка, основанная на вашем вкусе </div>\n      <div class=\"cards\">\n        <app-page-tabs-main-recommend-card [data]=\"card\" *ngFor=\"let card of recommends$ | async\"></app-page-tabs-main-recommend-card>\n      </div>\n    </div>\n    <div class=\"trend-container\">\n      <div class=\"title\"> Тренды </div>\n      <div class=\"subtitle\"> Модные тенденции весна 2021 </div>\n      <div class=\"cards\">\n        <app-page-tabs-main-trend-card\n          *ngFor=\"let article of articles$ | async\"\n          [data]=\"article\"\n        ></app-page-tabs-main-trend-card>\n      </div>\n    </div>\n  </div>\n</div>\n");

/***/ }),

/***/ "jzfM":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-recommend-card/page-tabs-main-recommend-card.component.html ***!
  \*****************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngIf=\"!!data; else skeleton\">\n  <div (click)=\"openProduct()\" class=\"container\">\n    <div class=\"image\">\n      <img [src]=\"data.imageUrl\">\n    </div>\n    <div class=\"label label__title\"> {{ data.brand }} </div>\n    <div class=\"label label__subtitle\"> {{ data.type | categorySplit }} </div>\n  </div>\n</ng-container>\n\n<ng-template #skeleton>\n  <div class=\"container\">\n    <div class=\"image\"></div>\n    <ion-skeleton-text class=\"label label__title\" animated style=\"width:40%; height: 1.23vh\"></ion-skeleton-text>\n    <ion-skeleton-text class=\"label label__subtitle\" animated style=\"width:60%; height: 1.23vh\"></ion-skeleton-text>\n  </div>\n</ng-template>\n\n");

/***/ }),

/***/ "oNCp":
/*!***************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-article/page-tabs-main-article.component.html ***!
  \***************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"wrapper\">\n  <div class=\"header\">\n    <svg-icon (click)=\"close()\" class=\"close\" src=\"assets/icon/svg/close.svg\"></svg-icon>\n  </div>\n  <div class=\"container\">\n    <ng-container *ngIf=\"!!(articleData$ | async)\">\n      <div class=\"title padding\"> {{ (articleData$ | async).title }} </div>\n      <ng-container *ngFor=\"let block of (articleData$ | async).blocks\">\n        <ng-container\n          [ngTemplateOutlet]=\"{'subtitle': subtitle, 'text': text, 'photo': photo}[block.type]\"\n          [ngTemplateOutletContext]=\"{ $implicit: block }\">\n        </ng-container>\n      </ng-container>\n      <div class=\"source padding\"> Источники: {{ sources$ | async }} </div>\n      <div class=\"author padding\"> Редактор: <span>{{ (articleData$ | async).author.name }}</span> </div>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #text let-data>\n  <div class=\"text padding\"> {{ data.text }} </div>\n</ng-template>\n\n<ng-template #photo let-data>\n  <div class=\"photo-wrapper\">\n    <app-shared-image-slider [imagesUrl]=\"data.urls\"></app-shared-image-slider>\n  </div>\n</ng-template>\n\n<ng-template #subtitle let-data>\n  <div class=\"subtitle padding\"> {{ data.text }} </div>\n</ng-template>\n");

/***/ }),

/***/ "pYNW":
/*!*******************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-trend-card/page-tabs-main-trend-card.component.scss ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".content {\n  display: flex;\n  height: 12.07vh;\n  width: 100%;\n  gap: 2.59vh;\n}\n\n.image {\n  width: 12.07vh;\n  min-width: 12.07vh;\n  height: 12.07vh;\n  border-radius: 1.48vh;\n  background: #DCE0EB;\n  overflow: hidden;\n}\n\n.image img {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\n.label {\n  height: 100%;\n  flex-grow: 1;\n  font-size: 1.94vh;\n  font-weight: 700;\n}\n\nion-skeleton-text {\n  height: 1.7vh;\n  margin-bottom: 0.7vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1tYWluLXRyZW5kLWNhcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBQ0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7QUFDSjs7QUFHQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUFGOztBQUdBO0VBQ0UsYUFBQTtFQUNBLG9CQUFBO0FBQUYiLCJmaWxlIjoicGFnZS10YWJzLW1haW4tdHJlbmQtY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMi4wN3ZoO1xuICB3aWR0aDogMTAwJTtcbiAgZ2FwOiAyLjU5dmg7XG59XG5cbi5pbWFnZSB7XG4gIHdpZHRoOiAxMi4wN3ZoO1xuICBtaW4td2lkdGg6IDEyLjA3dmg7XG4gIGhlaWdodDogMTIuMDd2aDtcbiAgYm9yZGVyLXJhZGl1czogMS40OHZoO1xuICBiYWNrZ3JvdW5kOiAjRENFMEVCO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuXG4gIGltZyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICB9XG59XG5cbi5sYWJlbCB7XG4gIGhlaWdodDogMTAwJTtcbiAgZmxleC1ncm93OiAxO1xuICBmb250LXNpemU6IDEuOTR2aDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cblxuaW9uLXNrZWxldG9uLXRleHQge1xuICBoZWlnaHQ6IDEuN3ZoO1xuICBtYXJnaW4tYm90dG9tOiAwLjd2aDtcbn1cbiJdfQ== */");

/***/ }),

/***/ "rL5x":
/*!***************************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main-recommend-card/page-tabs-main-recommend-card.component.scss ***!
  \***************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  flex-flow: column;\n}\n\n.image {\n  width: 17.24vh;\n  height: 23.15vh;\n  border-radius: 1.48vh;\n  background: #DCE0EB;\n  margin-bottom: 1.7vh;\n  overflow: hidden;\n}\n\n.image img {\n  width: 100%;\n  border: 0;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\n.label {\n  width: 17vh;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.label__title {\n  margin-bottom: 0.5vh;\n  margin-left: 0.1vh;\n  color: #202D3D;\n  font-size: 1.62vh;\n  font-weight: 700;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.label__subtitle {\n  margin-left: 0.1vh;\n  color: #6E7782;\n  font-size: 1.42vh;\n  font-weight: 400;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy1tYWluLXJlY29tbWVuZC1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxvQkFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBQ0U7RUFDRSxXQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBQ0o7O0FBR0E7RUFDRSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBQUY7O0FBRUU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBSjs7QUFHRTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFESiIsImZpbGUiOiJwYWdlLXRhYnMtbWFpbi1yZWNvbW1lbmQtY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWZsb3c6IGNvbHVtbjtcbn1cblxuLmltYWdlIHtcbiAgd2lkdGg6IDE3LjI0dmg7XG4gIGhlaWdodDogMjMuMTV2aDtcbiAgYm9yZGVyLXJhZGl1czogMS40OHZoO1xuICBiYWNrZ3JvdW5kOiAjRENFMEVCO1xuICBtYXJnaW4tYm90dG9tOiAxLjd2aDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICBpbWcge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJvcmRlcjogMDtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG4gIH1cbn1cblxuLmxhYmVsIHtcbiAgd2lkdGg6IDE3dmg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuXG4gICZfX3RpdGxlIHtcbiAgICBtYXJnaW4tYm90dG9tOiAwLjV2aDtcbiAgICBtYXJnaW4tbGVmdDogMC4xdmg7XG4gICAgY29sb3I6ICMyMDJEM0Q7XG4gICAgZm9udC1zaXplOiAxLjYydmg7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIH1cblxuICAmX19zdWJ0aXRsZSB7XG4gICAgbWFyZ2luLWxlZnQ6IDAuMXZoO1xuICAgIGNvbG9yOiAjNkU3NzgyO1xuICAgIGZvbnQtc2l6ZTogMS40MnZoO1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "sY6W":
/*!*************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-main/page-tabs-main.module.ts ***!
  \*************************************************************************/
/*! exports provided: PageTabsMainModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsMainModule", function() { return PageTabsMainModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../@shared/shared.module */ "pk6O");
/* harmony import */ var _page_tabs_main_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-tabs-main.component */ "7d0u");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _page_tabs_main_camera_page_tabs_main_camera_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./page-tabs-main-camera/page-tabs-main-camera.component */ "+mQK");
/* harmony import */ var _page_tabs_main_search_page_tabs_main_search_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./page-tabs-main-search/page-tabs-main-search.component */ "Tlwu");
/* harmony import */ var _page_tabs_main_trend_card_page_tabs_main_trend_card_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./page-tabs-main-trend-card/page-tabs-main-trend-card.component */ "gU5r");
/* harmony import */ var _page_tabs_main_recommend_card_page_tabs_main_recommend_card_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./page-tabs-main-recommend-card/page-tabs-main-recommend-card.component */ "UxYo");
/* harmony import */ var _page_tabs_main_search_modal_page_tabs_main_search_modal_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./page-tabs-main-search-modal/page-tabs-main-search-modal.component */ "HHte");
/* harmony import */ var _page_tabs_main_article_page_tabs_main_article_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./page-tabs-main-article/page-tabs-main-article.component */ "EuSP");
/* harmony import */ var _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../page-product/page-product.module */ "A6qN");













let PageTabsMainModule = class PageTabsMainModule {
};
PageTabsMainModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _page_tabs_main_component__WEBPACK_IMPORTED_MODULE_4__["PageTabsMainComponent"],
            _page_tabs_main_camera_page_tabs_main_camera_component__WEBPACK_IMPORTED_MODULE_6__["PageTabsMainCameraComponent"],
            _page_tabs_main_search_page_tabs_main_search_component__WEBPACK_IMPORTED_MODULE_7__["PageTabsMainSearchComponent"],
            _page_tabs_main_trend_card_page_tabs_main_trend_card_component__WEBPACK_IMPORTED_MODULE_8__["PageTabsMainTrendCardComponent"],
            _page_tabs_main_recommend_card_page_tabs_main_recommend_card_component__WEBPACK_IMPORTED_MODULE_9__["PageTabsMainRecommendCardComponent"],
            _page_tabs_main_search_modal_page_tabs_main_search_modal_component__WEBPACK_IMPORTED_MODULE_10__["PageTabsMainSearchModalComponent"],
            _page_tabs_main_article_page_tabs_main_article_component__WEBPACK_IMPORTED_MODULE_11__["PageTabsMainArticleComponent"]
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__["SharedModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([{ path: '', component: _page_tabs_main_component__WEBPACK_IMPORTED_MODULE_4__["PageTabsMainComponent"] }]),
            _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_12__["PageProductModule"],
        ]
    })
], PageTabsMainModule);



/***/ })

}]);
//# sourceMappingURL=page-tabs-main-page-tabs-main-module-es2015.js.map