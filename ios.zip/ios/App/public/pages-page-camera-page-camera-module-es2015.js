(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-page-camera-page-camera-module"],{

/***/ "0O/+":
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/page-camera/components/page-camera-dot/page-camera-dot.component.ts ***!
  \*******************************************************************************************/
/*! exports provided: PageCameraDotComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageCameraDotComponent", function() { return PageCameraDotComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_camera_dot_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-camera-dot.component.html */ "T9qd");
/* harmony import */ var _page_camera_dot_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-camera-dot.component.scss */ "RyO4");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PageCameraDotComponent = class PageCameraDotComponent {
    constructor() {
        this.isActive = false;
        this.selectDot = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    ngOnInit() {
    }
};
PageCameraDotComponent.ctorParameters = () => [];
PageCameraDotComponent.propDecorators = {
    isActive: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    selectDot: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }]
};
PageCameraDotComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-camera-dot',
        template: _raw_loader_page_camera_dot_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_camera_dot_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageCameraDotComponent);



/***/ }),

/***/ "4ija":
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/page-camera/components/page-camera-dot/page-camera-dot-group.class.ts ***!
  \*********************************************************************************************/
/*! exports provided: PageCameraDotGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageCameraDotGroup", function() { return PageCameraDotGroup; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");


class PageCameraDotGroup {
    constructor(dots, imgRange, imgDimension) {
        this.dots$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"]([]);
        this.dotsObserver$ = this.dots$.asObservable();
        this.isValid$ = this.dots$.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(x => x.findIndex(d => !!d.isChosen) !== -1));
        this.dots = this.dotsMapper(dots, imgRange, imgDimension);
    }
    set dots(value) {
        if (!value) {
            value = [];
        }
        this.dots$.next(value);
    }
    get dots() {
        return this.dots$.getValue();
    }
    get selectedDot() {
        var _a, _b;
        return (_b = (_a = this.dots) === null || _a === void 0 ? void 0 : _a.find(x => !!x.isChosen)) !== null && _b !== void 0 ? _b : null;
    }
    selectDot(dot) {
        console.log(dot);
        const isChosenCur = !!dot.isChosen;
        const dots = this.dots;
        dots.forEach(x => x.isChosen = false);
        dot.isChosen = !isChosenCur;
        this.dots = [...dots];
    }
    clear() {
        this.dots = [];
    }
    dotsMapper(dots, imgRange, imgDimension) {
        var _a, _b, _c;
        const center = (a, b) => {
            return b - (b - a) / 2;
        };
        return (_c = (_b = (_a = dots === null || dots === void 0 ? void 0 : dots.map(d => ({
            id: d.id,
            x: center(d.area.lowerLeftCorner.x, d.area.upperRightCorner.x),
            y: center(d.area.lowerLeftCorner.y, d.area.upperRightCorner.y),
        }))) === null || _a === void 0 ? void 0 : _a.filter(d => d.x >= 0 && d.x <= imgDimension.width && d.y >= 0 && d.y <= imgDimension.height)) === null || _b === void 0 ? void 0 : _b.map(d => ({
            id: d.id,
            position: {
                x: d.x * (imgRange.rangeX[1] - imgRange.rangeX[0]) / imgDimension.width + imgRange.rangeX[0],
                y: d.y * (imgRange.rangeY[1] - imgRange.rangeY[0]) / imgDimension.height + imgRange.rangeY[0],
            },
            isChosen: false,
        }))) !== null && _c !== void 0 ? _c : [];
    }
}


/***/ }),

/***/ "7mVc":
/*!************************************************************!*\
  !*** ./src/app/@core/services/recognition-info.service.ts ***!
  \************************************************************/
/*! exports provided: RecognitionInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecognitionInfoService", function() { return RecognitionInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _user_info_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-info.service */ "tTdR");
/* harmony import */ var _api_api_recognition_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api/api-recognition.service */ "p0lb");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");





let RecognitionInfoService = class RecognitionInfoService {
    constructor(userInfoService, apiRecognitionService) {
        this.userInfoService = userInfoService;
        this.apiRecognitionService = apiRecognitionService;
        this.recommendCards$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]([null, null, null]);
    }
    textResultMapper(result) {
        var _a;
        return {
            scoreId: result === null || result === void 0 ? void 0 : result.id,
            previews: (_a = result === null || result === void 0 ? void 0 : result.searchResults) !== null && _a !== void 0 ? _a : [],
        };
    }
    getStartReco() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const gender = yield this.userInfoService.getInitialGender();
            return yield this.apiRecognitionService.getStartScreenReco(gender);
        });
    }
    getMainRecommends() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.isMainRecommendsLoaded()) {
                return;
            }
            const res = yield this.apiRecognitionService.getMainRecommends();
            this.recommendCards$.next(res);
        });
    }
    isMainRecommendsLoaded() {
        return !this.recommendCards$.getValue().every(x => x === null);
    }
};
RecognitionInfoService.ctorParameters = () => [
    { type: _user_info_service__WEBPACK_IMPORTED_MODULE_2__["UserInfoService"] },
    { type: _api_api_recognition_service__WEBPACK_IMPORTED_MODULE_3__["ApiRecognitionService"] }
];
RecognitionInfoService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RecognitionInfoService);



/***/ }),

/***/ "Blnv":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-camera/page-camera.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-template #cameraPreview>\n  <div class=\"camera-preview\" id=\"camera-preview\"></div>\n</ng-template>\n<div class=\"img-preview\" *ngIf=\"!!(imgSrcObservable | async); else cameraPreview\">\n  <app-page-camera-dot\n    *ngFor=\"let dot of dotsGroup?.dotsObserver$ | async\"\n    [style]=\"'pointer-events: none; position: absolute; top:' + dot.position.y + 'px; left: ' + dot.position.x + 'px'\"\n    [isActive]=\"dot.isChosen\"\n    (selectDot)=\"dotsGroup.selectDot(dot)\"\n  ></app-page-camera-dot>\n  <ion-img #imgElement alt=\"\" [src]=\"imgSrc\"></ion-img>\n</div>\n\n<div class=\"container\">\n  <div class=\"buttons-container\">\n    <svg-icon\n      class=\"button-icon button-icon__close\"\n      (click)=\"clickClose()\"\n      src=\"assets/icon/svg/close.svg\">\n    </svg-icon>\n  </div>\n\n  <div class=\"flex-free-space\"></div>\n\n  <div class=\"buttons-container\" *ngIf=\"!!(imgSrcObservable | async); else buttonsGallery\">\n    <div *ngIf=\"(viewType$ | async) === 'search'\"\n         (click)=\"findPhoto()\"\n         class=\"button-photo ion-activatable ripple-parent\"\n    >\n      <ion-ripple-effect></ion-ripple-effect>\n      <svg-icon\n        class=\"button-icon button-icon__search\"\n        src=\"assets/icon/svg/search.svg\">\n      </svg-icon>\n    </div>\n    <div *ngIf=\"(viewType$ | async) === 'choosing'\"\n         (click)=\"findDot()\"\n         class=\"button-photo ion-activatable ripple-parent\"\n         [class.button-photo__unactive]=\"!(dotsGroup?.isValid$ | async)\"\n    >\n      <ion-ripple-effect></ion-ripple-effect>\n      <svg-icon\n        class=\"button-icon button-icon__search\"\n        src=\"assets/icon/svg/search.svg\">\n      </svg-icon>\n    </div>\n  </div>\n  <ng-template #buttonsGallery>\n    <div class=\"buttons-container\">\n      <svg-icon\n        class=\"button-icon button-icon__gallery\"\n        (click)=\"openGallery()\"\n        src=\"assets/icon/svg/gallery.svg\">\n      </svg-icon>\n      <div (click)=\"takePhoto()\" class=\"button-photo ion-activatable ripple-parent\">\n        <ion-ripple-effect></ion-ripple-effect>\n        <svg-icon\n          class=\"button-icon button-icon__photo\"\n          src=\"assets/icon/svg/photo.svg\">\n        </svg-icon>\n      </div>\n      <svg-icon\n        class=\"button-icon button-icon__flash\"\n        (click)=\"switchCamera()\"\n        src=\"assets/icon/svg/switch-camera.svg\">\n      </svg-icon>\n    </div>\n  </ng-template>\n</div>\n");

/***/ }),

/***/ "COZQ":
/*!************************************************************!*\
  !*** ./src/app/pages/page-camera/page-camera.component.ts ***!
  \************************************************************/
/*! exports provided: PageCameraComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageCameraComponent", function() { return PageCameraComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_camera_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-camera.component.html */ "Blnv");
/* harmony import */ var _page_camera_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-camera.component.scss */ "SVXG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/core */ "gcOT");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _core_services_platform_status_bar_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../@core/services/platform/status-bar.service */ "qCjG");
/* harmony import */ var _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../@core/services/api/api-recognition.service */ "p0lb");
/* harmony import */ var _components_page_camera_dot_page_camera_dot_group_class__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/page-camera-dot/page-camera-dot-group.class */ "4ija");
/* harmony import */ var _core_services_loading_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../@core/services/loading.service */ "IpGr");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ "tyNb");















const { CameraPreview, Camera } = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"];
let PageCameraComponent = class PageCameraComponent {
    constructor(activeRoute, location, navCtrl, statusBarService, apiRecognitionService, loadingService, recognitionInfoService, platform) {
        this.activeRoute = activeRoute;
        this.location = location;
        this.navCtrl = navCtrl;
        this.statusBarService = statusBarService;
        this.apiRecognitionService = apiRecognitionService;
        this.loadingService = loadingService;
        this.recognitionInfoService = recognitionInfoService;
        this.platform = platform;
        this.nextRouteUrl = '/main/scan';
        this.viewType$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]('search');
        this.items$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([]);
        this.imgSrc$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"](null);
        this.imgSrcObservable = this.imgSrc$.asObservable();
        this.isSrcWithImage = false;
        this.subscriptions = [];
        this.options = {
            x: 0,
            y: 0,
            width: window.screen.width,
            height: window.screen.height,
            position: 'rear',
            toBack: true,
            parent: 'camera-preview',
            className: 'camera-preview',
        };
        this.responseRecognitionData = null;
        this.goToPreviousRoute = () => {
            // queueMicrotask for camera stop fix
            queueMicrotask(() => this.location.back());
        };
    }
    get imgSrc() {
        return this.imgSrc$.getValue();
    }
    set imgSrc(value) {
        this.imgSrc$.next(value);
    }
    ngOnInit() {
        this.statusBarService.hide().then();
    }
    ngAfterViewInit() {
        this.platform.backButton.subscribeWithPriority(9999, () => {
            this.clickClose();
        });
        const img = this.activeRoute.snapshot.queryParamMap.get('img');
        if (img) {
            this.imgSrc = img;
            this.isSrcWithImage = true;
            this.findPhoto().then();
        }
        this.subscriptions.push(this.imgSrcObservable.subscribe((ref) => {
            if (!!ref) {
                CameraPreview.stop();
            }
            else {
                queueMicrotask(() => CameraPreview.start(this.options));
            }
        }));
    }
    ngOnDestroy() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.subscriptions.forEach((s) => s.unsubscribe());
            this.imgSrc = null;
            CameraPreview.stop();
            yield this.statusBarService.setDefault();
        });
    }
    switchCamera() {
        CameraPreview.flip();
    }
    openGallery() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const capturedPhoto = yield Camera.getPhoto({
                resultType: _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["CameraResultType"].DataUrl,
                source: _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["CameraSource"].Photos,
                quality: 70,
            });
            this.imgSrc = capturedPhoto.dataUrl;
        });
    }
    takePhoto() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const capturedPhoto = yield CameraPreview.capture({
                quality: 70,
            });
            this.imgSrc = `data:image/png;base64, ${capturedPhoto.value}`;
        });
    }
    clickClose() {
        if (!!this.imgSrc && !this.isSrcWithImage) {
            this.cancelPhoto();
        }
        else {
            this.goToPreviousRoute();
        }
    }
    findPhoto() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.loadingService.startLoading();
            const recognitionDetected = yield this.apiRecognitionService.searchByPhoto(this.imgSrc);
            if (!recognitionDetected) {
                return;
            }
            yield this.loadingService.stopLoading();
            this.viewType$.next('choosing');
            const imgRange = this.getImgRange();
            const imgDimension = yield this.getImageDimensions(this.imgSrc);
            recognitionDetected.detectedObjects.forEach((x, i) => x.id = i);
            this.responseRecognitionData = recognitionDetected;
            this.dotsGroup = new _components_page_camera_dot_page_camera_dot_group_class__WEBPACK_IMPORTED_MODULE_10__["PageCameraDotGroup"](recognitionDetected.detectedObjects, imgRange, imgDimension);
        });
    }
    findDot() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const selectedDot = this.dotsGroup.selectedDot;
            if (!selectedDot) {
                console.warn('findDot', 'there`re not selected dots');
                return;
            }
            const resDot = this.responseRecognitionData.detectedObjects.find(x => x.id === selectedDot.id);
            this.recognitionInfoService.recognitionSaveFunction =
                () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () { return yield this.apiRecognitionService.searchByDot(this.responseRecognitionData.searchId, resDot); });
            yield this.navCtrl.navigateForward(this.nextRouteUrl);
        });
    }
    cancelPhoto() {
        var _a;
        this.imgSrc = null;
        (_a = this.dotsGroup) === null || _a === void 0 ? void 0 : _a.clear();
        this.viewType$.next('search');
    }
    getImgRange() {
        const imgHtml = this.imgElement.el;
        return {
            rangeX: [imgHtml.offsetLeft, imgHtml.offsetLeft + imgHtml.offsetWidth],
            rangeY: [imgHtml.offsetTop, imgHtml.offsetTop + imgHtml.offsetHeight],
        };
    }
    getImageDimensions(file) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return new Promise((resolved) => {
                const i = new Image();
                i.onload = () => {
                    resolved({ width: i.width, height: i.height });
                };
                i.src = file;
            });
        });
    }
};
PageCameraComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_13__["ActivatedRoute"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: _core_services_platform_status_bar_service__WEBPACK_IMPORTED_MODULE_8__["StatusBarService"] },
    { type: _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_9__["ApiRecognitionService"] },
    { type: _core_services_loading_service__WEBPACK_IMPORTED_MODULE_11__["LoadingService"] },
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_12__["RecognitionInfoService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"] }
];
PageCameraComponent.propDecorators = {
    imgElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['imgElement',] }]
};
PageCameraComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-camera',
        template: _raw_loader_page_camera_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_camera_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageCameraComponent);



/***/ }),

/***/ "JJls":
/*!***********************************************************!*\
  !*** ./src/app/@shared/functions/base64-file.function.ts ***!
  \***********************************************************/
/*! exports provided: dataURLtoFile, urlToDataUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dataURLtoFile", function() { return dataURLtoFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "urlToDataUrl", function() { return urlToDataUrl; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");

function dataURLtoFile(dataUrl, filename = 'default') {
    const arr = dataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
}
function urlToDataUrl(imageUrl) {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
        const proxy = 'https://api.codetabs.com/v1/proxy?quest=';
        let res;
        try {
            res = yield fetch(imageUrl);
        }
        catch (e) {
            res = yield fetch(proxy + imageUrl);
        }
        const blob = yield res.blob();
        console.log(res);
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                resolve(reader.result);
            };
            reader.readAsDataURL(blob);
        });
    });
}


/***/ }),

/***/ "RyO4":
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/page-camera/components/page-camera-dot/page-camera-dot.component.scss ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".circle {\n  pointer-events: all;\n  display: flex;\n  width: 4.45vh;\n  height: 4.45vh;\n  border-radius: 50%;\n  transform: translate(-50%, -50%);\n  border: 0.25vh solid rgba(255, 255, 255, 0.5);\n  box-sizing: border-box;\n}\n.circle .entry-circle {\n  margin: 0.5vh;\n  width: 100%;\n  background: #FFFFFF;\n  border-radius: 50%;\n}\n.circle .entry-check {\n  display: none;\n  margin: 0.8vh;\n  color: #FFFFFF;\n}\n.circle__active {\n  border-color: transparent;\n  background: #45BF78;\n  box-shadow: 0 6px 4px rgba(0, 0, 0, 0.25);\n}\n.circle__active .entry-circle {\n  display: none;\n}\n.circle__active .entry-check {\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtY2FtZXJhLWRvdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQ0FBQTtFQUNBLDZDQUFBO0VBQ0Esc0JBQUE7QUFDRjtBQUNFO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBQ0o7QUFFRTtFQUNFLGFBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBQUFKO0FBR0U7RUFDRSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EseUNBQUE7QUFESjtBQUdJO0VBQ0UsYUFBQTtBQUROO0FBSUk7RUFDRSxjQUFBO0FBRk4iLCJmaWxlIjoicGFnZS1jYW1lcmEtZG90LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNpcmNsZSB7XG4gIHBvaW50ZXItZXZlbnRzOiBhbGw7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiA0LjQ1dmg7XG4gIGhlaWdodDogNC40NXZoO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuICBib3JkZXI6IC4yNXZoIHNvbGlkIHJnYmEoI0ZGRkZGRiwgLjUpO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuXG4gIC5lbnRyeS1jaXJjbGUge1xuICAgIG1hcmdpbjogMC41dmg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgYmFja2dyb3VuZDogI0ZGRkZGRjtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIH1cblxuICAuZW50cnktY2hlY2sge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgbWFyZ2luOiAuOHZoO1xuICAgIGNvbG9yOiAjRkZGRkZGO1xuICB9XG5cbiAgJl9fYWN0aXZlIHtcbiAgICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIGJhY2tncm91bmQ6ICM0NUJGNzg7XG4gICAgYm94LXNoYWRvdzogMCA2cHggNHB4IHJnYmEoMCwgMCwgMCwgMC4yNSk7XG5cbiAgICAuZW50cnktY2lyY2xlIHtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxuXG4gICAgLmVudHJ5LWNoZWNrIHtcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "SVXG":
/*!**************************************************************!*\
  !*** ./src/app/pages/page-camera/page-camera.component.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".camera-preview {\n  position: absolute;\n  display: flex;\n  height: 100%;\n  width: 100%;\n}\n.camera-preview > * {\n  margin: auto;\n}\n.img-preview {\n  position: absolute;\n  display: flex;\n  height: 100%;\n  width: 100%;\n  background: #2F3441;\n}\n.img-preview > * {\n  margin: auto;\n}\n.container {\n  display: flex;\n  flex-flow: column;\n  width: 100%;\n  height: 100%;\n  padding: 7vh 0;\n  box-sizing: border-box;\n}\n.container .buttons-container {\n  display: flex;\n  justify-content: space-evenly;\n  z-index: 1;\n}\n.container .buttons-container .button-photo {\n  display: flex;\n  margin: auto 0;\n  height: 8.5vh;\n  width: 8.7vh;\n  border-radius: 50%;\n  background: #6B7683;\n  transition: 0.3s;\n}\n.container .buttons-container .button-photo__unactive {\n  transition: 0.3s;\n  opacity: 0.3;\n}\n.container .buttons-container .button-icon {\n  margin: auto 0;\n  color: #DADADA;\n}\n.container .buttons-container .button-icon__close {\n  height: 1.7vh;\n  width: 1.7vh;\n  margin: 0 auto 0 2vh;\n}\n.container .buttons-container .button-icon__gallery {\n  height: 2.92vh;\n  width: 2.92vh;\n}\n.container .buttons-container .button-icon__photo {\n  margin: auto;\n  height: 3.5vh;\n  width: 3.5vh;\n}\n.container .buttons-container .button-icon__flash {\n  height: 2.92vh;\n  width: 2.92vh;\n}\n.container .buttons-container .button-icon__search {\n  margin: auto;\n  height: 3vh;\n  width: 3vh;\n}\nion-img {\n  width: 100%;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BhZ2UtY2FtZXJhLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFDRjtBQUNFO0VBQ0UsWUFBQTtBQUNKO0FBR0E7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FBQUY7QUFFRTtFQUNFLFlBQUE7QUFBSjtBQUlBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7QUFERjtBQUdFO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtBQURKO0FBR0k7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBRE47QUFHTTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtBQURSO0FBS0k7RUFDRSxjQUFBO0VBQ0EsY0FBQTtBQUhOO0FBS007RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0FBSFI7QUFNTTtFQUNFLGNBQUE7RUFDQSxhQUFBO0FBSlI7QUFPTTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQUxSO0FBUU07RUFDRSxjQUFBO0VBQ0EsYUFBQTtBQU5SO0FBU007RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7QUFQUjtBQWFBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0tBQUEsbUJBQUE7QUFWRiIsImZpbGUiOiJwYWdlLWNhbWVyYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYW1lcmEtcHJldmlldyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcblxuICAmID4gKiB7XG4gICAgbWFyZ2luOiBhdXRvO1xuICB9XG59XG5cbi5pbWctcHJldmlldyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZDogIzJGMzQ0MTtcblxuICAmID4gKiB7XG4gICAgbWFyZ2luOiBhdXRvO1xuICB9XG59XG5cbi5jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgcGFkZGluZzogN3ZoIDA7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG5cbiAgLmJ1dHRvbnMtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICAgIHotaW5kZXg6IDE7IC8vIGZvciB3ZWIgdmVyc2lvblxuXG4gICAgLmJ1dHRvbi1waG90byB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgbWFyZ2luOiBhdXRvIDA7XG4gICAgICBoZWlnaHQ6IDguNXZoO1xuICAgICAgd2lkdGg6IDguN3ZoO1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgYmFja2dyb3VuZDogIzZCNzY4MztcbiAgICAgIHRyYW5zaXRpb246IC4zcztcblxuICAgICAgJl9fdW5hY3RpdmUge1xuICAgICAgICB0cmFuc2l0aW9uOiAuM3M7XG4gICAgICAgIG9wYWNpdHk6IC4zO1xuICAgICAgfVxuICAgIH1cblxuICAgIC5idXR0b24taWNvbiB7XG4gICAgICBtYXJnaW46IGF1dG8gMDtcbiAgICAgIGNvbG9yOiAjREFEQURBO1xuXG4gICAgICAmX19jbG9zZSB7XG4gICAgICAgIGhlaWdodDogMS43dmg7XG4gICAgICAgIHdpZHRoOiAxLjd2aDtcbiAgICAgICAgbWFyZ2luOiAwIGF1dG8gMCAydmg7XG4gICAgICB9XG5cbiAgICAgICZfX2dhbGxlcnkge1xuICAgICAgICBoZWlnaHQ6IDIuOTJ2aDtcbiAgICAgICAgd2lkdGg6IDIuOTJ2aDtcbiAgICAgIH1cblxuICAgICAgJl9fcGhvdG8ge1xuICAgICAgICBtYXJnaW46IGF1dG87XG4gICAgICAgIGhlaWdodDogMy41dmg7XG4gICAgICAgIHdpZHRoOiAzLjV2aDtcbiAgICAgIH1cblxuICAgICAgJl9fZmxhc2gge1xuICAgICAgICBoZWlnaHQ6IDIuOTJ2aDtcbiAgICAgICAgd2lkdGg6IDIuOTJ2aDtcbiAgICAgIH1cblxuICAgICAgJl9fc2VhcmNoIHtcbiAgICAgICAgbWFyZ2luOiBhdXRvO1xuICAgICAgICBoZWlnaHQ6IDN2aDtcbiAgICAgICAgd2lkdGg6IDN2aDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuaW9uLWltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBvYmplY3QtZml0OiBjb250YWluO1xufVxuIl19 */");

/***/ }),

/***/ "T9qd":
/*!***********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-camera/components/page-camera-dot/page-camera-dot.component.html ***!
  \***********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div (click)=\"selectDot.emit()\" class=\"circle\" [class.circle__active]=\"isActive\">\n  <div class=\"entry-circle\"></div>\n  <svg-icon class=\"entry-check\" src=\"assets/icon/svg/check.svg\"></svg-icon>\n</div>\n");

/***/ }),

/***/ "XeY1":
/*!*********************************************************!*\
  !*** ./src/app/pages/page-camera/page-camera.module.ts ***!
  \*********************************************************/
/*! exports provided: PageCameraModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageCameraModule", function() { return PageCameraModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _page_camera_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-camera.component */ "COZQ");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../@shared/shared.module */ "pk6O");
/* harmony import */ var _components_page_camera_dot_page_camera_dot_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/page-camera-dot/page-camera-dot.component */ "0O/+");







let PageCameraModule = class PageCameraModule {
};
PageCameraModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_camera_component__WEBPACK_IMPORTED_MODULE_4__["PageCameraComponent"], _components_page_camera_dot_page_camera_dot_component__WEBPACK_IMPORTED_MODULE_6__["PageCameraDotComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild([{ path: '', component: _page_camera_component__WEBPACK_IMPORTED_MODULE_4__["PageCameraComponent"] }]),
        ],
    })
], PageCameraModule);



/***/ }),

/***/ "p0lb":
/*!***************************************************************!*\
  !*** ./src/app/@core/services/api/api-recognition.service.ts ***!
  \***************************************************************/
/*! exports provided: ApiRecognitionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiRecognitionService", function() { return ApiRecognitionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../platform/app-config.service */ "ophu");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../@shared/functions/base64-file.function */ "JJls");





let ApiRecognitionService = class ApiRecognitionService {
    constructor(appConfigService, http) {
        this.http = http;
        this.restUrl = appConfigService.recognitionUrl;
    }
    getMainRecommends() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                const url = `${this.restUrl}/api/MainScreen/feeds`;
                return yield this.http.get(url).toPromise();
            }
            catch (e) {
                console.error('getMainRecommends', e);
                return [];
            }
        });
    }
    getStartScreenReco(gender) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/StartScreenReco?gender=${gender}`).toPromise();
            }
            catch (e) {
                console.error('getStartScreenReco', e);
                return [];
            }
        });
    }
    searchByPhoto(dataUrl) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const imgFile = Object(_shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_4__["dataURLtoFile"])(dataUrl);
            const body = new FormData();
            body.append('imageFile', imgFile, imgFile.name);
            try {
                return yield this.http.post(`${this.restUrl}/api/Reco`, body).toPromise();
            }
            catch (e) {
                console.error('searchByPhoto', e);
                return null;
            }
        });
    }
    searchByDot(searchId, dot) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.post(`${this.restUrl}/api/Reco/search/${searchId}`, dot).toPromise();
            }
            catch (e) {
                console.error('searchByDot', e);
                return null;
            }
        });
    }
    searchByText(search) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/Text?query=${search}`).toPromise();
            }
            catch (e) {
                console.error('searchByText', e);
                return null;
            }
        });
    }
    getFullItem(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                const url = `${this.restUrl} /api/Reco/feed/${id}`;
                return yield this.http.get(`${this.restUrl}/api/Reco/feed/${id}`).toPromise();
            }
            catch (e) {
                console.error('getFullItem', e);
                return null;
            }
        });
    }
};
ApiRecognitionService.ctorParameters = () => [
    { type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
ApiRecognitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApiRecognitionService);



/***/ })

}]);
//# sourceMappingURL=pages-page-camera-page-camera-module-es2015.js.map