(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["page-tabs-tinder-page-tabs-tinder-module"],{

/***/ "A8BH":
/*!**********************************************************!*\
  !*** ./src/app/@core/services/api/api-tinder.service.ts ***!
  \**********************************************************/
/*! exports provided: ApiTinderService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiTinderService", function() { return ApiTinderService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../platform/app-config.service */ "ophu");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");




let ApiTinderService = class ApiTinderService {
    constructor(appConfigService, http) {
        this.http = http;
        this.restUrl = appConfigService.recognitionUrl;
    }
    getNextTinder() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.http.get(`${this.restUrl}/api/Tinder/next`).toPromise();
        });
    }
};
ApiTinderService.ctorParameters = () => [
    { type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
ApiTinderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApiTinderService);



/***/ }),

/***/ "Ds04":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-tinder/page-tabs-tinder.component.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"header\">\n    <span>Лукич</span>\n    <span class=\"filter-icon\"><svg-icon src=\"assets/icon/svg/filter-list.svg\"></svg-icon></span>\n  </div>\n  <div class=\"subheader\"> Выбирай лучшее, то что тебе нравится, а LUC найдет для тебя это </div>\n  <div class=\"card-container\">\n<!--    <div class=\"card\" #tinderCard><app-page-tabs-tinder-card [imgSrc]=\"currentImg$ | async\"></app-page-tabs-tinder-card></div>-->\n<!--    <div class=\"card card__pseudo\"> <div class=\"shadow\"></div> <img alt=\"\" [src]=\"nextImg$ | async\" /> </div>-->\n    <ion-slides (ionSlideDidChange)=\"slideDetectChange()\" style=\"width: 100%; height: 100%\" #ionSlides>\n      <ion-slide *ngFor=\"let card of cards$ | async\">\n        <app-page-tabs-tinder-card class=\"card\" [data]=\"card\"></app-page-tabs-tinder-card>\n      </ion-slide>\n    </ion-slides>\n  </div>\n</div>\n");

/***/ }),

/***/ "KNm0":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-tinder/page-tabs-tinder.module.ts ***!
  \*****************************************************************************/
/*! exports provided: PageTabsTinderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsTinderModule", function() { return PageTabsTinderModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _page_tabs_tinder_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-tabs-tinder.component */ "qiOo");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _components_page_tabs_tinder_card_page_tabs_tinder_card_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/page-tabs-tinder-card/page-tabs-tinder-card.component */ "sRNJ");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../@shared/shared.module */ "pk6O");
/* harmony import */ var _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../page-product/page-product.module */ "A6qN");








let PageTabsTinderModule = class PageTabsTinderModule {
};
PageTabsTinderModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_tabs_tinder_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsTinderComponent"], _components_page_tabs_tinder_card_page_tabs_tinder_card_component__WEBPACK_IMPORTED_MODULE_5__["PageTabsTinderCardComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{ path: '', component: _page_tabs_tinder_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsTinderComponent"] }]),
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__["SharedModule"],
            _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_7__["PageProductModule"],
        ]
    })
], PageTabsTinderModule);



/***/ }),

/***/ "Qoyy":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-tinder/page-tabs-tinder.component.scss ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  flex-flow: column;\n  width: 100%;\n  height: 100%;\n  gap: 1.97vh;\n  padding: 0 4.27vw;\n  box-sizing: border-box;\n  overflow: hidden;\n  background: white;\n}\n.container .header {\n  font-size: 2.71vh;\n  font-weight: 700;\n  color: #222222;\n  margin-top: 2.46vh;\n}\n.container .header .filter-icon {\n  float: right;\n  width: 5vw;\n  color: #546173;\n}\n.container .subheader {\n  margin-bottom: 3.5vh;\n  font-size: 1.9vh;\n  font-weight: 400;\n  color: #222222;\n}\n.container .card-container {\n  position: relative;\n  width: 100%;\n  flex-grow: 1;\n  margin-bottom: 2vh;\n}\n.container .card-container .card {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n  border-radius: 1.97vh;\n  z-index: 1;\n}\n.container .card-container .card__pseudo {\n  position: absolute;\n  background: #EAEDF5;\n  z-index: 0;\n}\n.container .card-container .card__pseudo img {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.container .card-container .card__pseudo .shadow {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  z-index: 1;\n  box-shadow: inset 0px -5px 20px -5px rgba(0, 0, 0, 0.4);\n  background: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy10aW5kZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUNGO0FBQ0U7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQ0o7QUFDSTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQUNOO0FBR0U7RUFDRSxvQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBREo7QUFJRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUZKO0FBSUk7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7QUFGTjtBQUlNO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7QUFGUjtBQUlRO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBRlY7QUFLUTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsdURBQUE7RUFDQSxnQkFBQTtBQUhWIiwiZmlsZSI6InBhZ2UtdGFicy10aW5kZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGdhcDogMS45N3ZoO1xuICBwYWRkaW5nOiAwIDQuMjd2dztcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG5cbiAgLmhlYWRlciB7XG4gICAgZm9udC1zaXplOiAyLjcxdmg7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgICBtYXJnaW4tdG9wOiAyLjQ2dmg7XG5cbiAgICAuZmlsdGVyLWljb24ge1xuICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgd2lkdGg6IDV2dztcbiAgICAgIGNvbG9yOiAjNTQ2MTczO1xuICAgIH1cbiAgfVxuXG4gIC5zdWJoZWFkZXIge1xuICAgIG1hcmdpbi1ib3R0b206IDMuNXZoO1xuICAgIGZvbnQtc2l6ZTogMS45dmg7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgfVxuXG4gIC5jYXJkLWNvbnRhaW5lciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBtYXJnaW4tYm90dG9tOiAydmg7XG5cbiAgICAuY2FyZCB7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICBib3JkZXItcmFkaXVzOiAxLjk3dmg7XG4gICAgICB6LWluZGV4OiAxO1xuXG4gICAgICAmX19wc2V1ZG8ge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGJhY2tncm91bmQ6ICNFQUVERjU7XG4gICAgICAgIHotaW5kZXg6IDA7XG5cbiAgICAgICAgaW1nIHtcbiAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgICAgIH1cblxuICAgICAgICAuc2hhZG93IHtcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICAgIHotaW5kZXg6IDE7XG4gICAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMHB4IC01cHggMjBweCAtNXB4IHJnYmEoMCwgMCwgMCwgLjQpO1xuICAgICAgICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "ljS3":
/*!************************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-tinder/components/page-tabs-tinder-card/page-tabs-tinder-card.component.scss ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  flex-flow: column;\n  justify-content: space-between;\n  position: relative;\n  width: 100%;\n  height: 100%;\n  background: #EAEDF5;\n}\n.container .shadow {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  z-index: 1;\n  box-shadow: inset 0px -5px 20px -5px rgba(0, 0, 0, 0.4);\n  pointer-events: none;\n}\n.container img {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.container .rights {\n  position: relative;\n  display: flex;\n  width: 6.4vw;\n  height: 6.4vw;\n  margin: 3.7vw 3.7vw 3.7vw auto;\n  border-radius: 50%;\n  background: rgba(49, 55, 65, 0.5);\n  z-index: 1;\n  color: #FFFFFF;\n  font-size: 1.97vh;\n  transition: 0.3s;\n}\n.container .rights span {\n  margin: auto;\n}\n.container .rights .info {\n  position: absolute;\n  padding: 1.23vh;\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n  right: 0;\n  top: 3.5vh;\n  background: #313741;\n  border-radius: 0.64vh;\n  pointer-events: none;\n  opacity: 0;\n  transition: 0.3s;\n}\n.container .rights__active {\n  background: #313741;\n  transition: 0.3s;\n}\n.container .rights__active .info {\n  opacity: 1;\n  transition: 0.3s;\n}\n.container .interface {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n  padding: 0 6.9vw;\n  margin-bottom: 2.46vh;\n  z-index: 1;\n}\n.container .shop {\n  width: 11.7vw;\n  height: 11.7vw;\n  margin: auto 0;\n  padding: 3vw;\n  border-radius: 50%;\n  background: #2CB172;\n  color: #FFFFFF;\n}\n.container .button {\n  width: 16vw;\n  height: 16vw;\n  padding: 5.3vw;\n  border-radius: 50%;\n  background: rgba(49, 55, 65, 0.5);\n}\n.container .button svg-icon {\n  color: #DDDFE3;\n}\n.container .button__favorite svg-icon {\n  color: #FF3B30;\n}\n.container ion-spinner {\n  margin: auto;\n  --color: #2CB172;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy10aW5kZXItY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBQ0Y7QUFDRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsdURBQUE7RUFDQSxvQkFBQTtBQUNKO0FBRUU7RUFDRSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBQUo7QUFHRTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBREo7QUFHSTtFQUNFLFlBQUE7QUFETjtBQUlJO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0EsMEJBQUE7RUFBQSx1QkFBQTtFQUFBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUFGTjtBQUtJO0VBQ0UsbUJBQUE7RUFDQSxnQkFBQTtBQUhOO0FBS007RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7QUFIUjtBQVFFO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxVQUFBO0FBTko7QUFTRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQVBKO0FBVUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0FBUko7QUFVSTtFQUNFLGNBQUE7QUFSTjtBQVlNO0VBQ0UsY0FBQTtBQVZSO0FBZ0JFO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0FBZEoiLCJmaWxlIjoicGFnZS10YWJzLXRpbmRlci1jYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZDogI0VBRURGNTtcblxuICAuc2hhZG93IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHotaW5kZXg6IDE7XG4gICAgYm94LXNoYWRvdzogaW5zZXQgMHB4IC01cHggMjBweCAtNXB4IHJnYmEoMCwgMCwgMCwgLjQpO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICB9XG5cbiAgaW1nIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICB0b3A6IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICB9XG5cbiAgLnJpZ2h0cyB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgd2lkdGg6IDYuNHZ3O1xuICAgIGhlaWdodDogNi40dnc7XG4gICAgbWFyZ2luOiAzLjd2dyAzLjd2dyAzLjd2dyBhdXRvO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKCMzMTM3NDEsIC41KTtcbiAgICB6LWluZGV4OiAxO1xuICAgIGNvbG9yOiAjRkZGRkZGO1xuICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgIHRyYW5zaXRpb246IC4zcztcblxuICAgIHNwYW4ge1xuICAgICAgbWFyZ2luOiBhdXRvO1xuICAgIH1cblxuICAgIC5pbmZvIHtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHBhZGRpbmc6IDEuMjN2aDtcbiAgICAgIHdpZHRoOiBtYXgtY29udGVudDtcbiAgICAgIHJpZ2h0OiAwO1xuICAgICAgdG9wOiAzLjV2aDtcbiAgICAgIGJhY2tncm91bmQ6ICMzMTM3NDE7XG4gICAgICBib3JkZXItcmFkaXVzOiAuNjR2aDtcbiAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgICAgb3BhY2l0eTogMDtcbiAgICAgIHRyYW5zaXRpb246IC4zcztcbiAgICB9XG5cbiAgICAmX19hY3RpdmUge1xuICAgICAgYmFja2dyb3VuZDogIzMxMzc0MTtcbiAgICAgIHRyYW5zaXRpb246IC4zcztcblxuICAgICAgLmluZm8ge1xuICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICB0cmFuc2l0aW9uOiAuM3M7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLmludGVyZmFjZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZzogMCA2Ljl2dztcbiAgICBtYXJnaW4tYm90dG9tOiAyLjQ2dmg7XG4gICAgei1pbmRleDogMTtcbiAgfVxuXG4gIC5zaG9wIHtcbiAgICB3aWR0aDogMTEuN3Z3O1xuICAgIGhlaWdodDogMTEuN3Z3O1xuICAgIG1hcmdpbjogYXV0byAwO1xuICAgIHBhZGRpbmc6IDN2dztcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgYmFja2dyb3VuZDogIzJDQjE3MjtcbiAgICBjb2xvcjogI0ZGRkZGRjtcbiAgfVxuXG4gIC5idXR0b24ge1xuICAgIHdpZHRoOiAxNnZ3O1xuICAgIGhlaWdodDogMTZ2dztcbiAgICBwYWRkaW5nOiA1LjN2dztcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgYmFja2dyb3VuZDogcmdiYSg0OSw1NSw2NSwuNSk7XG5cbiAgICBzdmctaWNvbiB7XG4gICAgICBjb2xvcjogI0REREZFMztcbiAgICB9XG5cbiAgICAmX19mYXZvcml0ZSB7XG4gICAgICBzdmctaWNvbiB7XG4gICAgICAgIGNvbG9yOiAjRkYzQjMwO1xuICAgICAgfVxuICAgIH1cblxuICB9XG5cbiAgaW9uLXNwaW5uZXIge1xuICAgIG1hcmdpbjogYXV0bztcbiAgICAtLWNvbG9yOiAjMkNCMTcyO1xuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "qiOo":
/*!********************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-tinder/page-tabs-tinder.component.ts ***!
  \********************************************************************************/
/*! exports provided: PageTabsTinderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsTinderComponent", function() { return PageTabsTinderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_tinder_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-tinder.component.html */ "Ds04");
/* harmony import */ var _page_tabs_tinder_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-tinder.component.scss */ "Qoyy");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _core_services_api_api_tinder_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../@core/services/api/api-tinder.service */ "A8BH");







let PageTabsTinderComponent = class PageTabsTinderComponent {
    constructor(apiTinderService, gestureCtrl, platform) {
        this.apiTinderService = apiTinderService;
        this.gestureCtrl = gestureCtrl;
        this.platform = platform;
        this.tabName = 'blocks';
        this.cards$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"]([
            () => this.getNextImage(),
            () => this.getNextImage(),
            () => this.getNextImage(),
        ]);
        this.action = (actionType) => {
            console.log('tinder-action', actionType);
        };
    }
    ngOnInit() { }
    ngAfterViewInit() {
        this.useTinderSwipe(this.tinderCard, this.platform.width());
    }
    useTinderSwipe(card, screenWidth) {
        if (!(card === null || card === void 0 ? void 0 : card.nativeElement)) {
            return;
        }
        const gesture = this.gestureCtrl.create({
            el: card.nativeElement,
            gestureName: 'tinder-swipe',
            onStart: (e) => {
                card.nativeElement.style.transition = `none`;
            },
            onMove: (e) => {
                card.nativeElement.style.transform = `translateX(${e.deltaX}px)`;
                // card.nativeElement.style.transform = `translateX(${e.deltaX}px) rotate(${e.deltaX / 8}deg)`;
            },
            onEnd: (e) => {
                let transform = `translateX(0px) rotate(0deg)`;
                if (e.deltaX > screenWidth / 2) {
                    transform = `translateX(${+screenWidth * 2}px)`;
                    // transform = `translateX(${+screenWidth * 2}px) rotate(${e.deltaX / 2}deg)`;
                    this.action('like');
                }
                else if (e.deltaX < -screenWidth / 2) {
                    transform = `translateX(${-screenWidth * 2}px)`;
                    // transform = `translateX(${-screenWidth * 2}px) rotate(${e.deltaX / 2}deg)`;
                    this.action('dislike');
                }
                card.nativeElement.style.transition = `.5s ease-out`;
                card.nativeElement.style.transform = transform;
            },
        });
        gesture.enable(true);
    }
    slideDetectChange() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const cards = this.cards$.getValue();
            const currentIdx = yield this.ionSlide.getActiveIndex();
            if (cards.length - (currentIdx + 1) < 1) {
                this.cards$.next([...cards, () => this.getNextImage()]);
            }
        });
    }
    getNextImage() {
        return this.apiTinderService.getNextTinder();
    }
};
PageTabsTinderComponent.ctorParameters = () => [
    { type: _core_services_api_api_tinder_service__WEBPACK_IMPORTED_MODULE_6__["ApiTinderService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["GestureController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] }
];
PageTabsTinderComponent.propDecorators = {
    tinderCard: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['tinderCard',] }],
    ionSlide: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['ionSlides',] }]
};
PageTabsTinderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-tinder',
        template: _raw_loader_page_tabs_tinder_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_tinder_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsTinderComponent);



/***/ }),

/***/ "sRNJ":
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-tinder/components/page-tabs-tinder-card/page-tabs-tinder-card.component.ts ***!
  \**********************************************************************************************************************/
/*! exports provided: PageTabsTinderCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsTinderCardComponent", function() { return PageTabsTinderCardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_tinder_card_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs-tinder-card.component.html */ "z8zC");
/* harmony import */ var _page_tabs_tinder_card_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs-tinder-card.component.scss */ "ljS3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../@shared/functions/base64-file.function */ "JJls");
/* harmony import */ var _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../@core/services/loading.service */ "IpGr");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../@core/services/api/api-recognition.service */ "p0lb");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../page-product/page-product.component */ "8jGz");
/* harmony import */ var _shared_classes_favorites_class__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../../@shared/classes/favorites.class */ "mVaD");
/* harmony import */ var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../@core/services/api/api-user.service */ "lA1K");
/* harmony import */ var _core_services_api_api_file_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../@core/services/api/api-file.service */ "0SLh");















let PageTabsTinderCardComponent = class PageTabsTinderCardComponent {
    constructor(navCtrl, loadingService, apiRecognitionService, modalController, recognitionInfoService, apiUserService, apiFileService) {
        this.navCtrl = navCtrl;
        this.loadingService = loadingService;
        this.apiRecognitionService = apiRecognitionService;
        this.modalController = modalController;
        this.recognitionInfoService = recognitionInfoService;
        this.apiUserService = apiUserService;
        this.apiFileService = apiFileService;
        this.data$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](null);
        this.isFavorite$ = this.data$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["map"])(x => { var _a; return (_a = x === null || x === void 0 ? void 0 : x.feedPreview) === null || _a === void 0 ? void 0 : _a.isFavorite; }));
        this.shopUrl$ = this.data$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["filter"])(x => x.type === 'feed'), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["map"])(x => x.feedId));
        this.isInfo$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](false);
        this.nextRouteUrl = '/main/camera';
        this.favoritesController = new _shared_classes_favorites_class__WEBPACK_IMPORTED_MODULE_12__["FavoritesController"](apiUserService);
    }
    set data(method) {
        this.disableInfo();
        method().then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!res) {
                // TODO: add error handler
                return;
            }
            res.imageUrl = res.type !== 'tinderItem' ? res.imageUrl : this.apiFileService.getTinderPhotoById(res.tinderId);
            if (res.type === 'feed') {
                res.feedPreview = yield this.apiRecognitionService.getFullItem(res.feedId);
            }
            this.data$.next(res);
        }));
    }
    ngOnInit() { }
    toggleInfo() {
        this.isInfo$.next(!this.isInfo$.value);
    }
    search() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.data$.getValue()) {
                return;
            }
            yield this.loadingService.startLoading();
            const img = yield Object(_shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_6__["urlToDataUrl"])(this.data$.value.imageUrl);
            yield this.loadingService.stopLoading();
            yield this.navCtrl.navigateForward(this.nextRouteUrl, { queryParams: { img } });
        });
    }
    openProduct() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const productId = (_a = this.data$.getValue()) === null || _a === void 0 ? void 0 : _a.feedId;
            if (!productId) {
                return;
            }
            this.recognitionInfoService.recognitionFeedFunction = () => this.apiRecognitionService.getFullItem(productId);
            yield this.presentModalInfo();
        });
    }
    setFavorite() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const data = this.data$.getValue();
            if (!data.feedPreview) {
                return;
            }
            data.feedPreview.isFavorite = yield this.favoritesController.setFavourite(data.feedId, !data.feedPreview.isFavorite);
            this.data$.next(Object.assign({}, data));
        });
    }
    disableInfo() {
        this.isInfo$.next(false);
    }
    presentModalInfo() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_11__["PageProductComponent"],
            });
            return yield modal.present();
        });
    }
};
PageTabsTinderCardComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"] },
    { type: _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_9__["ApiRecognitionService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_10__["RecognitionInfoService"] },
    { type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_13__["ApiUserService"] },
    { type: _core_services_api_api_file_service__WEBPACK_IMPORTED_MODULE_14__["ApiFileService"] }
];
PageTabsTinderCardComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageTabsTinderCardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-tinder-card',
        template: _raw_loader_page_tabs_tinder_card_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_tinder_card_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsTinderCardComponent);



/***/ }),

/***/ "z8zC":
/*!**************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-tinder/components/page-tabs-tinder-card/page-tabs-tinder-card.component.html ***!
  \**************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"shadow\"></div>\n  <ng-container *ngIf=\"!!(data$ | async); else loader\">\n    <img alt=\"\" [src]=\"(data$ | async).imageUrl\"/>\n    <div\n      [ngStyle]=\"{visibility: !(shopUrl$ | async) ? 'visible' : 'hidden'}\"\n      (click)=\"toggleInfo()\"\n      class=\"rights\"\n      [class.rights__active]=\"isInfo$ | async\"\n    >\n      <span> © </span>\n      <div class=\"info\"> Источник: pinterest.ru </div>\n    </div>\n    <div class=\"interface\">\n      <div\n        [ngStyle]=\"{visibility: !!(shopUrl$ | async) ? 'visible' : 'hidden'}\"\n        class=\"button\" [class.button__favorite]=\"isFavorite$ | async\"\n        (click)=\"setFavorite()\"\n      >\n        <svg-icon src=\"assets/icon/svg/favorite.svg\"></svg-icon>\n      </div>\n      <div *ngIf=\"!!(shopUrl$ | async)\" (click)=\"openProduct()\" class=\"shop\">\n        <svg-icon src=\"assets/icon/svg/shopping-cart.svg\"></svg-icon>\n      </div>\n      <div (click)=\"search()\" class=\"button\">\n        <svg-icon src=\"assets/icon/svg/search.svg\"></svg-icon>\n      </div>\n    </div>\n  </ng-container>\n  <ng-template #loader>\n    <ion-spinner name=\"dots\"></ion-spinner>\n  </ng-template>\n</div>\n");

/***/ })

}]);
//# sourceMappingURL=page-tabs-tinder-page-tabs-tinder-module-es2015.js.map