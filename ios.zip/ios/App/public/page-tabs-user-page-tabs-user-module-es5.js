(function () {
  function _get(target, property, receiver) { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get; } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(receiver); } return desc.value; }; } return _get(target, property, receiver || target); }

  function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

  function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["page-tabs-user-page-tabs-user-module"], {
    /***/
    "+wiY":
    /*!***********************************************************************!*\
      !*** ./src/app/popups/popup-drop-pass/popup-drop-pass.component.scss ***!
      \***********************************************************************/

    /*! exports provided: default */

    /***/
    function wiY(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".page-wrapper {\n  display: flex;\n  flex-flow: column;\n  height: 100%;\n  padding: 3.7vh 0;\n}\n\n.header {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n  padding: 0 2.2vh;\n  box-sizing: border-box;\n}\n\n.header > * {\n  margin: auto 0;\n}\n\n.header .label {\n  text-align: center;\n  font-size: 2.1vh;\n  font-weight: 600;\n  color: #222222;\n}\n\n.header .icon {\n  width: 2.43vh;\n  height: 2.43vh;\n  color: #2CB172;\n}\n\n.form {\n  display: flex;\n  flex-flow: column;\n  flex-grow: 1;\n  gap: 1.97vh;\n  padding: 0 4.27vw;\n  margin-top: 5vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BvcHVwLWRyb3AtcGFzcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSw4QkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7QUFDRjs7QUFDRTtFQUNFLGNBQUE7QUFDSjs7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFBSjs7QUFHRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQURKOztBQUtBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFGRiIsImZpbGUiOiJwb3B1cC1kcm9wLXBhc3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucGFnZS13cmFwcGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIGhlaWdodDogMTAwJTtcbiAgcGFkZGluZzogMy43dmggMDtcbn1cblxuLmhlYWRlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiAxMDAlO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIHBhZGRpbmc6IDAgMi4ydmg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG5cbiAgJiA+ICoge1xuICAgIG1hcmdpbjogYXV0byAwO1xuICB9XG5cbiAgLmxhYmVsIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyLjF2aDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiAjMjIyMjIyO1xuICB9XG5cbiAgLmljb24ge1xuICAgIHdpZHRoOiAyLjQzdmg7XG4gICAgaGVpZ2h0OiAyLjQzdmg7XG4gICAgY29sb3I6ICMyQ0IxNzI7XG4gIH1cbn1cblxuLmZvcm0ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgZmxleC1ncm93OiAxO1xuICBnYXA6IDEuOTd2aDtcbiAgcGFkZGluZzogMCA0LjI3dnc7XG4gIG1hcmdpbi10b3A6IDV2aDtcbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "2yLI":
    /*!***********************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-reg/page-tabs-user-screen-reg.component.ts ***!
      \***********************************************************************************************************************/

    /*! exports provided: PageTabsUserScreenRegComponent */

    /***/
    function yLI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsUserScreenRegComponent", function () {
        return PageTabsUserScreenRegComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_user_screen_reg_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-user-screen-reg.component.html */
      "wVb9");
      /* harmony import */


      var _page_tabs_user_screen_reg_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-user-screen-reg.component.scss */
      "sm/y");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _core_services_loading_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../../../@core/services/loading.service */
      "IpGr");
      /* harmony import */


      var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../../../../@core/services/api/api-user.service */
      "lA1K");
      /* harmony import */


      var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../../../../@core/services/user-info.service */
      "tTdR");

      var PageTabsUserScreenRegComponent = /*#__PURE__*/function () {
        function PageTabsUserScreenRegComponent(loadingService, apiUserService, userService) {
          _classCallCheck(this, PageTabsUserScreenRegComponent);

          this.loadingService = loadingService;
          this.apiUserService = apiUserService;
          this.userService = userService;
          this.regForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].email]),
            passwords: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
              password: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(3)]),
              repeatPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(3)])
            }, [matchValidator]),
            isPersonalDataAgree: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](false, [agreeValidator])
          });
        }

        _createClass(PageTabsUserScreenRegComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.regForm.valueChanges.subscribe(function (x) {
              return console.log(x);
            });
          }
        }, {
          key: "agreeClick",
          value: function agreeClick() {
            this.regForm.get('isPersonalDataAgree').markAsDirty();
            this.regForm.get('isPersonalDataAgree').setValue(!this.regForm.get('isPersonalDataAgree').value);
          }
        }, {
          key: "checkFieldError",
          value: function checkFieldError(fieldName) {
            var _a, _b;

            return ((_a = this.regForm.get(fieldName)) === null || _a === void 0 ? void 0 : _a.errors) && ((_b = this.regForm.get(fieldName)) === null || _b === void 0 ? void 0 : _b.dirty);
          }
        }, {
          key: "regClick",
          value: function regClick() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var res;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      Object.values(this.regForm.controls).forEach(function (x) {
                        return x.markAsDirty();
                      });

                      if (this.regForm.valid) {
                        _context.next = 4;
                        break;
                      }

                      console.warn('invalid form');
                      return _context.abrupt("return");

                    case 4:
                      _context.next = 6;
                      return this.loadingService.startLoading();

                    case 6:
                      _context.next = 8;
                      return this.apiUserService.userRegister(this.regForm.value);

                    case 8:
                      res = _context.sent;
                      this.loadingService.stopLoading().then();
                      this.userService.setUser(res);

                    case 11:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return PageTabsUserScreenRegComponent;
      }();

      PageTabsUserScreenRegComponent.ctorParameters = function () {
        return [{
          type: _core_services_loading_service__WEBPACK_IMPORTED_MODULE_5__["LoadingService"]
        }, {
          type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_6__["ApiUserService"]
        }, {
          type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_7__["UserInfoService"]
        }];
      };

      PageTabsUserScreenRegComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-user-screen-reg',
        template: _raw_loader_page_tabs_user_screen_reg_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_user_screen_reg_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsUserScreenRegComponent);

      function matchValidator(group) {
        var values = Object.values(group.value);

        if ((values === null || values === void 0 ? void 0 : values.length) === values.filter(function (x) {
          return x === values[0];
        }).length) {
          return null;
        }

        return {
          mismatch: {
            message: 'Values are not equal'
          }
        };
      }

      function agreeValidator(control) {
        if (!!control.value) {
          return null;
        }

        return {
          agree: {
            message: 'Values are not agree'
          }
        };
      }
      /***/

    },

    /***/
    "4NFK":
    /*!*****************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/device.js ***!
      \*****************************************************************************************************************/

    /*! exports provided: DevicePluginWeb, Device */

    /***/
    function NFK(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DevicePluginWeb", function () {
        return DevicePluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Device", function () {
        return Device;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");
      /* harmony import */


      var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../util */
      "vW6J");

      var DevicePluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(DevicePluginWeb, _super);

        function DevicePluginWeb() {
          return _super.call(this, {
            name: 'Device',
            platforms: ['web']
          }) || this;
        }

        DevicePluginWeb.prototype.getInfo = function () {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var ua, uaFields;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              ua = navigator.userAgent;
              uaFields = this.parseUa(ua);
              return [2
              /*return*/
              , Promise.resolve({
                model: uaFields.model,
                platform: 'web',
                appVersion: '',
                appBuild: '',
                appId: '',
                appName: '',
                operatingSystem: uaFields.operatingSystem,
                osVersion: uaFields.osVersion,
                manufacturer: navigator.vendor,
                isVirtual: false,
                uuid: this.getUid()
              })];
            });
          });
        };

        DevicePluginWeb.prototype.getBatteryInfo = function () {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var battery, e_1;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  battery = {};
                  _a.label = 1;

                case 1:
                  _a.trys.push([1, 3,, 4]);

                  return [4
                  /*yield*/
                  , navigator.getBattery()];

                case 2:
                  battery = _a.sent();
                  return [3
                  /*break*/
                  , 4];

                case 3:
                  e_1 = _a.sent();
                  return [3
                  /*break*/
                  , 4];

                case 4:
                  return [2
                  /*return*/
                  , Promise.resolve({
                    batteryLevel: battery.level,
                    isCharging: battery.charging
                  })];
              }
            });
          });
        };

        DevicePluginWeb.prototype.getLanguageCode = function () {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              return [2
              /*return*/
              , {
                value: navigator.language
              }];
            });
          });
        };

        DevicePluginWeb.prototype.parseUa = function (_ua) {
          var uaFields = {};
          var start = _ua.indexOf('(') + 1;

          var end = _ua.indexOf(') AppleWebKit');

          if (_ua.indexOf(') Gecko') !== -1) {
            end = _ua.indexOf(') Gecko');
          }

          var fields = _ua.substring(start, end);

          if (_ua.indexOf('Android') !== -1) {
            uaFields.model = fields.replace('; wv', '').split('; ').pop().split(' Build')[0];
            uaFields.osVersion = fields.split('; ')[1];
          } else {
            uaFields.model = fields.split('; ')[0];

            if (navigator.oscpu) {
              uaFields.osVersion = navigator.oscpu;
            } else {
              if (_ua.indexOf('Windows') !== -1) {
                uaFields.osVersion = fields;
              } else {
                var lastParts = fields.split('; ').pop().replace(' like Mac OS X', '').split(' ');
                uaFields.osVersion = lastParts[lastParts.length - 1].replace(/_/g, '.');
              }
            }
          }

          if (/android/i.test(_ua)) {
            uaFields.operatingSystem = 'android';
          } else if (/iPad|iPhone|iPod/.test(_ua) && !window.MSStream) {
            uaFields.operatingSystem = 'ios';
          } else if (/Win/.test(_ua)) {
            uaFields.operatingSystem = 'windows';
          } else if (/Mac/i.test(_ua)) {
            uaFields.operatingSystem = 'mac';
          } else {
            uaFields.operatingSystem = 'unknown';
          }

          return uaFields;
        };

        DevicePluginWeb.prototype.getUid = function () {
          var uid = window.localStorage.getItem('_capuid');

          if (uid) {
            return uid;
          }

          uid = Object(_util__WEBPACK_IMPORTED_MODULE_2__["uuid4"])();
          window.localStorage.setItem('_capuid', uid);
          return uid;
        };

        return DevicePluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Device = new DevicePluginWeb(); //# sourceMappingURL=device.js.map

      /***/
    },

    /***/
    "5fE0":
    /*!*********************************************************************!*\
      !*** ./src/app/popups/popup-drop-pass/popup-drop-pass.component.ts ***!
      \*********************************************************************/

    /*! exports provided: PopupDropPassComponent */

    /***/
    function fE0(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PopupDropPassComponent", function () {
        return PopupDropPassComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_popup_drop_pass_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./popup-drop-pass.component.html */
      "QOz/");
      /* harmony import */


      var _popup_drop_pass_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./popup-drop-pass.component.scss */
      "+wiY");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../@core/services/api/api-user.service */
      "lA1K");
      /* harmony import */


      var _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../@core/services/loading.service */
      "IpGr");

      var PopupDropPassComponent = /*#__PURE__*/function () {
        function PopupDropPassComponent(modalCtrl, apiUserService, loadingService, alertController) {
          _classCallCheck(this, PopupDropPassComponent);

          this.modalCtrl = modalCtrl;
          this.apiUserService = apiUserService;
          this.loadingService = loadingService;
          this.alertController = alertController;
          this.email = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].email]);
        }

        _createClass(PopupDropPassComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "back",
          value: function back() {
            this.modalCtrl.dismiss().then();
          }
        }, {
          key: "dropPass",
          value: function dropPass() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var result;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      this.email.markAsTouched();

                      if (this.email.valid) {
                        _context2.next = 3;
                        break;
                      }

                      return _context2.abrupt("return");

                    case 3:
                      _context2.next = 5;
                      return this.loadingService.startLoading();

                    case 5:
                      _context2.next = 7;
                      return this.apiUserService.dropPassword(this.email.value);

                    case 7:
                      result = _context2.sent;
                      console.log('dropPass', result);
                      _context2.next = 11;
                      return this.loadingService.stopLoading();

                    case 11:
                      _context2.next = 13;
                      return this.presentAlert(result);

                    case 13:
                      this.back();

                    case 14:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "presentAlert",
          value: function presentAlert(result) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var message, alert;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      message = result ? 'Новый пароль был отправлен на вашу почту.' : 'Не удалось сбросить пароль.';
                      _context3.next = 3;
                      return this.alertController.create({
                        header: 'Сброс пароля',
                        message: message,
                        buttons: ['Понятно']
                      });

                    case 3:
                      alert = _context3.sent;
                      _context3.next = 6;
                      return alert.present();

                    case 6:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }]);

        return PopupDropPassComponent;
      }();

      PopupDropPassComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }, {
          type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_6__["ApiUserService"]
        }, {
          type: _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }];
      };

      PopupDropPassComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-popup-drop-pass',
        template: _raw_loader_popup_drop_pass_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_popup_drop_pass_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PopupDropPassComponent);
      /***/
    },

    /***/
    "5l+B":
    /*!****************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/page-tabs-user.component.ts ***!
      \****************************************************************************/

    /*! exports provided: PageTabsUserComponent */

    /***/
    function lB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsUserComponent", function () {
        return PageTabsUserComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_user_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-user.component.html */
      "tXLs");
      /* harmony import */


      var _page_tabs_user_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-user.component.scss */
      "Ic2J");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../@core/services/user-info.service */
      "tTdR");
      /* harmony import */


      var _core_abstractions_RxJsUnsubscriber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../../@core/abstractions/RxJsUnsubscriber */
      "IB9i");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");

      var PageTabsUserComponent = /*#__PURE__*/function (_core_abstractions_Rx) {
        _inherits(PageTabsUserComponent, _core_abstractions_Rx);

        var _super2 = _createSuper(PageTabsUserComponent);

        function PageTabsUserComponent(userService) {
          var _this2;

          _classCallCheck(this, PageTabsUserComponent);

          _this2 = _super2.call(this);
          _this2.userService = userService;
          _this2.tabName = 'user';
          _this2.userInfo$ = _this2.userService.authUser$.asObservable();
          _this2.pageType$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]('auth');
          return _this2;
        }

        _createClass(PageTabsUserComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.autoPageTypeChanger();
          }
        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            _get(_getPrototypeOf(PageTabsUserComponent.prototype), "ngOnDestroy", this).call(this);
          }
        }, {
          key: "exitAccount",
          value: function exitAccount() {
            this.userService.clearUser();
          }
        }, {
          key: "switchPage",
          value: function switchPage(type) {
            if (this.pageType$.getValue() === type) {
              return;
            }

            this.pageType$.next(type);
          }
        }, {
          key: "autoPageTypeChanger",
          value: function autoPageTypeChanger() {
            var _this3 = this;

            this.userService.authUser$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["takeUntil"])(this.unsubscribe$)).subscribe(function (x) {
              if (x) {
                _this3.pageType$.next('auth');
              } else {
                _this3.pageType$.next('login');
              }
            });
          }
        }]);

        return PageTabsUserComponent;
      }(_core_abstractions_RxJsUnsubscriber__WEBPACK_IMPORTED_MODULE_6__["RxJsUnsubscriber"]);

      PageTabsUserComponent.ctorParameters = function () {
        return [{
          type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_5__["UserInfoService"]
        }];
      };

      PageTabsUserComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-user',
        template: _raw_loader_page_tabs_user_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_user_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsUserComponent);
      /***/
    },

    /***/
    "6iwe":
    /*!*************************************************************************!*\
      !*** ./src/app/popups/popup-change-pass/popup-change-pass.component.ts ***!
      \*************************************************************************/

    /*! exports provided: PopupChangePassComponent */

    /***/
    function iwe(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PopupChangePassComponent", function () {
        return PopupChangePassComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_popup_change_pass_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./popup-change-pass.component.html */
      "ZBtC");
      /* harmony import */


      var _popup_change_pass_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./popup-change-pass.component.scss */
      "D0FE");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../@core/services/api/api-user.service */
      "lA1K");
      /* harmony import */


      var _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../@core/services/loading.service */
      "IpGr");

      var PopupChangePassComponent = /*#__PURE__*/function () {
        function PopupChangePassComponent(modalCtrl, apiUserService, loadingService, alertController) {
          _classCallCheck(this, PopupChangePassComponent);

          this.modalCtrl = modalCtrl;
          this.apiUserService = apiUserService;
          this.loadingService = loadingService;
          this.alertController = alertController;
          this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"]({
            oldPass: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''),
            newPass: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](''),
            repeatPass: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('')
          }, [matchValidator]);
        }

        _createClass(PopupChangePassComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "back",
          value: function back() {
            this.modalCtrl.dismiss().then();
          }
        }, {
          key: "changePass",
          value: function changePass() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var result;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      this.form.markAsTouched();
                      this.form.markAllAsTouched();

                      if (this.form.valid) {
                        _context4.next = 4;
                        break;
                      }

                      return _context4.abrupt("return");

                    case 4:
                      _context4.next = 6;
                      return this.loadingService.startLoading();

                    case 6:
                      _context4.next = 8;
                      return this.apiUserService.refreshPassword(this.form.value.oldPass, this.form.value.newPass);

                    case 8:
                      result = _context4.sent;
                      _context4.next = 11;
                      return this.loadingService.stopLoading();

                    case 11:
                      _context4.next = 13;
                      return this.presentAlert(result);

                    case 13:
                      this.back();

                    case 14:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "presentAlert",
          value: function presentAlert(result) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var message, alert;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      message = result ? 'Пароль успешно изменен.' : 'Не удалось изменить пароль.';
                      _context5.next = 3;
                      return this.alertController.create({
                        header: 'Смена пароля',
                        message: message,
                        buttons: ['Понятно']
                      });

                    case 3:
                      alert = _context5.sent;
                      _context5.next = 6;
                      return alert.present();

                    case 6:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }]);

        return PopupChangePassComponent;
      }();

      PopupChangePassComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }, {
          type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_6__["ApiUserService"]
        }, {
          type: _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"]
        }];
      };

      PopupChangePassComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-popup-change-pass',
        template: _raw_loader_popup_change_pass_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_popup_change_pass_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PopupChangePassComponent);

      function matchValidator(group) {
        var values = [group.value.newPass, group.value.repeatPass];

        if (values[0] !== '' && values[0] === values[1]) {
          console.log('validate', values);
          return null;
        }

        console.log('validate error');
        return {
          mismatch: {
            message: 'Values are not equal'
          }
        };
      }
      /***/

    },

    /***/
    "7xk4":
    /*!****************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-regbutton/page-tabs-user-regbutton.component.scss ***!
      \****************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function xk4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  display: flex;\n  width: inherit;\n  height: 3.94vh;\n  border: 0.12vh solid #dddfe3;\n  border-radius: 0.98vh;\n  box-sizing: border-box;\n}\n.container .button {\n  width: 100%;\n  font-size: 1.72vh;\n  font-weight: 600;\n  text-align: center;\n  line-height: 3.7vh;\n  color: #6B7683;\n  transition: 0.2s;\n}\n.container .button__active {\n  border-radius: 0.98vh;\n  color: #EAEDF5;\n  background: #2CB172;\n  transition: 0.2s;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy11c2VyLXJlZ2J1dHRvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLDRCQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtBQUNGO0FBQ0U7RUFDRSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFDSjtBQUNJO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUNOIiwiZmlsZSI6InBhZ2UtdGFicy11c2VyLXJlZ2J1dHRvbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICB3aWR0aDogaW5oZXJpdDtcbiAgaGVpZ2h0OiAzLjk0dmg7XG4gIGJvcmRlcjogMC4xMnZoIHNvbGlkICNkZGRmZTM7XG4gIGJvcmRlci1yYWRpdXM6IDAuOTh2aDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcblxuICAuYnV0dG9uIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBmb250LXNpemU6IDEuNzJ2aDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBsaW5lLWhlaWdodDogMy43dmg7XG4gICAgY29sb3I6ICM2Qjc2ODM7XG4gICAgdHJhbnNpdGlvbjogLjJzO1xuXG4gICAgJl9fYWN0aXZlIHtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDAuOTh2aDtcbiAgICAgIGNvbG9yOiAjRUFFREY1O1xuICAgICAgYmFja2dyb3VuZDogIzJDQjE3MjtcbiAgICAgIHRyYW5zaXRpb246IC4ycztcbiAgICB9XG4gIH1cbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "8Pie":
    /*!***************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-auth/page-tabs-user-screen-auth.component.scss ***!
      \***************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Pie(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ":host {\n  height: 100%;\n  display: inherit;\n  flex-flow: inherit;\n  gap: inherit;\n}\n\n.forget-password {\n  font-size: 1.72vh;\n  margin-bottom: 1.97vh;\n}\n\n.menu-container {\n  display: flex;\n  flex-flow: column;\n  flex-grow: 1;\n  padding-bottom: 1.97vh;\n  margin: 0 -4.27vw;\n}\n\n.forget-password {\n  font-size: 1.72vh;\n  margin-bottom: 1.97vh;\n  color: #2CB172;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy11c2VyLXNjcmVlbi1hdXRoLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtFQUNBLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7QUFDRiIsImZpbGUiOiJwYWdlLXRhYnMtdXNlci1zY3JlZW4tYXV0aC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgaGVpZ2h0OiAxMDAlO1xuICBkaXNwbGF5OiBpbmhlcml0O1xuICBmbGV4LWZsb3c6IGluaGVyaXQ7XG4gIGdhcDogaW5oZXJpdDtcbn1cblxuLmZvcmdldC1wYXNzd29yZCB7XG4gIGZvbnQtc2l6ZTogMS43MnZoO1xuICBtYXJnaW4tYm90dG9tOiAxLjk3dmg7XG59XG5cbi5tZW51LWNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBmbGV4LWdyb3c6IDE7XG4gIHBhZGRpbmctYm90dG9tOiAxLjk3dmg7XG4gIG1hcmdpbjogMCAtNC4yN3Z3O1xufVxuXG4uZm9yZ2V0LXBhc3N3b3JkIHtcbiAgZm9udC1zaXplOiAxLjcydmg7XG4gIG1hcmdpbi1ib3R0b206IDEuOTd2aDtcbiAgY29sb3I6ICMyQ0IxNzI7XG59XG4iXX0= */";
      /***/
    },

    /***/
    "9XtX":
    /*!******************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/browser.js ***!
      \******************************************************************************************************************/

    /*! exports provided: BrowserPluginWeb, Browser */

    /***/
    function XtX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BrowserPluginWeb", function () {
        return BrowserPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Browser", function () {
        return Browser;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var BrowserPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(BrowserPluginWeb, _super);

        function BrowserPluginWeb() {
          return _super.call(this, {
            name: 'Browser',
            platforms: ['web']
          }) || this;
        }

        BrowserPluginWeb.prototype.open = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              this._lastWindow = window.open(options.url, options.windowName || '_blank');
              return [2
              /*return*/
              , Promise.resolve()];
            });
          });
        };

        BrowserPluginWeb.prototype.prefetch = function (_options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              // Does nothing
              return [2
              /*return*/
              , Promise.resolve()];
            });
          });
        };

        BrowserPluginWeb.prototype.close = function () {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              this._lastWindow && this._lastWindow.close();
              return [2
              /*return*/
              , Promise.resolve()];
            });
          });
        };

        return BrowserPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Browser = new BrowserPluginWeb(); //# sourceMappingURL=browser.js.map

      /***/
    },

    /***/
    "BTHi":
    /*!*************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/page-tabs-user.module.ts ***!
      \*************************************************************************/

    /*! exports provided: PageTabsUserModule */

    /***/
    function BTHi(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsUserModule", function () {
        return PageTabsUserModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _page_tabs_user_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./page-tabs-user.component */
      "5l+B");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _components_page_tabs_user_regbutton_page_tabs_user_regbutton_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./components/page-tabs-user-regbutton/page-tabs-user-regbutton.component */
      "t250");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../../@shared/shared.module */
      "pk6O");
      /* harmony import */


      var _components_page_tabs_user_outsource_page_tabs_user_outsource_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./components/page-tabs-user-outsource/page-tabs-user-outsource.component */
      "XOtm");
      /* harmony import */


      var _components_page_tabs_user_menu_page_tabs_user_menu_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./components/page-tabs-user-menu/page-tabs-user-menu.component */
      "P1Zj");
      /* harmony import */


      var _pages_page_tabs_user_screen_login_page_tabs_user_screen_login_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./pages/page-tabs-user-screen-login/page-tabs-user-screen-login.component */
      "kRvs");
      /* harmony import */


      var _pages_page_tabs_user_screen_reg_page_tabs_user_screen_reg_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ./pages/page-tabs-user-screen-reg/page-tabs-user-screen-reg.component */
      "2yLI");
      /* harmony import */


      var _popups_popup_feedback_popup_feedback_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ../../../popups/popup-feedback/popup-feedback.module */
      "gEHV");
      /* harmony import */


      var _pages_page_tabs_user_screen_auth_page_tabs_user_screen_auth_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ./pages/page-tabs-user-screen-auth/page-tabs-user-screen-auth.component */
      "s/pR");
      /* harmony import */


      var _popups_popup_change_pass_popup_change_pass_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! ../../../popups/popup-change-pass/popup-change-pass.module */
      "fhDh");
      /* harmony import */


      var _popups_popup_drop_pass_popup_drop_pass_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ../../../popups/popup-drop-pass/popup-drop-pass.module */
      "L+UL");

      var PageTabsUserModule = function PageTabsUserModule() {
        _classCallCheck(this, PageTabsUserModule);
      };

      PageTabsUserModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_tabs_user_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsUserComponent"], _components_page_tabs_user_regbutton_page_tabs_user_regbutton_component__WEBPACK_IMPORTED_MODULE_5__["PageTabsUserRegbuttonComponent"], _components_page_tabs_user_outsource_page_tabs_user_outsource_component__WEBPACK_IMPORTED_MODULE_7__["PageTabsUserOutsourceComponent"], _components_page_tabs_user_menu_page_tabs_user_menu_component__WEBPACK_IMPORTED_MODULE_8__["PageTabsUserMenuComponent"], _pages_page_tabs_user_screen_login_page_tabs_user_screen_login_component__WEBPACK_IMPORTED_MODULE_9__["PageTabsUserScreenLoginComponent"], _pages_page_tabs_user_screen_reg_page_tabs_user_screen_reg_component__WEBPACK_IMPORTED_MODULE_10__["PageTabsUserScreenRegComponent"], _pages_page_tabs_user_screen_auth_page_tabs_user_screen_auth_component__WEBPACK_IMPORTED_MODULE_12__["PageTabsUserScreenAuthComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__["SharedModule"], _popups_popup_feedback_popup_feedback_module__WEBPACK_IMPORTED_MODULE_11__["PopupFeedbackModule"], _popups_popup_change_pass_popup_change_pass_module__WEBPACK_IMPORTED_MODULE_13__["PopupChangePassModule"], _popups_popup_drop_pass_popup_drop_pass_module__WEBPACK_IMPORTED_MODULE_14__["PopupDropPassModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
          path: '',
          component: _page_tabs_user_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsUserComponent"]
        }])]
      })], PageTabsUserModule);
      /***/
    },

    /***/
    "Como":
    /*!*******************************!*\
      !*** ./capacitor.config.json ***!
      \*******************************/

    /*! exports provided: appId, appName, bundledWebRuntime, npmClient, webDir, orientation, plugins, cordova, default */

    /***/
    function Como(module) {
      module.exports = JSON.parse("{\"appId\":\"com.luc.app\",\"appName\":\"LUC\",\"bundledWebRuntime\":false,\"npmClient\":\"npm\",\"webDir\":\"www\",\"orientation\":\"portrait\",\"plugins\":{\"SplashScreen\":{\"launchShowDuration\":500,\"androidScaleType\":\"CENTER_CROP\"},\"GoogleAuth\":{\"scopes\":[\"profile\",\"email\"],\"serverClientId\":\"345754396950-9ie0u4sfo1h1q1c0bl7rgep9tkjau18l.apps.googleusercontent.com\",\"forceCodeForRefreshToken\":true}},\"cordova\":{}}");
      /***/
    },

    /***/
    "D0FE":
    /*!***************************************************************************!*\
      !*** ./src/app/popups/popup-change-pass/popup-change-pass.component.scss ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function D0FE(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".page-wrapper {\n  display: flex;\n  flex-flow: column;\n  height: 100%;\n  padding: 3.7vh 0;\n}\n\n.header {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n  padding: 0 2.2vh;\n  box-sizing: border-box;\n}\n\n.header > * {\n  margin: auto 0;\n}\n\n.header .label {\n  text-align: center;\n  font-size: 2.1vh;\n  font-weight: 600;\n  color: #222222;\n}\n\n.header .icon {\n  width: 2.43vh;\n  height: 2.43vh;\n  color: #2CB172;\n}\n\n.form {\n  display: flex;\n  flex-flow: column;\n  flex-grow: 1;\n  gap: 1.97vh;\n  padding: 0 4.27vw;\n  margin-top: 5vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BvcHVwLWNoYW5nZS1wYXNzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtBQUNGOztBQUNFO0VBQ0UsY0FBQTtBQUNKOztBQUVFO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUFKOztBQUdFO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0FBREo7O0FBS0E7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQUZGIiwiZmlsZSI6InBvcHVwLWNoYW5nZS1wYXNzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnBhZ2Utd3JhcHBlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHBhZGRpbmc6IDMuN3ZoIDA7XG59XG5cbi5oZWFkZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICB3aWR0aDogMTAwJTtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBwYWRkaW5nOiAwIDIuMnZoO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuXG4gICYgPiAqIHtcbiAgICBtYXJnaW46IGF1dG8gMDtcbiAgfVxuXG4gIC5sYWJlbCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMi4xdmg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgfVxuXG4gIC5pY29uIHtcbiAgICB3aWR0aDogMi40M3ZoO1xuICAgIGhlaWdodDogMi40M3ZoO1xuICAgIGNvbG9yOiAjMkNCMTcyO1xuICB9XG59XG5cbi5mb3JtIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIGZsZXgtZ3JvdzogMTtcbiAgZ2FwOiAxLjk3dmg7XG4gIHBhZGRpbmc6IDAgNC4yN3Z3O1xuICBtYXJnaW4tdG9wOiA1dmg7XG59XG4iXX0= */";
      /***/
    },

    /***/
    "FUmq":
    /*!******************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web-runtime.js ***!
      \******************************************************************************************************************/

    /*! exports provided: CapacitorWeb */

    /***/
    function FUmq(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CapacitorWeb", function () {
        return CapacitorWeb;
      });

      var CapacitorWeb =
      /** @class */
      function () {
        function CapacitorWeb() {
          var _this = this;

          this.platform = 'web';
          this.isNative = false; // Need to assign here to avoid having to define every plugin but still
          // get the typed benefits of the provided plugins in PluginRegistry

          this.Plugins = {}; // Gracefully degrade in non-Proxy supporting engines, e.g. IE11. This
          // effectively means that trying to access an unavailable plugin will
          // locally throw, but this is still better than throwing a syntax error.

          if (typeof Proxy !== 'undefined') {
            // Build a proxy for the Plugins object that returns the "Noop Plugin"
            // if a plugin isn't available
            this.Plugins = new Proxy(this.Plugins, {
              get: function get(target, prop) {
                if (typeof target[prop] === 'undefined') {
                  var thisRef_1 = _this;
                  return new Proxy({}, {
                    get: function get(_target, _prop) {
                      if (typeof _target[_prop] === 'undefined') {
                        return thisRef_1.pluginMethodNoop.bind(thisRef_1, _target, _prop, prop);
                      } else {
                        return _target[_prop];
                      }
                    }
                  });
                } else {
                  return target[prop];
                }
              }
            });
          }
        }

        CapacitorWeb.prototype.pluginMethodNoop = function (_target, _prop, pluginName) {
          return Promise.reject(pluginName + " does not have web implementation.");
        };

        CapacitorWeb.prototype.getPlatform = function () {
          return this.platform;
        };

        CapacitorWeb.prototype.isPluginAvailable = function (name) {
          return this.Plugins.hasOwnProperty(name);
        };

        CapacitorWeb.prototype.convertFileSrc = function (filePath) {
          return filePath;
        };

        CapacitorWeb.prototype.handleError = function (e) {
          console.error(e);
        };

        return CapacitorWeb;
      }(); //# sourceMappingURL=web-runtime.js.map

      /***/

    },

    /***/
    "Gwgb":
    /*!*****************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/motion.js ***!
      \*****************************************************************************************************************/

    /*! exports provided: MotionPluginWeb, Motion */

    /***/
    function Gwgb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MotionPluginWeb", function () {
        return MotionPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Motion", function () {
        return Motion;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var MotionPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(MotionPluginWeb, _super);

        function MotionPluginWeb() {
          var _this = _super.call(this, {
            name: 'Motion'
          }) || this;

          _this.registerWindowListener('devicemotion', 'accel');

          _this.registerWindowListener('deviceorientation', 'orientation');

          return _this;
        }

        return MotionPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Motion = new MotionPluginWeb(); //# sourceMappingURL=motion.js.map

      /***/
    },

    /***/
    "HGlX":
    /*!**************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/app.js ***!
      \**************************************************************************************************************/

    /*! exports provided: AppPluginWeb, App */

    /***/
    function HGlX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppPluginWeb", function () {
        return AppPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "App", function () {
        return App;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var AppPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(AppPluginWeb, _super);

        function AppPluginWeb() {
          var _this = _super.call(this, {
            name: 'App',
            platforms: ['web']
          }) || this;

          if (typeof document !== 'undefined') {
            document.addEventListener('visibilitychange', _this.handleVisibilityChange.bind(_this), false);
          }

          return _this;
        }

        AppPluginWeb.prototype.exitApp = function () {
          throw new Error('Method not implemented.');
        };

        AppPluginWeb.prototype.canOpenUrl = function (_options) {
          return Promise.resolve({
            value: true
          });
        };

        AppPluginWeb.prototype.openUrl = function (_options) {
          return Promise.resolve({
            completed: true
          });
        };

        AppPluginWeb.prototype.getLaunchUrl = function () {
          return Promise.resolve({
            url: ''
          });
        };

        AppPluginWeb.prototype.getState = function () {
          return Promise.resolve({
            isActive: document.hidden !== true
          });
        };

        AppPluginWeb.prototype.handleVisibilityChange = function () {
          var data = {
            isActive: document.hidden !== true
          };
          this.notifyListeners('appStateChange', data);
        };

        return AppPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var App = new AppPluginWeb(); //# sourceMappingURL=app.js.map

      /***/
    },

    /***/
    "IB9i":
    /*!********************************************************!*\
      !*** ./src/app/@core/abstractions/RxJsUnsubscriber.ts ***!
      \********************************************************/

    /*! exports provided: RxJsUnsubscriber */

    /***/
    function IB9i(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RxJsUnsubscriber", function () {
        return RxJsUnsubscriber;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /**
       * use for takeUntil(unsubscribe$)
       */


      var RxJsUnsubscriber = /*#__PURE__*/function () {
        function RxJsUnsubscriber() {
          _classCallCheck(this, RxJsUnsubscriber);

          this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        }

        _createClass(RxJsUnsubscriber, [{
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            this.unsubscribe$.next();
            this.unsubscribe$.complete();
          }
        }]);

        return RxJsUnsubscriber;
      }();

      RxJsUnsubscriber.ctorParameters = function () {
        return [];
      };

      RxJsUnsubscriber = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Directive"])() // tslint:disable-next-line:directive-class-suffix
      ], RxJsUnsubscriber);
      /***/
    },

    /***/
    "Ic2J":
    /*!******************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/page-tabs-user.component.scss ***!
      \******************************************************************************/

    /*! exports provided: default */

    /***/
    function Ic2J(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  display: flex;\n  flex-flow: column;\n  width: 100%;\n  height: 100%;\n  gap: 1.97vh;\n  padding: 0 4.27vw;\n  box-sizing: border-box;\n  overflow: hidden;\n  background: white;\n}\n.container .header {\n  font-size: 2.71vh;\n  font-weight: 700;\n  color: #222222;\n  margin-top: 2.46vh;\n}\n.container .subheader {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 1.97vh;\n  font-size: 1.9vh;\n  font-weight: 400;\n  color: #222222;\n}\n.container .subheader a {\n  color: #2CB172;\n}\n.container .page-wrapper {\n  overflow-y: auto;\n  overflow-x: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy11c2VyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFDRjtBQUNFO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUNKO0FBRUU7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBQUo7QUFNSTtFQUNFLGNBQUE7QUFKTjtBQVFFO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQU5KIiwiZmlsZSI6InBhZ2UtdGFicy11c2VyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBnYXA6IDEuOTd2aDtcbiAgcGFkZGluZzogMCA0LjI3dnc7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuXG4gIC5oZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogMi43MXZoO1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgY29sb3I6ICMyMjIyMjI7XG4gICAgbWFyZ2luLXRvcDogMi40NnZoO1xuICB9XG5cbiAgLnN1YmhlYWRlciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgbWFyZ2luLWJvdHRvbTogMS45N3ZoO1xuICAgIGZvbnQtc2l6ZTogMS45dmg7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcblxuICAgICZfX2V4aXQge1xuXG4gICAgfVxuXG4gICAgYSB7XG4gICAgICBjb2xvcjogIzJDQjE3MjtcbiAgICB9XG4gIH1cblxuICAucGFnZS13cmFwcGVyIHtcbiAgICBvdmVyZmxvdy15OiBhdXRvO1xuICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgfVxufVxuXG5cbiJdfQ== */";
      /***/
    },

    /***/
    "Ik3O":
    /*!******************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-menu/page-tabs-user-menu.component.scss ***!
      \******************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Ik3O(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  display: flex;\n  height: 64px;\n  width: 100%;\n  padding: 0 6.93vw;\n  box-sizing: border-box;\n}\n.container > * {\n  margin: auto 0;\n}\n.container .ion-ripple-color {\n  color: lightgray;\n}\n.container .title {\n  flex-grow: 1;\n  font-size: 1.97vh;\n  font-weight: 500;\n  color: #222222;\n}\n.container .main-icon {\n  width: 2.46vh;\n  height: 2.46vh;\n  color: #99A0AB;\n  margin-right: 7.5vw;\n}\n.container .icon-wrapper {\n  width: 1.43vh;\n  height: 1.43vh;\n  transform: scaleX(-1);\n}\n.container .icon-wrapper .icon {\n  color: #6B7683;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy11c2VyLW1lbnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0FBQ0Y7QUFDRTtFQUNFLGNBQUE7QUFDSjtBQUVFO0VBQ0UsZ0JBQUE7QUFBSjtBQUdFO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBREo7QUFJRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FBRko7QUFLRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EscUJBQUE7QUFISjtBQUtJO0VBQ0UsY0FBQTtBQUhOIiwiZmlsZSI6InBhZ2UtdGFicy11c2VyLW1lbnUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiA2NHB4O1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZzogMCA2Ljkzdnc7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG5cbiAgJiA+ICoge1xuICAgIG1hcmdpbjogYXV0byAwO1xuICB9XG5cbiAgLmlvbi1yaXBwbGUtY29sb3Ige1xuICAgIGNvbG9yOiBsaWdodGdyYXk7XG4gIH1cblxuICAudGl0bGUge1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBmb250LXNpemU6IDEuOTd2aDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGNvbG9yOiAjMjIyMjIyO1xuICB9XG5cbiAgLm1haW4taWNvbiB7XG4gICAgd2lkdGg6IDIuNDZ2aDtcbiAgICBoZWlnaHQ6IDIuNDZ2aDtcbiAgICBjb2xvcjogIzk5QTBBQjtcbiAgICBtYXJnaW4tcmlnaHQ6IDcuNXZ3O1xuICB9XG5cbiAgLmljb24td3JhcHBlciB7XG4gICAgd2lkdGg6IDEuNDN2aDtcbiAgICBoZWlnaHQ6IDEuNDN2aDtcbiAgICB0cmFuc2Zvcm06IHNjYWxlWCgtMSk7XG5cbiAgICAuaWNvbiB7XG4gICAgICBjb2xvcjogIzZCNzY4MztcbiAgICB9XG4gIH1cbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "J2Oh":
    /*!******************************************************************!*\
      !*** ./src/app/@core/services/outsource-auth/vk-auth.service.ts ***!
      \******************************************************************/

    /*! exports provided: VkAuthService */

    /***/
    function J2Oh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "VkAuthService", function () {
        return VkAuthService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../platform/app-config.service */
      "ophu");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @capacitor/core */
      "gcOT");

      var VkAuthService = /*#__PURE__*/function () {
        function VkAuthService(http, appConfigService) {
          _classCallCheck(this, VkAuthService);

          this.http = http;
          this.appConfigService = appConfigService;
          this.vkAuthEndpoint = 'https://oauth.vk.com/authorize';
          this.vkAuthParams = {
            client_id: '7669704',
            redirect_uri: "".concat(this.appConfigService.locationOrigin, "/main/tabs/user"),
            // redirect_uri: `https://oauth.vk.com/blank.html`,
            response_type: 'token',
            display: 'mobile',
            scope: 'offline',
            state: 'vk'
          };
        }

        _createClass(VkAuthService, [{
          key: "authRequest",
          value: function authRequest() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var _this4 = this;

              var uri;
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      uri = "".concat(this.vkAuthEndpoint, "?");
                      uri += Object.keys(this.vkAuthParams).map(function (x) {
                        return "".concat(x, "=").concat(_this4.vkAuthParams[x]);
                      }).join('&');
                      _context6.next = 4;
                      return _capacitor_core__WEBPACK_IMPORTED_MODULE_4__["Browser"].open({
                        url: uri,
                        presentationStyle: 'popover'
                      });

                    case 4:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "authRequestPlugin",
          value: function authRequestPlugin() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              var VKAuth, init, scope;
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      VKAuth = _capacitor_core__WEBPACK_IMPORTED_MODULE_4__["Plugins"].VKAuth;
                      _context7.next = 3;
                      return VKAuth.initWithId({
                        id: '7731427'
                      });

                    case 3:
                      init = _context7.sent;
                      _context7.next = 6;
                      return VKAuth.auth({
                        scope: ['offline']
                      });

                    case 6:
                      scope = _context7.sent;
                      return _context7.abrupt("return", new Promise(function (resolve, reject) {
                        VKAuth.addListener('vkAuthFinished', function (info) {
                          console.log('vkAuthFinished was fired', JSON.stringify(info, null, 2));
                          resolve(info.token);
                        });
                      }));

                    case 8:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7);
            }));
          }
        }]);

        return VkAuthService;
      }();

      VkAuthService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
        }, {
          type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"]
        }];
      };

      VkAuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], VkAuthService);
      /***/
    },

    /***/
    "JCnY":
    /*!************************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/splash-screen.js ***!
      \************************************************************************************************************************/

    /*! exports provided: SplashScreenPluginWeb, SplashScreen */

    /***/
    function JCnY(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SplashScreenPluginWeb", function () {
        return SplashScreenPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SplashScreen", function () {
        return SplashScreen;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var SplashScreenPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SplashScreenPluginWeb, _super);

        function SplashScreenPluginWeb() {
          return _super.call(this, {
            name: 'SplashScreen',
            platforms: ['web']
          }) || this;
        }

        SplashScreenPluginWeb.prototype.show = function (_options, _callback) {
          return Promise.resolve();
        };

        SplashScreenPluginWeb.prototype.hide = function (_options, _callback) {
          return Promise.resolve();
        };

        return SplashScreenPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var SplashScreen = new SplashScreenPluginWeb(); //# sourceMappingURL=splash-screen.js.map

      /***/
    },

    /***/
    "JE9H":
    /*!*************************************************************!*\
      !*** ./src/app/@core/services/platform/rate-app.service.ts ***!
      \*************************************************************/

    /*! exports provided: RateAppService */

    /***/
    function JE9H(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RateAppService", function () {
        return RateAppService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_native_app_rate_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic-native/app-rate/ngx */
      "k0k6");

      var RateAppService = /*#__PURE__*/function () {
        function RateAppService(appRate) {
          _classCallCheck(this, RateAppService);

          this.appRate = appRate;
        }

        _createClass(RateAppService, [{
          key: "rateUs",
          value: function rateUs() {
            this.appRate.preferences = {
              usesUntilPrompt: 5,
              useLanguage: 'en',
              displayAppName: 'LUC',
              storeAppURL: {
                android: 'market://details?id=com.luc.app'
              }
            };
            this.appRate.promptForRating(true);
          }
        }]);

        return RateAppService;
      }();

      RateAppService.ctorParameters = function () {
        return [{
          type: _ionic_native_app_rate_ngx__WEBPACK_IMPORTED_MODULE_2__["AppRate"]
        }];
      };

      RateAppService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], RateAppService);
      /***/
    },

    /***/
    "JprH":
    /*!******************************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-outsource/page-tabs-user-outsource.component.html ***!
      \******************************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function JprH(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container\">\n  <div class=\"label\"> или войдите с помощью </div>\n  <div class=\"icon-container\">\n    <svg-icon (click)=\"googleAuth()\" src=\"assets/icon/svg/auth/google.svg\"></svg-icon>\n<!--    <svg-icon (click)=\"vkAuth()\" src=\"assets/icon/svg/auth/vk.svg\"></svg-icon>-->\n<!--    <svg-icon src=\"assets/icon/svg/auth/facebook.svg\"></svg-icon>-->\n  </div>\n</div>\n";
      /***/
    },

    /***/
    "KGk9":
    /*!******************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web-plugins.js ***!
      \******************************************************************************************************************/

    /*! exports provided: AccessibilityPluginWeb, Accessibility, AppPluginWeb, App, BrowserPluginWeb, Browser, CameraPluginWeb, Camera, ClipboardPluginWeb, Clipboard, FilesystemPluginWeb, Filesystem, GeolocationPluginWeb, Geolocation, DevicePluginWeb, Device, LocalNotificationsPluginWeb, LocalNotifications, SharePluginWeb, Share, ModalsPluginWeb, Modals, MotionPluginWeb, Motion, NetworkPluginWeb, Network, PermissionsPluginWeb, Permissions, SplashScreenPluginWeb, SplashScreen, StoragePluginWeb, Storage, ToastPluginWeb, Toast, registerWebPlugin */

    /***/
    function KGk9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "registerWebPlugin", function () {
        return registerWebPlugin;
      });
      /* harmony import */


      var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./global */
      "dUEc");
      /* harmony import */


      var _web_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./web/index */
      "gHRE");
      /* harmony import */


      var _web_accessibility__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./web/accessibility */
      "rE3Y");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "AccessibilityPluginWeb", function () {
        return _web_accessibility__WEBPACK_IMPORTED_MODULE_2__["AccessibilityPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Accessibility", function () {
        return _web_accessibility__WEBPACK_IMPORTED_MODULE_2__["Accessibility"];
      });
      /* harmony import */


      var _web_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./web/app */
      "HGlX");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "AppPluginWeb", function () {
        return _web_app__WEBPACK_IMPORTED_MODULE_3__["AppPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "App", function () {
        return _web_app__WEBPACK_IMPORTED_MODULE_3__["App"];
      });
      /* harmony import */


      var _web_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./web/browser */
      "9XtX");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "BrowserPluginWeb", function () {
        return _web_browser__WEBPACK_IMPORTED_MODULE_4__["BrowserPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Browser", function () {
        return _web_browser__WEBPACK_IMPORTED_MODULE_4__["Browser"];
      });
      /* harmony import */


      var _web_camera__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./web/camera */
      "yKy8");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "CameraPluginWeb", function () {
        return _web_camera__WEBPACK_IMPORTED_MODULE_5__["CameraPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Camera", function () {
        return _web_camera__WEBPACK_IMPORTED_MODULE_5__["Camera"];
      });
      /* harmony import */


      var _web_clipboard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./web/clipboard */
      "ipqe");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "ClipboardPluginWeb", function () {
        return _web_clipboard__WEBPACK_IMPORTED_MODULE_6__["ClipboardPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Clipboard", function () {
        return _web_clipboard__WEBPACK_IMPORTED_MODULE_6__["Clipboard"];
      });
      /* harmony import */


      var _web_filesystem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./web/filesystem */
      "LIGA");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "FilesystemPluginWeb", function () {
        return _web_filesystem__WEBPACK_IMPORTED_MODULE_7__["FilesystemPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Filesystem", function () {
        return _web_filesystem__WEBPACK_IMPORTED_MODULE_7__["Filesystem"];
      });
      /* harmony import */


      var _web_geolocation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./web/geolocation */
      "uBk0");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "GeolocationPluginWeb", function () {
        return _web_geolocation__WEBPACK_IMPORTED_MODULE_8__["GeolocationPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Geolocation", function () {
        return _web_geolocation__WEBPACK_IMPORTED_MODULE_8__["Geolocation"];
      });
      /* harmony import */


      var _web_device__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./web/device */
      "4NFK");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "DevicePluginWeb", function () {
        return _web_device__WEBPACK_IMPORTED_MODULE_9__["DevicePluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Device", function () {
        return _web_device__WEBPACK_IMPORTED_MODULE_9__["Device"];
      });
      /* harmony import */


      var _web_local_notifications__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ./web/local-notifications */
      "QMQ/");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "LocalNotificationsPluginWeb", function () {
        return _web_local_notifications__WEBPACK_IMPORTED_MODULE_10__["LocalNotificationsPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "LocalNotifications", function () {
        return _web_local_notifications__WEBPACK_IMPORTED_MODULE_10__["LocalNotifications"];
      });
      /* harmony import */


      var _web_share__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ./web/share */
      "OlAk");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "SharePluginWeb", function () {
        return _web_share__WEBPACK_IMPORTED_MODULE_11__["SharePluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Share", function () {
        return _web_share__WEBPACK_IMPORTED_MODULE_11__["Share"];
      });
      /* harmony import */


      var _web_modals__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ./web/modals */
      "Otlp");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "ModalsPluginWeb", function () {
        return _web_modals__WEBPACK_IMPORTED_MODULE_12__["ModalsPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Modals", function () {
        return _web_modals__WEBPACK_IMPORTED_MODULE_12__["Modals"];
      });
      /* harmony import */


      var _web_motion__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! ./web/motion */
      "Gwgb");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "MotionPluginWeb", function () {
        return _web_motion__WEBPACK_IMPORTED_MODULE_13__["MotionPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Motion", function () {
        return _web_motion__WEBPACK_IMPORTED_MODULE_13__["Motion"];
      });
      /* harmony import */


      var _web_network__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ./web/network */
      "kSrW");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "NetworkPluginWeb", function () {
        return _web_network__WEBPACK_IMPORTED_MODULE_14__["NetworkPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Network", function () {
        return _web_network__WEBPACK_IMPORTED_MODULE_14__["Network"];
      });
      /* harmony import */


      var _web_permissions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! ./web/permissions */
      "M3vd");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "PermissionsPluginWeb", function () {
        return _web_permissions__WEBPACK_IMPORTED_MODULE_15__["PermissionsPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Permissions", function () {
        return _web_permissions__WEBPACK_IMPORTED_MODULE_15__["Permissions"];
      });
      /* harmony import */


      var _web_splash_screen__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! ./web/splash-screen */
      "JCnY");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "SplashScreenPluginWeb", function () {
        return _web_splash_screen__WEBPACK_IMPORTED_MODULE_16__["SplashScreenPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "SplashScreen", function () {
        return _web_splash_screen__WEBPACK_IMPORTED_MODULE_16__["SplashScreen"];
      });
      /* harmony import */


      var _web_storage__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
      /*! ./web/storage */
      "xlCS");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "StoragePluginWeb", function () {
        return _web_storage__WEBPACK_IMPORTED_MODULE_17__["StoragePluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Storage", function () {
        return _web_storage__WEBPACK_IMPORTED_MODULE_17__["Storage"];
      });
      /* harmony import */


      var _web_toast__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
      /*! ./web/toast */
      "NZWm");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "ToastPluginWeb", function () {
        return _web_toast__WEBPACK_IMPORTED_MODULE_18__["ToastPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Toast", function () {
        return _web_toast__WEBPACK_IMPORTED_MODULE_18__["Toast"];
      });

      Object(_web_index__WEBPACK_IMPORTED_MODULE_1__["mergeWebPlugins"])(_global__WEBPACK_IMPORTED_MODULE_0__["Plugins"]);

      var registerWebPlugin = function registerWebPlugin(plugin) {
        Object(_web_index__WEBPACK_IMPORTED_MODULE_1__["mergeWebPlugin"])(_global__WEBPACK_IMPORTED_MODULE_0__["Plugins"], plugin);
      }; //# sourceMappingURL=web-plugins.js.map

      /***/

    },

    /***/
    "KlGS":
    /*!*******************************************************************!*\
      !*** ./src/app/popups/popup-feedback/popup-feedback.component.ts ***!
      \*******************************************************************/

    /*! exports provided: PopupFeedbackComponent */

    /***/
    function KlGS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PopupFeedbackComponent", function () {
        return PopupFeedbackComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_popup_feedback_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./popup-feedback.component.html */
      "uQ6z");
      /* harmony import */


      var _popup_feedback_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./popup-feedback.component.scss */
      "NkFm");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../@core/services/api/api-user.service */
      "lA1K");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var _core_services_loading_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../@core/services/loading.service */
      "IpGr");
      /* harmony import */


      var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../@core/services/user-info.service */
      "tTdR");

      var PopupFeedbackComponent = /*#__PURE__*/function () {
        function PopupFeedbackComponent(userService, loadingService, apiUserService, modalCtrl, alertController) {
          _classCallCheck(this, PopupFeedbackComponent);

          this.userService = userService;
          this.loadingService = loadingService;
          this.apiUserService = apiUserService;
          this.modalCtrl = modalCtrl;
          this.alertController = alertController;
          this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].email]),
            feedbackCategory: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]),
            message: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(3)])
          });
          this.email = '';
          this.themes$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["BehaviorSubject"]([]);
          this.selectionThemes$ = this.themes$.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["map"])(function (x) {
            return x.map(function (item) {
              return {
                value: item,
                title: item.nameRus
              };
            });
          }));
        }

        _createClass(PopupFeedbackComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.form.get('email').setValue(this.email);
            this.getThemes().then();
            this.form.valueChanges.subscribe(function (x) {
              return console.log(x);
            });
          }
        }, {
          key: "close",
          value: function close() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
              return regeneratorRuntime.wrap(function _callee8$(_context8) {
                while (1) {
                  switch (_context8.prev = _context8.next) {
                    case 0:
                      _context8.next = 2;
                      return this.modalCtrl.dismiss();

                    case 2:
                    case "end":
                      return _context8.stop();
                  }
                }
              }, _callee8, this);
            }));
          }
        }, {
          key: "send",
          value: function send() {
            var _a, _b, _c;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
              var userId, formData;
              return regeneratorRuntime.wrap(function _callee9$(_context9) {
                while (1) {
                  switch (_context9.prev = _context9.next) {
                    case 0:
                      this.form.markAsDirty();

                      if (this.form.valid) {
                        _context9.next = 3;
                        break;
                      }

                      return _context9.abrupt("return");

                    case 3:
                      userId = (_c = (_b = (_a = this.userService.authUser$) === null || _a === void 0 ? void 0 : _a.getValue()) === null || _b === void 0 ? void 0 : _b.id) !== null && _c !== void 0 ? _c : 0;
                      formData = Object.assign(Object.assign({}, this.form.value), {
                        userId: userId
                      });
                      _context9.next = 7;
                      return this.loadingService.startLoading();

                    case 7:
                      _context9.next = 9;
                      return this.apiUserService.sendReport(formData);

                    case 9:
                      _context9.next = 11;
                      return this.loadingService.stopLoading();

                    case 11:
                      _context9.next = 13;
                      return this.presentAlert();

                    case 13:
                      _context9.next = 15;
                      return this.close();

                    case 15:
                    case "end":
                      return _context9.stop();
                  }
                }
              }, _callee9, this);
            }));
          }
        }, {
          key: "getThemes",
          value: function getThemes() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
              var themes;
              return regeneratorRuntime.wrap(function _callee10$(_context10) {
                while (1) {
                  switch (_context10.prev = _context10.next) {
                    case 0:
                      _context10.next = 2;
                      return this.apiUserService.getReportReference();

                    case 2:
                      themes = _context10.sent;
                      this.themes$.next(themes);

                    case 4:
                    case "end":
                      return _context10.stop();
                  }
                }
              }, _callee10, this);
            }));
          }
        }, {
          key: "presentAlert",
          value: function presentAlert() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
              var alert;
              return regeneratorRuntime.wrap(function _callee11$(_context11) {
                while (1) {
                  switch (_context11.prev = _context11.next) {
                    case 0:
                      _context11.next = 2;
                      return this.alertController.create({
                        header: 'Спасибо за обращение',
                        message: 'Мы обязательно прочитаем Ваше сообщение и сделаем выводы.',
                        buttons: ['Понятно']
                      });

                    case 2:
                      alert = _context11.sent;
                      _context11.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context11.stop();
                  }
                }
              }, _callee11, this);
            }));
          }
        }]);

        return PopupFeedbackComponent;
      }();

      PopupFeedbackComponent.ctorParameters = function () {
        return [{
          type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_10__["UserInfoService"]
        }, {
          type: _core_services_loading_service__WEBPACK_IMPORTED_MODULE_9__["LoadingService"]
        }, {
          type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_6__["ApiUserService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }];
      };

      PopupFeedbackComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-popup-feedback',
        template: _raw_loader_popup_feedback_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_popup_feedback_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PopupFeedbackComponent);
      /***/
    },

    /***/
    "L+UL":
    /*!******************************************************************!*\
      !*** ./src/app/popups/popup-drop-pass/popup-drop-pass.module.ts ***!
      \******************************************************************/

    /*! exports provided: PopupDropPassModule */

    /***/
    function LUL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PopupDropPassModule", function () {
        return PopupDropPassModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _popup_drop_pass_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./popup-drop-pass.component */
      "5fE0");
      /* harmony import */


      var angular_svg_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! angular-svg-icon */
      "OFbc");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../@shared/shared.module */
      "pk6O");

      var PopupDropPassModule = function PopupDropPassModule() {
        _classCallCheck(this, PopupDropPassModule);
      };

      PopupDropPassModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_popup_drop_pass_component__WEBPACK_IMPORTED_MODULE_3__["PopupDropPassComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], angular_svg_icon__WEBPACK_IMPORTED_MODULE_4__["AngularSvgIconModule"].forRoot(), _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"]]
      })], PopupDropPassModule);
      /***/
    },

    /***/
    "LIGA":
    /*!*********************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/filesystem.js ***!
      \*********************************************************************************************************************/

    /*! exports provided: FilesystemPluginWeb, Filesystem */

    /***/
    function LIGA(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FilesystemPluginWeb", function () {
        return FilesystemPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Filesystem", function () {
        return Filesystem;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");
      /* harmony import */


      var _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../core-plugin-definitions */
      "Ni5F");

      var FilesystemPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(FilesystemPluginWeb, _super);

        function FilesystemPluginWeb() {
          var _this = _super.call(this, {
            name: 'Filesystem',
            platforms: ['web']
          }) || this;

          _this.DEFAULT_DIRECTORY = _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["FilesystemDirectory"].Data;
          _this.DB_VERSION = 1;
          _this.DB_NAME = 'Disc';
          _this._writeCmds = ['add', 'put', 'delete'];
          return _this;
        }

        FilesystemPluginWeb.prototype.initDb = function () {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var _this = this;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              if (this._db !== undefined) {
                return [2
                /*return*/
                , this._db];
              }

              if (!('indexedDB' in window)) {
                throw new Error('This browser doesn\'t support IndexedDB');
              }

              return [2
              /*return*/
              , new Promise(function (resolve, reject) {
                var request = indexedDB.open(_this.DB_NAME, _this.DB_VERSION);
                request.onupgradeneeded = FilesystemPluginWeb.doUpgrade;

                request.onsuccess = function () {
                  _this._db = request.result;
                  resolve(request.result);
                };

                request.onerror = function () {
                  return reject(request.error);
                };

                request.onblocked = function () {
                  console.warn('db blocked');
                };
              })];
            });
          });
        };

        FilesystemPluginWeb.doUpgrade = function (event) {
          var eventTarget = event.target;
          var db = eventTarget.result;

          switch (event.oldVersion) {
            case 0:
            case 1:
            default:
              if (db.objectStoreNames.contains('FileStorage')) {
                db.deleteObjectStore('FileStorage');
              }

              var store = db.createObjectStore('FileStorage', {
                keyPath: 'path'
              });
              store.createIndex('by_folder', 'folder');
          }
        };

        FilesystemPluginWeb.prototype.dbRequest = function (cmd, args) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var readFlag;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              readFlag = this._writeCmds.indexOf(cmd) !== -1 ? 'readwrite' : 'readonly';
              return [2
              /*return*/
              , this.initDb().then(function (conn) {
                return new Promise(function (resolve, reject) {
                  var tx = conn.transaction(['FileStorage'], readFlag);
                  var store = tx.objectStore('FileStorage');
                  var req = store[cmd].apply(store, args);

                  req.onsuccess = function () {
                    return resolve(req.result);
                  };

                  req.onerror = function () {
                    return reject(req.error);
                  };
                });
              })];
            });
          });
        };

        FilesystemPluginWeb.prototype.dbIndexRequest = function (indexName, cmd, args) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var readFlag;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              readFlag = this._writeCmds.indexOf(cmd) !== -1 ? 'readwrite' : 'readonly';
              return [2
              /*return*/
              , this.initDb().then(function (conn) {
                return new Promise(function (resolve, reject) {
                  var tx = conn.transaction(['FileStorage'], readFlag);
                  var store = tx.objectStore('FileStorage');
                  var index = store.index(indexName);
                  var req = index[cmd].apply(index, args);

                  req.onsuccess = function () {
                    return resolve(req.result);
                  };

                  req.onerror = function () {
                    return reject(req.error);
                  };
                });
              })];
            });
          });
        };

        FilesystemPluginWeb.prototype.getPath = function (directory, uriPath) {
          directory = directory || this.DEFAULT_DIRECTORY;
          var cleanedUriPath = uriPath !== undefined ? uriPath.replace(/^[/]+|[/]+$/g, '') : '';
          var fsPath = '/' + directory;
          if (uriPath !== '') fsPath += '/' + cleanedUriPath;
          return fsPath;
        };

        FilesystemPluginWeb.prototype.clear = function () {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var conn, tx, store;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  return [4
                  /*yield*/
                  , this.initDb()];

                case 1:
                  conn = _a.sent();
                  tx = conn.transaction(['FileStorage'], 'readwrite');
                  store = tx.objectStore('FileStorage');
                  store.clear();
                  return [2
                  /*return*/
                  , {}];
              }
            });
          });
        };
        /**
         * Read a file from disk
         * @param options options for the file read
         * @return a promise that resolves with the read file data result
         */


        FilesystemPluginWeb.prototype.readFile = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, entry;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  path = this.getPath(options.directory, options.path);
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path])];

                case 1:
                  entry = _a.sent();
                  if (entry === undefined) throw Error('File does not exist.');
                  return [2
                  /*return*/
                  , {
                    data: entry.content
                  }];
              }
            });
          });
        };
        /**
         * Write a file to disk in the specified location on device
         * @param options options for the file write
         * @return a promise that resolves with the file write result
         */


        FilesystemPluginWeb.prototype.writeFile = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, data, doRecursive, occupiedEntry, encoding, parentPath, parentEntry, subDirIndex, parentArgPath, now, pathObj;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  path = this.getPath(options.directory, options.path);
                  data = options.data;
                  doRecursive = options.recursive;
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path])];

                case 1:
                  occupiedEntry = _a.sent();
                  if (occupiedEntry && occupiedEntry.type === 'directory') throw 'The supplied path is a directory.';
                  encoding = options.encoding;
                  parentPath = path.substr(0, path.lastIndexOf('/'));
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [parentPath])];

                case 2:
                  parentEntry = _a.sent();
                  if (!(parentEntry === undefined)) return [3
                  /*break*/
                  , 4];
                  subDirIndex = parentPath.indexOf('/', 1);
                  if (!(subDirIndex !== -1)) return [3
                  /*break*/
                  , 4];
                  parentArgPath = parentPath.substr(subDirIndex);
                  return [4
                  /*yield*/
                  , this.mkdir({
                    path: parentArgPath,
                    directory: options.directory,
                    recursive: doRecursive
                  })];

                case 3:
                  _a.sent();

                  _a.label = 4;

                case 4:
                  now = Date.now();
                  pathObj = {
                    path: path,
                    folder: parentPath,
                    type: 'file',
                    size: data.length,
                    ctime: now,
                    mtime: now,
                    content: !encoding && data.indexOf(',') >= 0 ? data.split(',')[1] : data
                  };
                  return [4
                  /*yield*/
                  , this.dbRequest('put', [pathObj])];

                case 5:
                  _a.sent();

                  return [2
                  /*return*/
                  , {
                    uri: pathObj.path
                  }];
              }
            });
          });
        };
        /**
         * Append to a file on disk in the specified location on device
         * @param options options for the file append
         * @return a promise that resolves with the file write result
         */


        FilesystemPluginWeb.prototype.appendFile = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, data, parentPath, now, ctime, occupiedEntry, parentEntry, subDirIndex, parentArgPath, pathObj;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  path = this.getPath(options.directory, options.path);
                  data = options.data;
                  parentPath = path.substr(0, path.lastIndexOf('/'));
                  now = Date.now();
                  ctime = now;
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path])];

                case 1:
                  occupiedEntry = _a.sent();
                  if (occupiedEntry && occupiedEntry.type === 'directory') throw 'The supplied path is a directory.';
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [parentPath])];

                case 2:
                  parentEntry = _a.sent();
                  if (!(parentEntry === undefined)) return [3
                  /*break*/
                  , 4];
                  subDirIndex = parentPath.indexOf('/', 1);
                  if (!(subDirIndex !== -1)) return [3
                  /*break*/
                  , 4];
                  parentArgPath = parentPath.substr(subDirIndex);
                  return [4
                  /*yield*/
                  , this.mkdir({
                    path: parentArgPath,
                    directory: options.directory,
                    recursive: true
                  })];

                case 3:
                  _a.sent();

                  _a.label = 4;

                case 4:
                  if (occupiedEntry !== undefined) {
                    data = occupiedEntry.content + data;
                    ctime = occupiedEntry.ctime;
                  }

                  pathObj = {
                    path: path,
                    folder: parentPath,
                    type: 'file',
                    size: data.length,
                    ctime: ctime,
                    mtime: now,
                    content: data
                  };
                  return [4
                  /*yield*/
                  , this.dbRequest('put', [pathObj])];

                case 5:
                  _a.sent();

                  return [2
                  /*return*/
                  , {}];
              }
            });
          });
        };
        /**
         * Delete a file from disk
         * @param options options for the file delete
         * @return a promise that resolves with the deleted file data result
         */


        FilesystemPluginWeb.prototype.deleteFile = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, entry, entries;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  path = this.getPath(options.directory, options.path);
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path])];

                case 1:
                  entry = _a.sent();
                  if (entry === undefined) throw Error('File does not exist.');
                  return [4
                  /*yield*/
                  , this.dbIndexRequest('by_folder', 'getAllKeys', [IDBKeyRange.only(path)])];

                case 2:
                  entries = _a.sent();
                  if (entries.length !== 0) throw Error('Folder is not empty.');
                  return [4
                  /*yield*/
                  , this.dbRequest('delete', [path])];

                case 3:
                  _a.sent();

                  return [2
                  /*return*/
                  , {}];
              }
            });
          });
        };
        /**
         * Create a directory.
         * @param options options for the mkdir
         * @return a promise that resolves with the mkdir result
         */


        FilesystemPluginWeb.prototype.mkdir = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, doRecursive, parentPath, depth, parentEntry, occupiedEntry, parentArgPath, now, pathObj;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  path = this.getPath(options.directory, options.path);
                  doRecursive = options.recursive;
                  parentPath = path.substr(0, path.lastIndexOf('/'));
                  depth = (path.match(/\//g) || []).length;
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [parentPath])];

                case 1:
                  parentEntry = _a.sent();
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path])];

                case 2:
                  occupiedEntry = _a.sent();
                  if (depth === 1) throw Error('Cannot create Root directory');
                  if (occupiedEntry !== undefined) throw Error('Current directory does already exist.');
                  if (!doRecursive && depth !== 2 && parentEntry === undefined) throw Error('Parent directory must exist');
                  if (!(doRecursive && depth !== 2 && parentEntry === undefined)) return [3
                  /*break*/
                  , 4];
                  parentArgPath = parentPath.substr(parentPath.indexOf('/', 1));
                  return [4
                  /*yield*/
                  , this.mkdir({
                    path: parentArgPath,
                    directory: options.directory,
                    recursive: doRecursive
                  })];

                case 3:
                  _a.sent();

                  _a.label = 4;

                case 4:
                  now = Date.now();
                  pathObj = {
                    path: path,
                    folder: parentPath,
                    type: 'directory',
                    size: 0,
                    ctime: now,
                    mtime: now
                  };
                  return [4
                  /*yield*/
                  , this.dbRequest('put', [pathObj])];

                case 5:
                  _a.sent();

                  return [2
                  /*return*/
                  , {}];
              }
            });
          });
        };
        /**
         * Remove a directory
         * @param options the options for the directory remove
         */


        FilesystemPluginWeb.prototype.rmdir = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, directory, recursive, fullPath, entry, readDirResult, _i, _a, entry_1, entryPath, entryObj;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_b) {
              switch (_b.label) {
                case 0:
                  path = options.path, directory = options.directory, recursive = options.recursive;
                  fullPath = this.getPath(directory, path);
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [fullPath])];

                case 1:
                  entry = _b.sent();
                  if (entry === undefined) throw Error('Folder does not exist.');
                  if (entry.type !== 'directory') throw Error('Requested path is not a directory');
                  return [4
                  /*yield*/
                  , this.readdir({
                    path: path,
                    directory: directory
                  })];

                case 2:
                  readDirResult = _b.sent();
                  if (readDirResult.files.length !== 0 && !recursive) throw Error('Folder is not empty');
                  _i = 0, _a = readDirResult.files;
                  _b.label = 3;

                case 3:
                  if (!(_i < _a.length)) return [3
                  /*break*/
                  , 9];
                  entry_1 = _a[_i];
                  entryPath = path + "/" + entry_1;
                  return [4
                  /*yield*/
                  , this.stat({
                    path: entryPath,
                    directory: directory
                  })];

                case 4:
                  entryObj = _b.sent();
                  if (!(entryObj.type === 'file')) return [3
                  /*break*/
                  , 6];
                  return [4
                  /*yield*/
                  , this.deleteFile({
                    path: entryPath,
                    directory: directory
                  })];

                case 5:
                  _b.sent();

                  return [3
                  /*break*/
                  , 8];

                case 6:
                  return [4
                  /*yield*/
                  , this.rmdir({
                    path: entryPath,
                    directory: directory,
                    recursive: recursive
                  })];

                case 7:
                  _b.sent();

                  _b.label = 8;

                case 8:
                  _i++;
                  return [3
                  /*break*/
                  , 3];

                case 9:
                  return [4
                  /*yield*/
                  , this.dbRequest('delete', [fullPath])];

                case 10:
                  _b.sent();

                  return [2
                  /*return*/
                  , {}];
              }
            });
          });
        };
        /**
         * Return a list of files from the directory (not recursive)
         * @param options the options for the readdir operation
         * @return a promise that resolves with the readdir directory listing result
         */


        FilesystemPluginWeb.prototype.readdir = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, entry, entries, names;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  path = this.getPath(options.directory, options.path);
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path])];

                case 1:
                  entry = _a.sent();
                  if (options.path !== '' && entry === undefined) throw Error('Folder does not exist.');
                  return [4
                  /*yield*/
                  , this.dbIndexRequest('by_folder', 'getAllKeys', [IDBKeyRange.only(path)])];

                case 2:
                  entries = _a.sent();
                  names = entries.map(function (e) {
                    return e.substring(path.length + 1);
                  });
                  return [2
                  /*return*/
                  , {
                    files: names
                  }];
              }
            });
          });
        };
        /**
         * Return full File URI for a path and directory
         * @param options the options for the stat operation
         * @return a promise that resolves with the file stat result
         */


        FilesystemPluginWeb.prototype.getUri = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, entry;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  path = this.getPath(options.directory, options.path);
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path])];

                case 1:
                  entry = _a.sent();
                  if (!(entry === undefined)) return [3
                  /*break*/
                  , 3];
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path + '/'])];

                case 2:
                  entry = _a.sent();
                  _a.label = 3;

                case 3:
                  if (entry === undefined) throw Error('Entry does not exist.');
                  return [2
                  /*return*/
                  , {
                    uri: entry.path
                  }];
              }
            });
          });
        };
        /**
         * Return data about a file
         * @param options the options for the stat operation
         * @return a promise that resolves with the file stat result
         */


        FilesystemPluginWeb.prototype.stat = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var path, entry;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  path = this.getPath(options.directory, options.path);
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path])];

                case 1:
                  entry = _a.sent();
                  if (!(entry === undefined)) return [3
                  /*break*/
                  , 3];
                  return [4
                  /*yield*/
                  , this.dbRequest('get', [path + '/'])];

                case 2:
                  entry = _a.sent();
                  _a.label = 3;

                case 3:
                  if (entry === undefined) throw Error('Entry does not exist.');
                  return [2
                  /*return*/
                  , {
                    type: entry.type,
                    size: entry.size,
                    ctime: entry.ctime,
                    mtime: entry.mtime,
                    uri: entry.path
                  }];
              }
            });
          });
        };
        /**
         * Rename a file or directory
         * @param options the options for the rename operation
         * @return a promise that resolves with the rename result
         */


        FilesystemPluginWeb.prototype.rename = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              return [2
              /*return*/
              , this._copy(options, true)];
            });
          });
        };
        /**
         * Copy a file or directory
         * @param options the options for the copy operation
         * @return a promise that resolves with the copy result
         */


        FilesystemPluginWeb.prototype.copy = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              return [2
              /*return*/
              , this._copy(options, false)];
            });
          });
        };
        /**
         * Function that can perform a copy or a rename
         * @param options the options for the rename operation
         * @param doRename whether to perform a rename or copy operation
         * @return a promise that resolves with the result
         */


        FilesystemPluginWeb.prototype._copy = function (options, doRename) {
          if (doRename === void 0) {
            doRename = false;
          }

          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var to, from, fromDirectory, toDirectory, fromPath, toPath, toObj, e_1, toPathComponents, toPath_1, toParentDirectory, fromObj, updateTime, _a, file, e_2, contents, _i, contents_1, filename;

            var _this = this;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_b) {
              switch (_b.label) {
                case 0:
                  to = options.to, from = options.from, fromDirectory = options.directory, toDirectory = options.toDirectory;

                  if (!to || !from) {
                    throw Error('Both to and from must be provided');
                  } // If no "to" directory is provided, use the "from" directory


                  if (!toDirectory) {
                    toDirectory = fromDirectory;
                  }

                  fromPath = this.getPath(fromDirectory, from);
                  toPath = this.getPath(toDirectory, to); // Test that the "to" and "from" locations are different

                  if (fromPath === toPath) {
                    return [2
                    /*return*/
                    , {}];
                  }

                  if (toPath.startsWith(fromPath)) {
                    throw Error('To path cannot contain the from path');
                  }

                  _b.label = 1;

                case 1:
                  _b.trys.push([1, 3,, 6]);

                  return [4
                  /*yield*/
                  , this.stat({
                    path: to,
                    directory: toDirectory
                  })];

                case 2:
                  toObj = _b.sent();
                  return [3
                  /*break*/
                  , 6];

                case 3:
                  e_1 = _b.sent();
                  toPathComponents = to.split('/');
                  toPathComponents.pop();
                  toPath_1 = toPathComponents.join('/');
                  if (!(toPathComponents.length > 0)) return [3
                  /*break*/
                  , 5];
                  return [4
                  /*yield*/
                  , this.stat({
                    path: toPath_1,
                    directory: toDirectory
                  })];

                case 4:
                  toParentDirectory = _b.sent();

                  if (toParentDirectory.type !== 'directory') {
                    throw new Error('Parent directory of the to path is a file');
                  }

                  _b.label = 5;

                case 5:
                  return [3
                  /*break*/
                  , 6];

                case 6:
                  // Cannot overwrite a directory
                  if (toObj && toObj.type === 'directory') {
                    throw new Error('Cannot overwrite a directory with a file');
                  }

                  return [4
                  /*yield*/
                  , this.stat({
                    path: from,
                    directory: fromDirectory
                  })];

                case 7:
                  fromObj = _b.sent();

                  updateTime = function updateTime(path, ctime, mtime) {
                    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, function () {
                      var fullPath, entry;
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
                        switch (_a.label) {
                          case 0:
                            fullPath = this.getPath(toDirectory, path);
                            return [4
                            /*yield*/
                            , this.dbRequest('get', [fullPath])];

                          case 1:
                            entry = _a.sent();
                            entry.ctime = ctime;
                            entry.mtime = mtime;
                            return [4
                            /*yield*/
                            , this.dbRequest('put', [entry])];

                          case 2:
                            _a.sent();

                            return [2
                            /*return*/
                            ];
                        }
                      });
                    });
                  };

                  _a = fromObj.type;

                  switch (_a) {
                    case 'file':
                      return [3
                      /*break*/
                      , 8];

                    case 'directory':
                      return [3
                      /*break*/
                      , 15];
                  }

                  return [3
                  /*break*/
                  , 28];

                case 8:
                  return [4
                  /*yield*/
                  , this.readFile({
                    path: from,
                    directory: fromDirectory
                  })];

                case 9:
                  file = _b.sent();
                  if (!doRename) return [3
                  /*break*/
                  , 11];
                  return [4
                  /*yield*/
                  , this.deleteFile({
                    path: from,
                    directory: fromDirectory
                  })];

                case 10:
                  _b.sent();

                  _b.label = 11;

                case 11:
                  // Write the file to the new location
                  return [4
                  /*yield*/
                  , this.writeFile({
                    path: to,
                    directory: toDirectory,
                    data: file.data
                  })];

                case 12:
                  // Write the file to the new location
                  _b.sent();

                  if (!doRename) return [3
                  /*break*/
                  , 14];
                  return [4
                  /*yield*/
                  , updateTime(to, fromObj.ctime, fromObj.mtime)];

                case 13:
                  _b.sent();

                  _b.label = 14;

                case 14:
                  // Resolve promise
                  return [2
                  /*return*/
                  , {}];

                case 15:
                  if (toObj) {
                    throw Error('Cannot move a directory over an existing object');
                  }

                  _b.label = 16;

                case 16:
                  _b.trys.push([16, 20,, 21]); // Create the to directory


                  return [4
                  /*yield*/
                  , this.mkdir({
                    path: to,
                    directory: toDirectory,
                    recursive: false
                  })];

                case 17:
                  // Create the to directory
                  _b.sent();

                  if (!doRename) return [3
                  /*break*/
                  , 19];
                  return [4
                  /*yield*/
                  , updateTime(to, fromObj.ctime, fromObj.mtime)];

                case 18:
                  _b.sent();

                  _b.label = 19;

                case 19:
                  return [3
                  /*break*/
                  , 21];

                case 20:
                  e_2 = _b.sent();
                  return [3
                  /*break*/
                  , 21];

                case 21:
                  return [4
                  /*yield*/
                  , this.readdir({
                    path: from,
                    directory: fromDirectory
                  })];

                case 22:
                  contents = _b.sent().files;
                  _i = 0, contents_1 = contents;
                  _b.label = 23;

                case 23:
                  if (!(_i < contents_1.length)) return [3
                  /*break*/
                  , 26];
                  filename = contents_1[_i]; // Move item from the from directory to the to directory

                  return [4
                  /*yield*/
                  , this._copy({
                    from: from + "/" + filename,
                    to: to + "/" + filename,
                    directory: fromDirectory,
                    toDirectory: toDirectory
                  }, doRename)];

                case 24:
                  // Move item from the from directory to the to directory
                  _b.sent();

                  _b.label = 25;

                case 25:
                  _i++;
                  return [3
                  /*break*/
                  , 23];

                case 26:
                  if (!doRename) return [3
                  /*break*/
                  , 28];
                  return [4
                  /*yield*/
                  , this.rmdir({
                    path: from,
                    directory: fromDirectory
                  })];

                case 27:
                  _b.sent();

                  _b.label = 28;

                case 28:
                  return [2
                  /*return*/
                  , {}];
              }
            });
          });
        };

        FilesystemPluginWeb._debug = true;
        return FilesystemPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Filesystem = new FilesystemPluginWeb(); //# sourceMappingURL=filesystem.js.map

      /***/
    },

    /***/
    "M/Pq":
    /*!**********************************************************************!*\
      !*** ./src/app/@core/services/outsource-auth/google-auth.service.ts ***!
      \**********************************************************************/

    /*! exports provided: GoogleAuthService */

    /***/
    function MPq(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GoogleAuthService", function () {
        return GoogleAuthService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../platform/app-config.service */
      "ophu");
      /* harmony import */


      var _codetrix_studio_capacitor_google_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @codetrix-studio/capacitor-google-auth */
      "OTqH");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @capacitor/core */
      "gcOT");

      var GoogleAuthService = /*#__PURE__*/function () {
        function GoogleAuthService(http, appConfigService) {
          _classCallCheck(this, GoogleAuthService);

          this.http = http;
          this.appConfigService = appConfigService;
          this.oauth2Endpoint = 'https://accounts.google.com/o/oauth2/v2/auth';
          this.oauth2Params = {
            client_id: '967897122719-vndnn724chk8b3v1d8vp0hn7pf479eq7.apps.googleusercontent.com',
            redirect_uri: "".concat(this.appConfigService.locationOrigin, "/main/tabs/user"),
            response_type: 'token',
            scope: 'https://www.googleapis.com/auth/userinfo.profile',
            state: 'pass-through value'
          };
        }

        _createClass(GoogleAuthService, [{
          key: "getMapFromRoute",
          value: function getMapFromRoute(fragment) {
            if (!fragment) {
              return;
            }

            var params = {};
            fragment.split('&').forEach(function (x) {
              var param = x.split('=');
              params[param[0]] = param[1];
            });
            console.log(params);
          }
        }, {
          key: "authRequest",
          value: function authRequest() {
            var _a;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
              var googleUser;
              return regeneratorRuntime.wrap(function _callee12$(_context12) {
                while (1) {
                  switch (_context12.prev = _context12.next) {
                    case 0:
                      _context12.next = 2;
                      return _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].GoogleAuth.signIn();

                    case 2:
                      googleUser = _context12.sent;
                      console.log('user', JSON.stringify(googleUser));
                      return _context12.abrupt("return", {
                        email: googleUser === null || googleUser === void 0 ? void 0 : googleUser.email,
                        googleOAuthToken: (_a = googleUser === null || googleUser === void 0 ? void 0 : googleUser.authentication) === null || _a === void 0 ? void 0 : _a.idToken
                      });

                    case 5:
                    case "end":
                      return _context12.stop();
                  }
                }
              }, _callee12);
            }));
          }
        }, {
          key: "createForm",
          value: function createForm() {
            var form = document.createElement('form');
            form.setAttribute('method', 'POST');
            form.setAttribute('action', this.oauth2Endpoint); // tslint:disable-next-line:forin

            for (var p in this.oauth2Params) {
              var input = document.createElement('input');
              input.setAttribute('type', 'hidden');
              input.setAttribute('name', p);
              input.setAttribute('value', this.oauth2Params[p]);
              form.appendChild(input);
            }

            return form;
          }
        }]);

        return GoogleAuthService;
      }();

      GoogleAuthService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
        }, {
          type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"]
        }];
      };

      GoogleAuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], GoogleAuthService);
      /***/
    },

    /***/
    "M3vd":
    /*!**********************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/permissions.js ***!
      \**********************************************************************************************************************/

    /*! exports provided: PermissionsPluginWeb, Permissions */

    /***/
    function M3vd(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PermissionsPluginWeb", function () {
        return PermissionsPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Permissions", function () {
        return Permissions;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");
      /* harmony import */


      var _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../core-plugin-definitions */
      "Ni5F");

      var PermissionsPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(PermissionsPluginWeb, _super);

        function PermissionsPluginWeb() {
          return _super.call(this, {
            name: 'Permissions'
          }) || this;
        }

        PermissionsPluginWeb.prototype.query = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var navigator, name, ret;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  navigator = window.navigator;

                  if (!navigator.permissions) {
                    return [2
                    /*return*/
                    , Promise.reject('This browser does not support the Permissions API')];
                  }

                  name = options.name === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["PermissionType"].Photos ? 'camera' : options.name;
                  return [4
                  /*yield*/
                  , navigator.permissions.query({
                    name: name
                  })];

                case 1:
                  ret = _a.sent();
                  return [2
                  /*return*/
                  , {
                    state: ret.state
                  }];
              }
            });
          });
        };

        return PermissionsPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Permissions = new PermissionsPluginWeb(); //# sourceMappingURL=permissions.js.map

      /***/
    },

    /***/
    "NZWm":
    /*!****************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/toast.js ***!
      \****************************************************************************************************************/

    /*! exports provided: ToastPluginWeb, Toast */

    /***/
    function NZWm(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ToastPluginWeb", function () {
        return ToastPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Toast", function () {
        return Toast;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var ToastPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToastPluginWeb, _super);

        function ToastPluginWeb() {
          return _super.call(this, {
            name: 'Toast',
            platforms: ['web']
          }) || this;
        }

        ToastPluginWeb.prototype.show = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var duration, toast;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              duration = 2000;

              if (options.duration) {
                duration = options.duration === 'long' ? 3500 : 2000;
              }

              toast = document.createElement('pwa-toast');
              toast.duration = duration;
              toast.message = options.text;
              document.body.appendChild(toast);
              return [2
              /*return*/
              ];
            });
          });
        };

        return ToastPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Toast = new ToastPluginWeb(); //# sourceMappingURL=toast.js.map

      /***/
    },

    /***/
    "Ni5F":
    /*!******************************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/core-plugin-definitions.js ***!
      \******************************************************************************************************************************/

    /*! exports provided: CameraSource, CameraDirection, CameraResultType, FilesystemDirectory, FilesystemEncoding, HapticsImpactStyle, HapticsNotificationType, KeyboardStyle, KeyboardResize, ActionSheetOptionStyle, PermissionType, PhotosAlbumType, StatusBarStyle, StatusBarAnimation */

    /***/
    function Ni5F(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CameraSource", function () {
        return CameraSource;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CameraDirection", function () {
        return CameraDirection;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CameraResultType", function () {
        return CameraResultType;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FilesystemDirectory", function () {
        return FilesystemDirectory;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FilesystemEncoding", function () {
        return FilesystemEncoding;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HapticsImpactStyle", function () {
        return HapticsImpactStyle;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HapticsNotificationType", function () {
        return HapticsNotificationType;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "KeyboardStyle", function () {
        return KeyboardStyle;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "KeyboardResize", function () {
        return KeyboardResize;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ActionSheetOptionStyle", function () {
        return ActionSheetOptionStyle;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PermissionType", function () {
        return PermissionType;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PhotosAlbumType", function () {
        return PhotosAlbumType;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StatusBarStyle", function () {
        return StatusBarStyle;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StatusBarAnimation", function () {
        return StatusBarAnimation;
      });

      var CameraSource;

      (function (CameraSource) {
        CameraSource["Prompt"] = "PROMPT";
        CameraSource["Camera"] = "CAMERA";
        CameraSource["Photos"] = "PHOTOS";
      })(CameraSource || (CameraSource = {}));

      var CameraDirection;

      (function (CameraDirection) {
        CameraDirection["Rear"] = "REAR";
        CameraDirection["Front"] = "FRONT";
      })(CameraDirection || (CameraDirection = {}));

      var CameraResultType;

      (function (CameraResultType) {
        CameraResultType["Uri"] = "uri";
        CameraResultType["Base64"] = "base64";
        CameraResultType["DataUrl"] = "dataUrl";
      })(CameraResultType || (CameraResultType = {}));

      var FilesystemDirectory;

      (function (FilesystemDirectory) {
        /**
         * The Documents directory
         * On iOS it's the app's documents directory.
         * Use this directory to store user-generated content.
         * On Android it's the Public Documents folder, so it's accessible from other apps.
         * It's not accesible on Android 10 unless the app enables legacy External Storage
         * by adding `android:requestLegacyExternalStorage="true"` in the `application` tag
         * in the `AndroidManifest.xml`
         */
        FilesystemDirectory["Documents"] = "DOCUMENTS";
        /**
         * The Data directory
         * On iOS it will use the Documents directory
         * On Android it's the directory holding application files.
         * Files will be deleted when the application is uninstalled.
         */

        FilesystemDirectory["Data"] = "DATA";
        /**
         * The Cache directory
         * Can be deleted in cases of low memory, so use this directory to write app-specific files
         * that your app can re-create easily.
         */

        FilesystemDirectory["Cache"] = "CACHE";
        /**
         * The external directory
         * On iOS it will use the Documents directory
         * On Android it's the directory on the primary shared/external
         * storage device where the application can place persistent files it owns.
         * These files are internal to the applications, and not typically visible
         * to the user as media.
         * Files will be deleted when the application is uninstalled.
         */

        FilesystemDirectory["External"] = "EXTERNAL";
        /**
         * The external storage directory
         * On iOS it will use the Documents directory
         * On Android it's the primary shared/external storage directory.
         * It's not accesible on Android 10 unless the app enables legacy External Storage
         * by adding `android:requestLegacyExternalStorage="true"` in the `application` tag
         * in the `AndroidManifest.xml`
         */

        FilesystemDirectory["ExternalStorage"] = "EXTERNAL_STORAGE";
      })(FilesystemDirectory || (FilesystemDirectory = {}));

      var FilesystemEncoding;

      (function (FilesystemEncoding) {
        FilesystemEncoding["UTF8"] = "utf8";
        FilesystemEncoding["ASCII"] = "ascii";
        FilesystemEncoding["UTF16"] = "utf16";
      })(FilesystemEncoding || (FilesystemEncoding = {}));

      var HapticsImpactStyle;

      (function (HapticsImpactStyle) {
        HapticsImpactStyle["Heavy"] = "HEAVY";
        HapticsImpactStyle["Medium"] = "MEDIUM";
        HapticsImpactStyle["Light"] = "LIGHT";
      })(HapticsImpactStyle || (HapticsImpactStyle = {}));

      var HapticsNotificationType;

      (function (HapticsNotificationType) {
        HapticsNotificationType["SUCCESS"] = "SUCCESS";
        HapticsNotificationType["WARNING"] = "WARNING";
        HapticsNotificationType["ERROR"] = "ERROR";
      })(HapticsNotificationType || (HapticsNotificationType = {}));

      var KeyboardStyle;

      (function (KeyboardStyle) {
        KeyboardStyle["Dark"] = "DARK";
        KeyboardStyle["Light"] = "LIGHT";
      })(KeyboardStyle || (KeyboardStyle = {}));

      var KeyboardResize;

      (function (KeyboardResize) {
        KeyboardResize["Body"] = "body";
        KeyboardResize["Ionic"] = "ionic";
        KeyboardResize["Native"] = "native";
        KeyboardResize["None"] = "none";
      })(KeyboardResize || (KeyboardResize = {}));

      var ActionSheetOptionStyle;

      (function (ActionSheetOptionStyle) {
        ActionSheetOptionStyle["Default"] = "DEFAULT";
        ActionSheetOptionStyle["Destructive"] = "DESTRUCTIVE";
        ActionSheetOptionStyle["Cancel"] = "CANCEL";
      })(ActionSheetOptionStyle || (ActionSheetOptionStyle = {})); //


      var PermissionType;

      (function (PermissionType) {
        PermissionType["Camera"] = "camera";
        PermissionType["Photos"] = "photos";
        PermissionType["Geolocation"] = "geolocation";
        PermissionType["Notifications"] = "notifications";
        PermissionType["ClipboardRead"] = "clipboard-read";
        PermissionType["ClipboardWrite"] = "clipboard-write";
        PermissionType["Microphone"] = "microphone";
      })(PermissionType || (PermissionType = {}));

      var PhotosAlbumType;

      (function (PhotosAlbumType) {
        /**
         * Album is a "smart" album (such as Favorites or Recently Added)
         */
        PhotosAlbumType["Smart"] = "smart";
        /**
         * Album is a cloud-shared album
         */

        PhotosAlbumType["Shared"] = "shared";
        /**
         * Album is a user-created album
         */

        PhotosAlbumType["User"] = "user";
      })(PhotosAlbumType || (PhotosAlbumType = {}));

      var StatusBarStyle;

      (function (StatusBarStyle) {
        /**
         * Light text for dark backgrounds.
         */
        StatusBarStyle["Dark"] = "DARK";
        /**
         * Dark text for light backgrounds.
         */

        StatusBarStyle["Light"] = "LIGHT";
      })(StatusBarStyle || (StatusBarStyle = {}));

      var StatusBarAnimation;

      (function (StatusBarAnimation) {
        /**
         * No animation during show/hide.
         */
        StatusBarAnimation["None"] = "NONE";
        /**
         * Slide animation during show/hide.
         */

        StatusBarAnimation["Slide"] = "SLIDE";
        /**
         * Fade animation during show/hide.
         */

        StatusBarAnimation["Fade"] = "FADE";
      })(StatusBarAnimation || (StatusBarAnimation = {})); //# sourceMappingURL=core-plugin-definitions.js.map

      /***/

    },

    /***/
    "NkFm":
    /*!*********************************************************************!*\
      !*** ./src/app/popups/popup-feedback/popup-feedback.component.scss ***!
      \*********************************************************************/

    /*! exports provided: default */

    /***/
    function NkFm(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  padding: 3vh 4.27vw;\n  box-sizing: border-box;\n  background: white;\n  overflow: hidden;\n  gap: 2.37vh;\n}\n.container .icon {\n  width: 2.43vh;\n  height: 2.43vh;\n  z-index: 1;\n}\n.container .icon__back {\n  color: #2CB172;\n}\n.container .header {\n  font-size: 2.71vh;\n  font-weight: 700;\n  color: #222222;\n  margin-top: 2.46vh;\n}\n.container .subheader {\n  margin-bottom: 1.97vh;\n  font-size: 1.9vh;\n  font-weight: 400;\n  color: #222222;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BvcHVwLWZlZWRiYWNrLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7QUFDRjtBQUNFO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0FBQ0o7QUFDSTtFQUNFLGNBQUE7QUFDTjtBQUdFO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQURKO0FBSUU7RUFDRSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBRkoiLCJmaWxlIjoicG9wdXAtZmVlZGJhY2suY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIHBhZGRpbmc6IDN2aCA0LjI3dnc7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBnYXA6IDIuMzd2aDtcblxuICAuaWNvbiB7XG4gICAgd2lkdGg6IDIuNDN2aDtcbiAgICBoZWlnaHQ6IDIuNDN2aDtcbiAgICB6LWluZGV4OiAxO1xuXG4gICAgJl9fYmFjayB7XG4gICAgICBjb2xvcjogIzJDQjE3MjtcbiAgICB9XG4gIH1cblxuICAuaGVhZGVyIHtcbiAgICBmb250LXNpemU6IDIuNzF2aDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGNvbG9yOiAjMjIyMjIyO1xuICAgIG1hcmdpbi10b3A6IDIuNDZ2aDtcbiAgfVxuXG4gIC5zdWJoZWFkZXIge1xuICAgIG1hcmdpbi1ib3R0b206IDEuOTd2aDtcbiAgICBmb250LXNpemU6IDEuOXZoO1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgY29sb3I6ICMyMjIyMjI7XG4gIH1cbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "OTqH":
    /*!*******************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/dist/esm/index.js ***!
      \*******************************************************************************/

    /*! exports provided: GoogleAuthWeb, GoogleAuth */

    /***/
    function OTqH(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _web__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./web */
      "npad");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "GoogleAuthWeb", function () {
        return _web__WEBPACK_IMPORTED_MODULE_0__["GoogleAuthWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "GoogleAuth", function () {
        return _web__WEBPACK_IMPORTED_MODULE_0__["GoogleAuth"];
      }); //# sourceMappingURL=index.js.map

      /***/

    },

    /***/
    "OlAk":
    /*!****************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/share.js ***!
      \****************************************************************************************************************/

    /*! exports provided: SharePluginWeb, Share */

    /***/
    function OlAk(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharePluginWeb", function () {
        return SharePluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Share", function () {
        return Share;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var SharePluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SharePluginWeb, _super);

        function SharePluginWeb() {
          return _super.call(this, {
            name: 'Share',
            platforms: ['web']
          }) || this;
        }

        SharePluginWeb.prototype.share = function (options) {
          if (!navigator.share) {
            return Promise.reject('Web Share API not available');
          }

          return navigator.share({
            title: options.title,
            text: options.text,
            url: options.url
          });
        };

        return SharePluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Share = new SharePluginWeb(); //# sourceMappingURL=share.js.map

      /***/
    },

    /***/
    "Otlp":
    /*!*****************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/modals.js ***!
      \*****************************************************************************************************************/

    /*! exports provided: ModalsPluginWeb, Modals */

    /***/
    function Otlp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ModalsPluginWeb", function () {
        return ModalsPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Modals", function () {
        return Modals;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var ModalsPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ModalsPluginWeb, _super);

        function ModalsPluginWeb() {
          return _super.call(this, {
            name: 'Modals',
            platforms: ['web']
          }) || this;
        }

        ModalsPluginWeb.prototype.alert = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              window.alert(options.message);
              return [2
              /*return*/
              , Promise.resolve()];
            });
          });
        };

        ModalsPluginWeb.prototype.prompt = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var val;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              val = window.prompt(options.message, options.inputText || '');
              return [2
              /*return*/
              , Promise.resolve({
                value: val,
                cancelled: val === null
              })];
            });
          });
        };

        ModalsPluginWeb.prototype.confirm = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var val;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              val = window.confirm(options.message);
              return [2
              /*return*/
              , Promise.resolve({
                value: val
              })];
            });
          });
        };

        ModalsPluginWeb.prototype.showActions = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var _this = this;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              return [2
              /*return*/
              , new Promise(function (resolve, _reject) {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, function () {
                  var actionSheet;

                  var _this = this;

                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
                    actionSheet = document.querySelector('pwa-action-sheet');

                    if (!actionSheet) {
                      actionSheet = document.createElement('pwa-action-sheet');
                      document.body.appendChild(actionSheet);
                    }

                    actionSheet.header = options.title;
                    actionSheet.cancelable = false;
                    actionSheet.options = options.options;
                    actionSheet.addEventListener('onSelection', function (e) {
                      return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, function () {
                        var selection;
                        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
                          selection = e.detail;
                          resolve({
                            index: selection
                          });
                          return [2
                          /*return*/
                          ];
                        });
                      });
                    });
                    return [2
                    /*return*/
                    ];
                  });
                });
              })];
            });
          });
        };

        return ModalsPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Modals = new ModalsPluginWeb(); //# sourceMappingURL=modals.js.map

      /***/
    },

    /***/
    "P1Zj":
    /*!****************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-menu/page-tabs-user-menu.component.ts ***!
      \****************************************************************************************************************/

    /*! exports provided: PageTabsUserMenuComponent */

    /***/
    function P1Zj(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsUserMenuComponent", function () {
        return PageTabsUserMenuComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_user_menu_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-user-menu.component.html */
      "qCgS");
      /* harmony import */


      var _page_tabs_user_menu_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-user-menu.component.scss */
      "Ik3O");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var PageTabsUserMenuComponent = /*#__PURE__*/function () {
        function PageTabsUserMenuComponent() {
          _classCallCheck(this, PageTabsUserMenuComponent);

          this.icon = 'star';
        }

        _createClass(PageTabsUserMenuComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return PageTabsUserMenuComponent;
      }();

      PageTabsUserMenuComponent.ctorParameters = function () {
        return [];
      };

      PageTabsUserMenuComponent.propDecorators = {
        icon: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      PageTabsUserMenuComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-user-menu',
        template: _raw_loader_page_tabs_user_menu_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_user_menu_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsUserMenuComponent);
      /***/
    },

    /***/
    "QMQ/":
    /*!******************************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/local-notifications.js ***!
      \******************************************************************************************************************************/

    /*! exports provided: LocalNotificationsPluginWeb, LocalNotifications */

    /***/
    function QMQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LocalNotificationsPluginWeb", function () {
        return LocalNotificationsPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LocalNotifications", function () {
        return LocalNotifications;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var LocalNotificationsPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(LocalNotificationsPluginWeb, _super);

        function LocalNotificationsPluginWeb() {
          var _this = _super.call(this, {
            name: 'LocalNotifications',
            platforms: ['web']
          }) || this;

          _this.pending = [];
          return _this;
        }

        LocalNotificationsPluginWeb.prototype.createChannel = function (channel) {
          throw new Error('Feature not available in the browser. ' + channel.id);
        };

        LocalNotificationsPluginWeb.prototype.deleteChannel = function (channel) {
          throw new Error('Feature not available in the browser. ' + channel.id);
        };

        LocalNotificationsPluginWeb.prototype.listChannels = function () {
          throw new Error('Feature not available in the browser');
        };

        LocalNotificationsPluginWeb.prototype.sendPending = function () {
          var _this = this;

          var toRemove = [];
          var now = +new Date();
          this.pending.forEach(function (localNotification) {
            if (localNotification.schedule && localNotification.schedule.at) {
              if (+localNotification.schedule.at <= now) {
                _this.buildNotification(localNotification);

                toRemove.push(localNotification);
              }
            }
          });
          console.log('Sent pending, removing', toRemove);
          this.pending = this.pending.filter(function (localNotification) {
            return !toRemove.find(function (ln) {
              return ln === localNotification;
            });
          });
        };

        LocalNotificationsPluginWeb.prototype.sendNotification = function (localNotification) {
          var _this = this;

          var l = localNotification;

          if (localNotification.schedule && localNotification.schedule.at) {
            var diff = +localNotification.schedule.at - +new Date();
            this.pending.push(l);
            setTimeout(function () {
              _this.sendPending();
            }, diff);
            return;
          }

          this.buildNotification(localNotification);
        };

        LocalNotificationsPluginWeb.prototype.buildNotification = function (localNotification) {
          var l = localNotification;
          return new Notification(l.title, {
            body: l.body
          });
        };

        LocalNotificationsPluginWeb.prototype.schedule = function (options) {
          var _this = this;

          var notifications = [];
          options.notifications.forEach(function (notification) {
            notifications.push(_this.sendNotification(notification));
          });
          return Promise.resolve({
            notifications: options.notifications.map(function (notification) {
              return {
                id: '' + notification.id
              };
            })
          });
        };

        LocalNotificationsPluginWeb.prototype.getPending = function () {
          return Promise.resolve({
            notifications: this.pending.map(function (localNotification) {
              return {
                id: '' + localNotification.id
              };
            })
          });
        };

        LocalNotificationsPluginWeb.prototype.registerActionTypes = function (_options) {
          throw new Error('Method not implemented.');
        };

        LocalNotificationsPluginWeb.prototype.cancel = function (pending) {
          console.log('Cancel these', pending);
          this.pending = this.pending.filter(function (localNotification) {
            return !pending.notifications.find(function (ln) {
              return ln.id === '' + localNotification.id;
            });
          });
          return Promise.resolve();
        };

        LocalNotificationsPluginWeb.prototype.areEnabled = function () {
          return Promise.resolve({
            value: Notification.permission === 'granted'
          });
        };

        LocalNotificationsPluginWeb.prototype.requestPermission = function () {
          return new Promise(function (resolve) {
            Notification.requestPermission(function (result) {
              var granted = true;

              if (result === 'denied' || result === 'default') {
                granted = false;
              }

              resolve({
                granted: granted
              });
            });
          });
        };

        LocalNotificationsPluginWeb.prototype.requestPermissions = function () {
          return new Promise(function (resolve, reject) {
            Notification.requestPermission(function (result) {
              if (result === 'denied' || result === 'default') {
                reject(result);
                return;
              }

              resolve({
                results: [result]
              });
            });
          });
        };

        return LocalNotificationsPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var LocalNotifications = new LocalNotificationsPluginWeb(); //# sourceMappingURL=local-notifications.js.map

      /***/
    },

    /***/
    "QOz/":
    /*!*************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/popup-drop-pass/popup-drop-pass.component.html ***!
      \*************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function QOz(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"page-wrapper\">\n  <div class=\"header\">\n    <svg-icon (click)=\"back()\" class=\"icon\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n    <span class=\"label flex-free-space\"> Смена пароля </span>\n    <div class=\"icon\"></div>\n  </div>\n  <div class=\"form\">\n    <app-shared-input [formControl]=\"email\" label=\"Email\" type=\"email\"></app-shared-input>\n    <app-shared-form-error\n      *ngIf=\"email?.errors && email?.touched;\"\n    > Введите корректный email </app-shared-form-error>\n    <div class=\"flex-free-space\"></div>\n    <app-shared-button (click)=\"dropPass()\" style=\"width: 100%\"> Сбросить пароль </app-shared-button>\n  </div>\n</div>\n";
      /***/
    },

    /***/
    "XOtm":
    /*!**************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-outsource/page-tabs-user-outsource.component.ts ***!
      \**************************************************************************************************************************/

    /*! exports provided: PageTabsUserOutsourceComponent */

    /***/
    function XOtm(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsUserOutsourceComponent", function () {
        return PageTabsUserOutsourceComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_user_outsource_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-user-outsource.component.html */
      "JprH");
      /* harmony import */


      var _page_tabs_user_outsource_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-user-outsource.component.scss */
      "v9ri");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _core_services_outsource_auth_google_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../../../@core/services/outsource-auth/google-auth.service */
      "M/Pq");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _core_services_outsource_auth_vk_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../../../../@core/services/outsource-auth/vk-auth.service */
      "J2Oh");
      /* harmony import */


      var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../../../../@core/services/api/api-user.service */
      "lA1K");
      /* harmony import */


      var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../../../../@core/services/user-info.service */
      "tTdR");

      var PageTabsUserOutsourceComponent = /*#__PURE__*/function () {
        function PageTabsUserOutsourceComponent(userService, apiUserService, googleAuthService, vkAuthService, route) {
          _classCallCheck(this, PageTabsUserOutsourceComponent);

          this.userService = userService;
          this.apiUserService = apiUserService;
          this.googleAuthService = googleAuthService;
          this.vkAuthService = vkAuthService;
          this.route = route;
        }

        _createClass(PageTabsUserOutsourceComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.snapshotMapping();
          }
        }, {
          key: "googleAuth",
          value: function googleAuth() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
              var googleData, user;
              return regeneratorRuntime.wrap(function _callee13$(_context13) {
                while (1) {
                  switch (_context13.prev = _context13.next) {
                    case 0:
                      _context13.next = 2;
                      return this.googleAuthService.authRequest();

                    case 2:
                      googleData = _context13.sent;

                      if (!(!(googleData === null || googleData === void 0 ? void 0 : googleData.googleOAuthToken) || !(googleData === null || googleData === void 0 ? void 0 : googleData.email))) {
                        _context13.next = 5;
                        break;
                      }

                      return _context13.abrupt("return");

                    case 5:
                      _context13.next = 7;
                      return this.apiUserService.userGoogle(googleData);

                    case 7:
                      user = _context13.sent;
                      this.userService.setUser(user);

                    case 9:
                    case "end":
                      return _context13.stop();
                  }
                }
              }, _callee13, this);
            }));
          }
        }, {
          key: "vkAuth",
          value: function vkAuth() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
              var token, user;
              return regeneratorRuntime.wrap(function _callee14$(_context14) {
                while (1) {
                  switch (_context14.prev = _context14.next) {
                    case 0:
                      _context14.next = 2;
                      return this.vkAuthService.authRequestPlugin();

                    case 2:
                      token = _context14.sent;

                      if (token) {
                        _context14.next = 5;
                        break;
                      }

                      return _context14.abrupt("return");

                    case 5:
                      _context14.next = 7;
                      return this.apiUserService.userVk(token);

                    case 7:
                      user = _context14.sent;
                      this.userService.setUser(user);

                    case 9:
                    case "end":
                      return _context14.stop();
                  }
                }
              }, _callee14, this);
            }));
          }
        }, {
          key: "snapshotMapping",
          value: function snapshotMapping() {
            this.googleAuthService.getMapFromRoute(this.route.snapshot.fragment);
          }
        }]);

        return PageTabsUserOutsourceComponent;
      }();

      PageTabsUserOutsourceComponent.ctorParameters = function () {
        return [{
          type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_8__["UserInfoService"]
        }, {
          type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_7__["ApiUserService"]
        }, {
          type: _core_services_outsource_auth_google_auth_service__WEBPACK_IMPORTED_MODULE_4__["GoogleAuthService"]
        }, {
          type: _core_services_outsource_auth_vk_auth_service__WEBPACK_IMPORTED_MODULE_6__["VkAuthService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"]
        }];
      };

      PageTabsUserOutsourceComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-user-outsource',
        template: _raw_loader_page_tabs_user_outsource_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_user_outsource_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsUserOutsourceComponent);
      /***/
    },

    /***/
    "ZBtC":
    /*!*****************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/popup-change-pass/popup-change-pass.component.html ***!
      \*****************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function ZBtC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"page-wrapper\">\n  <div class=\"header\">\n    <svg-icon (click)=\"back()\" class=\"icon\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n    <span class=\"label flex-free-space\"> Смена  пароля </span>\n    <div class=\"icon\"></div>\n  </div>\n  <div class=\"form\">\n    <app-shared-input [formControl]=\"form.get('oldPass')\" label=\"Старый пароль\" type=\"password\"></app-shared-input>\n    <app-shared-input [formControl]=\"form.get('newPass')\" label=\"Новый пароль\" type=\"password\"></app-shared-input>\n    <app-shared-input [formControl]=\"form.get('repeatPass')\" label=\"Повторите пароль\" type=\"password\"></app-shared-input>\n    <app-shared-form-error\n      *ngIf=\"form?.errors && form?.touched;\"\n    > Пароли не совпадают </app-shared-form-error>\n    <div class=\"flex-free-space\"></div>\n    <app-shared-button (click)=\"changePass()\" style=\"width: 100%\"> Сменить пароль </app-shared-button>\n  </div>\n</div>\n";
      /***/
    },

    /***/
    "bX9d":
    /*!******************************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-regbutton/page-tabs-user-regbutton.component.html ***!
      \******************************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function bX9d(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container\">\n  <div\n    class=\"button button ion-activatable ripple-parent\"\n    (click)=\"buttonClick('login')\"\n    [class.button__active]=\"pageType === 'login'\"\n  >\n    <ion-ripple-effect></ion-ripple-effect>\n    Войти\n  </div>\n\n  <div\n    class=\"button button ion-activatable ripple-parent\"\n    (click)=\"buttonClick('reg')\"\n    [class.button__active]=\"pageType === 'reg'\"\n  >\n    <ion-ripple-effect></ion-ripple-effect>\n    Создать аккаунт\n  </div>\n</div>\n";
      /***/
    },

    /***/
    "dUEc":
    /*!*************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/global.js ***!
      \*************************************************************************************************************/

    /*! exports provided: Capacitor, Plugins */

    /***/
    function dUEc(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Capacitor", function () {
        return Capacitor;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Plugins", function () {
        return Plugins;
      });
      /* harmony import */


      var _web_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./web-runtime */
      "FUmq"); // Create our default Capacitor instance, which will be
      // overridden on native platforms


      var Capacitor = function (globalThis) {
        // Create a new CapacitorWeb instance if one doesn't already exist on globalThis
        // Ensure the global is assigned the same Capacitor instance,
        // then export Capacitor so it can be imported in other modules
        return globalThis.Capacitor = globalThis.Capacitor || new _web_runtime__WEBPACK_IMPORTED_MODULE_0__["CapacitorWeb"]();
      }( // figure out the current globalThis, such as "window", "self" or "global"
      // ensure errors are not thrown in an node SSR environment or web worker
      typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : {});

      var Plugins = Capacitor.Plugins; //# sourceMappingURL=global.js.map

      /***/
    },

    /***/
    "f9tZ":
    /*!*****************************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-auth/page-tabs-user-screen-auth.component.html ***!
      \*****************************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function f9tZ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-shared-select label=\"Пол\" [values]=\"genderReference\" [formControl]=\"userForm.controls.gender\"></app-shared-select>\n<!--TODO: add later-->\n<!--<app-shared-input label=\"Возраст\" type=\"number\"></app-shared-input>-->\n<!--<app-shared-select label=\"Город проживания\"></app-shared-select>-->\n<a class=\"forget-password\" (click)=\"refreshPassword()\"> Сменить пароль </a>\n\n<div class=\"menu-container\">\n  <div class=\"flex-free-space\"></div>\n  <app-page-tabs-user-menu  (click)=\"rate()\" icon=\"star\"> Оценить приложение </app-page-tabs-user-menu>\n  <app-page-tabs-user-menu (click)=\"share()\" icon=\"crowd\"> Поделиться с друзьями </app-page-tabs-user-menu>\n  <app-page-tabs-user-menu (click)=\"openFeedback()\" icon=\"fire\"> Обратная связь </app-page-tabs-user-menu>\n</div>\n";
      /***/
    },

    /***/
    "fhDh":
    /*!**********************************************************************!*\
      !*** ./src/app/popups/popup-change-pass/popup-change-pass.module.ts ***!
      \**********************************************************************/

    /*! exports provided: PopupChangePassModule */

    /***/
    function fhDh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PopupChangePassModule", function () {
        return PopupChangePassModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _popup_change_pass_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./popup-change-pass.component */
      "6iwe");
      /* harmony import */


      var angular_svg_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! angular-svg-icon */
      "OFbc");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../@shared/shared.module */
      "pk6O");

      var PopupChangePassModule = function PopupChangePassModule() {
        _classCallCheck(this, PopupChangePassModule);
      };

      PopupChangePassModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_popup_change_pass_component__WEBPACK_IMPORTED_MODULE_3__["PopupChangePassComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], angular_svg_icon__WEBPACK_IMPORTED_MODULE_4__["AngularSvgIconModule"].forRoot(), _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"]]
      })], PopupChangePassModule);
      /***/
    },

    /***/
    "gEHV":
    /*!****************************************************************!*\
      !*** ./src/app/popups/popup-feedback/popup-feedback.module.ts ***!
      \****************************************************************/

    /*! exports provided: PopupFeedbackModule */

    /***/
    function gEHV(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PopupFeedbackModule", function () {
        return PopupFeedbackModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _popup_feedback_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./popup-feedback.component */
      "KlGS");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../@shared/shared.module */
      "pk6O");

      var PopupFeedbackModule = function PopupFeedbackModule() {
        _classCallCheck(this, PopupFeedbackModule);
      };

      PopupFeedbackModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_popup_feedback_component__WEBPACK_IMPORTED_MODULE_3__["PopupFeedbackComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"]]
      })], PopupFeedbackModule);
      /***/
    },

    /***/
    "gHRE":
    /*!****************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/index.js ***!
      \****************************************************************************************************************/

    /*! exports provided: WebPluginRegistry, WebPlugins, WebPlugin, mergeWebPlugins, mergeWebPlugin */

    /***/
    function gHRE(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "WebPluginRegistry", function () {
        return WebPluginRegistry;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "WebPlugins", function () {
        return WebPlugins;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "WebPlugin", function () {
        return WebPlugin;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "mergeWebPlugins", function () {
        return mergeWebPlugins;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "mergeWebPlugin", function () {
        return mergeWebPlugin;
      });

      var WebPluginRegistry =
      /** @class */
      function () {
        function WebPluginRegistry() {
          this.plugins = {};
          this.loadedPlugins = {};
        }

        WebPluginRegistry.prototype.addPlugin = function (plugin) {
          this.plugins[plugin.config.name] = plugin;
        };

        WebPluginRegistry.prototype.getPlugin = function (name) {
          return this.plugins[name];
        };

        WebPluginRegistry.prototype.loadPlugin = function (name) {
          var plugin = this.getPlugin(name);

          if (!plugin) {
            console.error("Unable to load web plugin " + name + ", no such plugin found.");
            return;
          }

          plugin.load();
        };

        WebPluginRegistry.prototype.getPlugins = function () {
          var p = [];

          for (var name_1 in this.plugins) {
            p.push(this.plugins[name_1]);
          }

          return p;
        };

        return WebPluginRegistry;
      }();

      var WebPlugins = new WebPluginRegistry();

      var WebPlugin =
      /** @class */
      function () {
        function WebPlugin(config, pluginRegistry) {
          this.config = config;
          this.loaded = false;
          this.listeners = {};
          this.windowListeners = {};

          if (!pluginRegistry) {
            WebPlugins.addPlugin(this);
          } else {
            pluginRegistry.addPlugin(this);
          }
        }

        WebPlugin.prototype.addWindowListener = function (handle) {
          window.addEventListener(handle.windowEventName, handle.handler);
          handle.registered = true;
        };

        WebPlugin.prototype.removeWindowListener = function (handle) {
          if (!handle) {
            return;
          }

          window.removeEventListener(handle.windowEventName, handle.handler);
          handle.registered = false;
        };

        WebPlugin.prototype.addListener = function (eventName, listenerFunc) {
          var _this = this;

          var listeners = this.listeners[eventName];

          if (!listeners) {
            this.listeners[eventName] = [];
          }

          this.listeners[eventName].push(listenerFunc); // If we haven't added a window listener for this event and it requires one,
          // go ahead and add it

          var windowListener = this.windowListeners[eventName];

          if (windowListener && !windowListener.registered) {
            this.addWindowListener(windowListener);
          }

          return {
            remove: function remove() {
              _this.removeListener(eventName, listenerFunc);
            }
          };
        };

        WebPlugin.prototype.removeListener = function (eventName, listenerFunc) {
          var listeners = this.listeners[eventName];

          if (!listeners) {
            return;
          }

          var index = listeners.indexOf(listenerFunc);
          this.listeners[eventName].splice(index, 1); // If there are no more listeners for this type of event,
          // remove the window listener

          if (!this.listeners[eventName].length) {
            this.removeWindowListener(this.windowListeners[eventName]);
          }
        };

        WebPlugin.prototype.removeAllListeners = function () {
          this.listeners = {};

          for (var listener in this.windowListeners) {
            this.removeWindowListener(this.windowListeners[listener]);
          }

          this.windowListeners = {};
        };

        WebPlugin.prototype.notifyListeners = function (eventName, data) {
          var listeners = this.listeners[eventName];

          if (listeners) {
            listeners.forEach(function (listener) {
              return listener(data);
            });
          }
        };

        WebPlugin.prototype.hasListeners = function (eventName) {
          return !!this.listeners[eventName].length;
        };

        WebPlugin.prototype.registerWindowListener = function (windowEventName, pluginEventName) {
          var _this = this;

          this.windowListeners[pluginEventName] = {
            registered: false,
            windowEventName: windowEventName,
            pluginEventName: pluginEventName,
            handler: function handler(event) {
              _this.notifyListeners(pluginEventName, event);
            }
          };
        };

        WebPlugin.prototype.requestPermissions = function () {
          if (Capacitor.isNative) {
            return Capacitor.nativePromise(this.config.name, 'requestPermissions', {});
          } else {
            return Promise.resolve({
              results: []
            });
          }
        };

        WebPlugin.prototype.load = function () {
          this.loaded = true;
        };

        return WebPlugin;
      }();

      var shouldMergeWebPlugin = function shouldMergeWebPlugin(plugin) {
        return plugin.config.platforms && plugin.config.platforms.indexOf(Capacitor.platform) >= 0;
      };
      /**
       * For all our known web plugins, merge them into the global plugins
       * registry if they aren't already existing. If they don't exist, that
       * means there's no existing native implementation for it.
       * @param knownPlugins the Capacitor.Plugins global registry.
       */


      var mergeWebPlugins = function mergeWebPlugins(knownPlugins) {
        var plugins = WebPlugins.getPlugins();

        for (var _i = 0, plugins_1 = plugins; _i < plugins_1.length; _i++) {
          var plugin = plugins_1[_i];
          mergeWebPlugin(knownPlugins, plugin);
        }
      };

      var mergeWebPlugin = function mergeWebPlugin(knownPlugins, plugin) {
        // If we already have a plugin registered (meaning it was defined in the native layer),
        // then we should only overwrite it if the corresponding web plugin activates on
        // a certain platform. For example: Geolocation uses the WebPlugin on Android but not iOS
        if (knownPlugins.hasOwnProperty(plugin.config.name) && !shouldMergeWebPlugin(plugin)) {
          return;
        }

        knownPlugins[plugin.config.name] = plugin;
      }; //# sourceMappingURL=index.js.map

      /***/

    },

    /***/
    "gwgM":
    /*!************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/index.js ***!
      \************************************************************************************************************/

    /*! exports provided: CameraSource, CameraDirection, CameraResultType, FilesystemDirectory, FilesystemEncoding, HapticsImpactStyle, HapticsNotificationType, KeyboardStyle, KeyboardResize, ActionSheetOptionStyle, PermissionType, PhotosAlbumType, StatusBarStyle, StatusBarAnimation, Capacitor, Plugins, AccessibilityPluginWeb, Accessibility, AppPluginWeb, App, BrowserPluginWeb, Browser, CameraPluginWeb, Camera, ClipboardPluginWeb, Clipboard, FilesystemPluginWeb, Filesystem, GeolocationPluginWeb, Geolocation, DevicePluginWeb, Device, LocalNotificationsPluginWeb, LocalNotifications, SharePluginWeb, Share, ModalsPluginWeb, Modals, MotionPluginWeb, Motion, NetworkPluginWeb, Network, PermissionsPluginWeb, Permissions, SplashScreenPluginWeb, SplashScreen, StoragePluginWeb, Storage, ToastPluginWeb, Toast, registerWebPlugin, WebPluginRegistry, WebPlugins, WebPlugin, mergeWebPlugins, mergeWebPlugin */

    /***/
    function gwgM(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./core-plugin-definitions */
      "Ni5F");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "CameraSource", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["CameraSource"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "CameraDirection", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["CameraDirection"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "CameraResultType", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["CameraResultType"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "FilesystemDirectory", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["FilesystemDirectory"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "FilesystemEncoding", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["FilesystemEncoding"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "HapticsImpactStyle", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["HapticsImpactStyle"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "HapticsNotificationType", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["HapticsNotificationType"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "KeyboardStyle", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["KeyboardStyle"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "KeyboardResize", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["KeyboardResize"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "ActionSheetOptionStyle", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["ActionSheetOptionStyle"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "PermissionType", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["PermissionType"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "PhotosAlbumType", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["PhotosAlbumType"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "StatusBarStyle", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["StatusBarStyle"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "StatusBarAnimation", function () {
        return _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_0__["StatusBarAnimation"];
      });
      /* harmony import */


      var _global__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./global */
      "dUEc");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Capacitor", function () {
        return _global__WEBPACK_IMPORTED_MODULE_1__["Capacitor"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Plugins", function () {
        return _global__WEBPACK_IMPORTED_MODULE_1__["Plugins"];
      });
      /* harmony import */


      var _web_plugins__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./web-plugins */
      "KGk9");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "AccessibilityPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["AccessibilityPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Accessibility", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Accessibility"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "AppPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["AppPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "App", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["App"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "BrowserPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["BrowserPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Browser", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Browser"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "CameraPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["CameraPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Camera", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Camera"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "ClipboardPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["ClipboardPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Clipboard", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Clipboard"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "FilesystemPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["FilesystemPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Filesystem", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Filesystem"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "GeolocationPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["GeolocationPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Geolocation", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Geolocation"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "DevicePluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["DevicePluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Device", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Device"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "LocalNotificationsPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["LocalNotificationsPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "LocalNotifications", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["LocalNotifications"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "SharePluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["SharePluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Share", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Share"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "ModalsPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["ModalsPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Modals", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Modals"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "MotionPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["MotionPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Motion", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Motion"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "NetworkPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["NetworkPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Network", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Network"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "PermissionsPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["PermissionsPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Permissions", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Permissions"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "SplashScreenPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["SplashScreenPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "SplashScreen", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "StoragePluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["StoragePluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Storage", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Storage"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "ToastPluginWeb", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["ToastPluginWeb"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "Toast", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["Toast"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "registerWebPlugin", function () {
        return _web_plugins__WEBPACK_IMPORTED_MODULE_2__["registerWebPlugin"];
      });
      /* harmony import */


      var _web_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./web/index */
      "gHRE");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "WebPluginRegistry", function () {
        return _web_index__WEBPACK_IMPORTED_MODULE_3__["WebPluginRegistry"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "WebPlugins", function () {
        return _web_index__WEBPACK_IMPORTED_MODULE_3__["WebPlugins"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "WebPlugin", function () {
        return _web_index__WEBPACK_IMPORTED_MODULE_3__["WebPlugin"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "mergeWebPlugins", function () {
        return _web_index__WEBPACK_IMPORTED_MODULE_3__["mergeWebPlugins"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "mergeWebPlugin", function () {
        return _web_index__WEBPACK_IMPORTED_MODULE_3__["mergeWebPlugin"];
      }); //# sourceMappingURL=index.js.map

      /***/

    },

    /***/
    "ipqe":
    /*!********************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/clipboard.js ***!
      \********************************************************************************************************************/

    /*! exports provided: ClipboardPluginWeb, Clipboard */

    /***/
    function ipqe(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ClipboardPluginWeb", function () {
        return ClipboardPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Clipboard", function () {
        return Clipboard;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var ClipboardPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ClipboardPluginWeb, _super);

        function ClipboardPluginWeb() {
          return _super.call(this, {
            name: 'Clipboard',
            platforms: ['web']
          }) || this;
        }

        ClipboardPluginWeb.prototype.write = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var blob, clipboardItemInput, err_1;

            var _a;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_b) {
              switch (_b.label) {
                case 0:
                  if (!navigator.clipboard) {
                    return [2
                    /*return*/
                    , Promise.reject('Clipboard API not available in this browser')];
                  }

                  if (!(options.string !== undefined || options.url)) return [3
                  /*break*/
                  , 2];

                  if (!navigator.clipboard.writeText) {
                    return [2
                    /*return*/
                    , Promise.reject('Writting to clipboard not supported in this browser')];
                  }

                  return [4
                  /*yield*/
                  , navigator.clipboard.writeText(options.string !== undefined ? options.string : options.url)];

                case 1:
                  _b.sent();

                  return [3
                  /*break*/
                  , 10];

                case 2:
                  if (!options.image) return [3
                  /*break*/
                  , 9];

                  if (!navigator.clipboard.write) {
                    return [2
                    /*return*/
                    , Promise.reject('Setting images not supported in this browser')];
                  }

                  _b.label = 3;

                case 3:
                  _b.trys.push([3, 7,, 8]);

                  return [4
                  /*yield*/
                  , fetch(options.image)];

                case 4:
                  return [4
                  /*yield*/
                  , _b.sent().blob()];

                case 5:
                  blob = _b.sent();
                  clipboardItemInput = new ClipboardItem((_a = {}, _a[blob.type] = blob, _a));
                  return [4
                  /*yield*/
                  , navigator.clipboard.write([clipboardItemInput])];

                case 6:
                  _b.sent();

                  return [3
                  /*break*/
                  , 8];

                case 7:
                  err_1 = _b.sent();
                  return [2
                  /*return*/
                  , Promise.reject('Failed to write image')];

                case 8:
                  return [3
                  /*break*/
                  , 10];

                case 9:
                  return [2
                  /*return*/
                  , Promise.reject('Nothing to write')];

                case 10:
                  return [2
                  /*return*/
                  , Promise.resolve()];
              }
            });
          });
        };

        ClipboardPluginWeb.prototype.read = function () {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var clipboardItems, type, clipboardBlob, data, err_2;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  if (!navigator.clipboard) {
                    return [2
                    /*return*/
                    , Promise.reject('Clipboard API not available in this browser')];
                  }

                  if (!!navigator.clipboard.read) return [3
                  /*break*/
                  , 1];

                  if (!navigator.clipboard.readText) {
                    return [2
                    /*return*/
                    , Promise.reject('Reading from clipboard not supported in this browser')];
                  }

                  return [2
                  /*return*/
                  , this.readText()];

                case 1:
                  _a.trys.push([1, 5,, 6]);

                  return [4
                  /*yield*/
                  , navigator.clipboard.read()];

                case 2:
                  clipboardItems = _a.sent();
                  type = clipboardItems[0].types[0];
                  return [4
                  /*yield*/
                  , clipboardItems[0].getType(type)];

                case 3:
                  clipboardBlob = _a.sent();
                  return [4
                  /*yield*/
                  , this._getBlobData(clipboardBlob, type)];

                case 4:
                  data = _a.sent();
                  return [2
                  /*return*/
                  , Promise.resolve({
                    value: data,
                    type: type
                  })];

                case 5:
                  err_2 = _a.sent();
                  return [2
                  /*return*/
                  , this.readText()];

                case 6:
                  return [2
                  /*return*/
                  ];
              }
            });
          });
        };

        ClipboardPluginWeb.prototype.readText = function () {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var text;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              switch (_a.label) {
                case 0:
                  return [4
                  /*yield*/
                  , navigator.clipboard.readText()];

                case 1:
                  text = _a.sent();
                  return [2
                  /*return*/
                  , Promise.resolve({
                    value: text,
                    type: 'text/plain'
                  })];
              }
            });
          });
        };

        ClipboardPluginWeb.prototype._getBlobData = function (clipboardBlob, type) {
          return new Promise(function (resolve, reject) {
            var reader = new FileReader();

            if (type.includes('image')) {
              reader.readAsDataURL(clipboardBlob);
            } else {
              reader.readAsText(clipboardBlob);
            }

            reader.onloadend = function () {
              var r = reader.result;
              resolve(r);
            };

            reader.onerror = function (e) {
              reject(e);
            };
          });
        };

        return ClipboardPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Clipboard = new ClipboardPluginWeb(); //# sourceMappingURL=clipboard.js.map

      /***/
    },

    /***/
    "kRvs":
    /*!***************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-login/page-tabs-user-screen-login.component.ts ***!
      \***************************************************************************************************************************/

    /*! exports provided: PageTabsUserScreenLoginComponent */

    /***/
    function kRvs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsUserScreenLoginComponent", function () {
        return PageTabsUserScreenLoginComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_user_screen_login_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-user-screen-login.component.html */
      "tx9K");
      /* harmony import */


      var _page_tabs_user_screen_login_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-user-screen-login.component.scss */
      "lyVJ");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _popups_popup_feedback_popup_feedback_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../../../popups/popup-feedback/popup-feedback.component */
      "KlGS");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../../../../@core/services/loading.service */
      "IpGr");
      /* harmony import */


      var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../../../../@core/services/api/api-user.service */
      "lA1K");
      /* harmony import */


      var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../../../../@core/services/user-info.service */
      "tTdR");
      /* harmony import */


      var _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../../../../@core/services/platform/mobile-share.service */
      "lAEh");
      /* harmony import */


      var _core_services_platform_rate_app_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ../../../../../@core/services/platform/rate-app.service */
      "JE9H");
      /* harmony import */


      var _popups_popup_drop_pass_popup_drop_pass_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ../../../../../popups/popup-drop-pass/popup-drop-pass.component */
      "5fE0");

      var PageTabsUserScreenLoginComponent = /*#__PURE__*/function () {
        function PageTabsUserScreenLoginComponent(modalController, loadingService, apiUserService, userService, shareService, rateAppService) {
          _classCallCheck(this, PageTabsUserScreenLoginComponent);

          this.modalController = modalController;
          this.loadingService = loadingService;
          this.apiUserService = apiUserService;
          this.userService = userService;
          this.shareService = shareService;
          this.rateAppService = rateAppService;
          this.loginForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].email, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].minLength(3)]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].minLength(3)])
          });
        }

        _createClass(PageTabsUserScreenLoginComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.loginForm.valueChanges.subscribe(function (x) {
              return console.log('form', x);
            });
          }
        }, {
          key: "loginClick",
          value: function loginClick() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
              var res;
              return regeneratorRuntime.wrap(function _callee15$(_context15) {
                while (1) {
                  switch (_context15.prev = _context15.next) {
                    case 0:
                      Object.values(this.loginForm.controls).forEach(function (x) {
                        return x.markAsDirty();
                      });

                      if (this.loginForm.valid) {
                        _context15.next = 4;
                        break;
                      }

                      console.warn('invalid form');
                      return _context15.abrupt("return");

                    case 4:
                      _context15.next = 6;
                      return this.apiUserService.userLogin(this.loginForm.value);

                    case 6:
                      res = _context15.sent;
                      this.loadingService.stopLoading().then();

                      if (res) {
                        _context15.next = 10;
                        break;
                      }

                      return _context15.abrupt("return");

                    case 10:
                      this.userService.setUser(res);

                    case 11:
                    case "end":
                      return _context15.stop();
                  }
                }
              }, _callee15, this);
            }));
          }
        }, {
          key: "rate",
          value: function rate() {
            this.rateAppService.rateUs();
          }
        }, {
          key: "share",
          value: function share() {
            this.shareService.shareApp().then();
          }
        }, {
          key: "refreshPassword",
          value: function refreshPassword() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
              return regeneratorRuntime.wrap(function _callee16$(_context16) {
                while (1) {
                  switch (_context16.prev = _context16.next) {
                    case 0:
                      _context16.next = 2;
                      return this.presentModalChangePass();

                    case 2:
                    case "end":
                      return _context16.stop();
                  }
                }
              }, _callee16, this);
            }));
          }
        }, {
          key: "openFeedback",
          value: function openFeedback() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
              return regeneratorRuntime.wrap(function _callee17$(_context17) {
                while (1) {
                  switch (_context17.prev = _context17.next) {
                    case 0:
                      _context17.next = 2;
                      return this.presentModalFeedback();

                    case 2:
                    case "end":
                      return _context17.stop();
                  }
                }
              }, _callee17, this);
            }));
          }
        }, {
          key: "presentModalFeedback",
          value: function presentModalFeedback() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee18() {
              var modal;
              return regeneratorRuntime.wrap(function _callee18$(_context18) {
                while (1) {
                  switch (_context18.prev = _context18.next) {
                    case 0:
                      _context18.next = 2;
                      return this.modalController.create({
                        component: _popups_popup_feedback_popup_feedback_component__WEBPACK_IMPORTED_MODULE_5__["PopupFeedbackComponent"]
                      });

                    case 2:
                      modal = _context18.sent;
                      _context18.next = 5;
                      return modal.present();

                    case 5:
                      return _context18.abrupt("return", _context18.sent);

                    case 6:
                    case "end":
                      return _context18.stop();
                  }
                }
              }, _callee18, this);
            }));
          }
        }, {
          key: "presentModalChangePass",
          value: function presentModalChangePass() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee19() {
              var modal;
              return regeneratorRuntime.wrap(function _callee19$(_context19) {
                while (1) {
                  switch (_context19.prev = _context19.next) {
                    case 0:
                      _context19.next = 2;
                      return this.modalController.create({
                        component: _popups_popup_drop_pass_popup_drop_pass_component__WEBPACK_IMPORTED_MODULE_12__["PopupDropPassComponent"]
                      });

                    case 2:
                      modal = _context19.sent;
                      _context19.next = 5;
                      return modal.present();

                    case 5:
                      return _context19.abrupt("return", _context19.sent);

                    case 6:
                    case "end":
                      return _context19.stop();
                  }
                }
              }, _callee19, this);
            }));
          }
        }]);

        return PageTabsUserScreenLoginComponent;
      }();

      PageTabsUserScreenLoginComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }, {
          type: _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"]
        }, {
          type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_8__["ApiUserService"]
        }, {
          type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_9__["UserInfoService"]
        }, {
          type: _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_10__["MobileShareService"]
        }, {
          type: _core_services_platform_rate_app_service__WEBPACK_IMPORTED_MODULE_11__["RateAppService"]
        }];
      };

      PageTabsUserScreenLoginComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-user-screen-login',
        template: _raw_loader_page_tabs_user_screen_login_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_user_screen_login_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsUserScreenLoginComponent);
      /***/
    },

    /***/
    "kSrW":
    /*!******************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/network.js ***!
      \******************************************************************************************************************/

    /*! exports provided: NetworkPluginWeb, Network */

    /***/
    function kSrW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NetworkPluginWeb", function () {
        return NetworkPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Network", function () {
        return Network;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var NetworkPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(NetworkPluginWeb, _super);

        function NetworkPluginWeb() {
          var _this = _super.call(this, {
            name: 'Network',
            platforms: ['web']
          }) || this;

          _this.listenerFunction = null;
          return _this;
        }

        NetworkPluginWeb.prototype.getStatus = function () {
          return new Promise(function (resolve, reject) {
            if (!window.navigator) {
              reject('Network info not available');
              return;
            }

            var connected = window.navigator.onLine;
            var connection = window.navigator.connection || window.navigator.mozConnection || window.navigator.webkitConnection;
            var connectionType = connection ? connection.type || connection.effectiveType : 'wifi';
            resolve({
              connected: connected,
              connectionType: connected ? connectionType : 'none'
            });
          });
        };

        NetworkPluginWeb.prototype.addListener = function (eventName, listenerFunc) {
          var thisRef = this;
          var connection = window.navigator.connection || window.navigator.mozConnection || window.navigator.webkitConnection;
          var connectionType = connection ? connection.type || connection.effectiveType : 'wifi';
          var onlineBindFunc = listenerFunc.bind(thisRef, {
            connected: true,
            connectionType: connectionType
          });
          var offlineBindFunc = listenerFunc.bind(thisRef, {
            connected: false,
            connectionType: 'none'
          });

          if (eventName.localeCompare('networkStatusChange') === 0) {
            window.addEventListener('online', onlineBindFunc);
            window.addEventListener('offline', offlineBindFunc);
            return {
              remove: function remove() {
                window.removeEventListener('online', onlineBindFunc);
                window.removeEventListener('offline', offlineBindFunc);
              }
            };
          }
        };

        return NetworkPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Network = new NetworkPluginWeb(); //# sourceMappingURL=network.js.map

      /***/
    },

    /***/
    "lAEh":
    /*!*****************************************************************!*\
      !*** ./src/app/@core/services/platform/mobile-share.service.ts ***!
      \*****************************************************************/

    /*! exports provided: MobileShareService */

    /***/
    function lAEh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MobileShareService", function () {
        return MobileShareService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @capacitor/core */
      "gcOT");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var Share = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].Share;

      var MobileShareService = /*#__PURE__*/function () {
        function MobileShareService(platform) {
          _classCallCheck(this, MobileShareService);

          this.platform = platform;
        }

        _createClass(MobileShareService, [{
          key: "shareApp",
          value: function shareApp() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee20() {
              var androidUrl;
              return regeneratorRuntime.wrap(function _callee20$(_context20) {
                while (1) {
                  switch (_context20.prev = _context20.next) {
                    case 0:
                      androidUrl = 'https://play.google.com/store/apps/details?id=com.luc.app';
                      this.shareData('LUC', "\u041F\u0440\u0438\u0432\u0435\u0442! \u0425\u043E\u0447\u0435\u0448\u044C \u043D\u0430\u0439\u0442\u0438 \u043F\u043E\u0434\u0445\u043E\u0434\u044F\u0449\u0443\u044E \u0442\u0435\u0431\u0435 \u043E\u0434\u0435\u0436\u0434\u0443 \u0438 \u0441\u0442\u0438\u043B\u044C, \u0442\u043E\u0433\u0434\u0430 \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u0439 \u0441\u043A\u043E\u0440\u0435\u0435 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 LUC: Android - ".concat(androidUrl, ", iOS - \u0443\u0436\u0435 \u0441\u043A\u043E\u0440\u043E"));

                    case 2:
                    case "end":
                      return _context20.stop();
                  }
                }
              }, _callee20, this);
            }));
          }
        }, {
          key: "shareData",
          value: function shareData(title, text) {
            var url = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
            this.share({
              title: title,
              text: text,
              url: url,
              dialogTitle: title
            }).then();
          }
        }, {
          key: "share",
          value: function share(options) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee21() {
              var shareRes;
              return regeneratorRuntime.wrap(function _callee21$(_context21) {
                while (1) {
                  switch (_context21.prev = _context21.next) {
                    case 0:
                      if (!(this.platform.is('android') || this.platform.is('ios'))) {
                        _context21.next = 6;
                        break;
                      }

                      _context21.next = 3;
                      return Share.share(options);

                    case 3:
                      shareRes = _context21.sent;
                      _context21.next = 7;
                      break;

                    case 6:
                      console.warn('your system not supported');

                    case 7:
                    case "end":
                      return _context21.stop();
                  }
                }
              }, _callee21, this);
            }));
          }
        }]);

        return MobileShareService;
      }();

      MobileShareService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]
        }];
      };

      MobileShareService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], MobileShareService);
      /***/
    },

    /***/
    "lyVJ":
    /*!*****************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-login/page-tabs-user-screen-login.component.scss ***!
      \*****************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function lyVJ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ":host {\n  height: 100%;\n  display: inherit;\n  flex-flow: inherit;\n  gap: inherit;\n}\n\n.forget-password {\n  font-size: 1.72vh;\n  margin-bottom: 1.97vh;\n  color: #2CB172;\n}\n\n.menu-container {\n  display: flex;\n  flex-flow: column;\n  flex-grow: 1;\n  padding-bottom: 1.97vh;\n  margin: 0 -4.27vw;\n}\n\n.button {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy11c2VyLXNjcmVlbi1sb2dpbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0FBQ0YiLCJmaWxlIjoicGFnZS10YWJzLXVzZXItc2NyZWVuLWxvZ2luLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGluaGVyaXQ7XG4gIGZsZXgtZmxvdzogaW5oZXJpdDtcbiAgZ2FwOiBpbmhlcml0O1xufVxuXG4uZm9yZ2V0LXBhc3N3b3JkIHtcbiAgZm9udC1zaXplOiAxLjcydmg7XG4gIG1hcmdpbi1ib3R0b206IDEuOTd2aDtcbiAgY29sb3I6ICMyQ0IxNzI7XG59XG5cbi5tZW51LWNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBmbGV4LWdyb3c6IDE7XG4gIHBhZGRpbmctYm90dG9tOiAxLjk3dmg7XG4gIG1hcmdpbjogMCAtNC4yN3Z3O1xufVxuXG4uYnV0dG9uIHtcbiAgd2lkdGg6IDEwMCU7XG59XG4iXX0= */";
      /***/
    },

    /***/
    "npad":
    /*!*****************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/dist/esm/web.js ***!
      \*****************************************************************************/

    /*! exports provided: GoogleAuthWeb, GoogleAuth */

    /***/
    function npad(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GoogleAuthWeb", function () {
        return GoogleAuthWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GoogleAuth", function () {
        return GoogleAuth;
      });
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @capacitor/core */
      "gwgM");
      /* harmony import */


      var _capacitor_config_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../../../../../capacitor.config.json */
      "Como");

      var _capacitor_config_json__WEBPACK_IMPORTED_MODULE_1___namespace = /*#__PURE__*/__webpack_require__.t(
      /*! ../../../../../capacitor.config.json */
      "Como", 1);

      var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
        return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          }

          function rejected(value) {
            try {
              step(generator["throw"](value));
            } catch (e) {
              reject(e);
            }
          }

          function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
              resolve(result.value);
            }).then(fulfilled, rejected);
          }

          step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
      }; // @ts-ignore


      var GoogleAuthWeb = /*#__PURE__*/function (_capacitor_core__WEBP) {
        _inherits(GoogleAuthWeb, _capacitor_core__WEBP);

        var _super3 = _createSuper(GoogleAuthWeb);

        _createClass(GoogleAuthWeb, [{
          key: "webConfigured",
          get: function get() {
            return document.getElementsByName('google-signin-client_id').length > 0;
          }
        }]);

        function GoogleAuthWeb() {
          var _this5;

          _classCallCheck(this, GoogleAuthWeb);

          _this5 = _super3.call(this, {
            name: 'GoogleAuth',
            platforms: ['web']
          });
          if (!_this5.webConfigured) return _possibleConstructorReturn(_this5);
          _this5.gapiLoaded = new Promise(function (resolve) {
            // HACK: Relying on window object, can't get property in gapi.load callback
            window.gapiResolve = resolve;

            _this5.initialize();
          });

          _this5.addUserChangeListener();

          return _this5;
        }

        _createClass(GoogleAuthWeb, [{
          key: "initialize",
          value: function initialize() {
            var head = document.getElementsByTagName('head')[0];
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.defer = true;
            script.async = true;
            script.onload = this.platformJsLoaded;
            script.src = 'https://apis.google.com/js/platform.js';
            head.appendChild(script);
          }
        }, {
          key: "platformJsLoaded",
          value: function platformJsLoaded() {
            gapi.load('auth2', function () {
              var clientConfig = {
                client_id: document.getElementsByName('google-signin-client_id')[0].content
              };

              if (_capacitor_config_json__WEBPACK_IMPORTED_MODULE_1__.plugins.GoogleAuth != null && _capacitor_config_json__WEBPACK_IMPORTED_MODULE_1__.plugins.GoogleAuth.scopes != null) {
                clientConfig.scope = _capacitor_config_json__WEBPACK_IMPORTED_MODULE_1__.plugins.GoogleAuth.scopes.join(' ');
              }

              gapi.auth2.init(clientConfig);
              window.gapiResolve();
            });
          }
        }, {
          key: "signIn",
          value: function signIn() {
            return __awaiter(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee23() {
              var _this6 = this;

              return regeneratorRuntime.wrap(function _callee23$(_context23) {
                while (1) {
                  switch (_context23.prev = _context23.next) {
                    case 0:
                      return _context23.abrupt("return", new Promise(function (resolve, reject) {
                        return __awaiter(_this6, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee22() {
                          var serverAuthCode, needsOfflineAccess, offlineAccessResponse, googleUser, user;
                          return regeneratorRuntime.wrap(function _callee22$(_context22) {
                            while (1) {
                              switch (_context22.prev = _context22.next) {
                                case 0:
                                  _context22.prev = 0;
                                  needsOfflineAccess = false;

                                  try {
                                    needsOfflineAccess = _capacitor_config_json__WEBPACK_IMPORTED_MODULE_1__.plugins.GoogleAuth.serverClientId != null;
                                  } catch (_a) {}

                                  if (!needsOfflineAccess) {
                                    _context22.next = 10;
                                    break;
                                  }

                                  _context22.next = 6;
                                  return gapi.auth2.getAuthInstance().grantOfflineAccess();

                                case 6:
                                  offlineAccessResponse = _context22.sent;
                                  serverAuthCode = offlineAccessResponse.code;
                                  _context22.next = 12;
                                  break;

                                case 10:
                                  _context22.next = 12;
                                  return gapi.auth2.getAuthInstance().signIn();

                                case 12:
                                  googleUser = gapi.auth2.getAuthInstance().currentUser.get();

                                  if (!needsOfflineAccess) {
                                    _context22.next = 16;
                                    break;
                                  }

                                  _context22.next = 16;
                                  return googleUser.reloadAuthResponse();

                                case 16:
                                  user = this.getUserFrom(googleUser);
                                  user.serverAuthCode = serverAuthCode;
                                  resolve(user);
                                  _context22.next = 24;
                                  break;

                                case 21:
                                  _context22.prev = 21;
                                  _context22.t0 = _context22["catch"](0);
                                  reject(_context22.t0);

                                case 24:
                                case "end":
                                  return _context22.stop();
                              }
                            }
                          }, _callee22, this, [[0, 21]]);
                        }));
                      }));

                    case 1:
                    case "end":
                      return _context23.stop();
                  }
                }
              }, _callee23);
            }));
          }
        }, {
          key: "refresh",
          value: function refresh() {
            return __awaiter(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee24() {
              var authResponse;
              return regeneratorRuntime.wrap(function _callee24$(_context24) {
                while (1) {
                  switch (_context24.prev = _context24.next) {
                    case 0:
                      _context24.next = 2;
                      return gapi.auth2.getAuthInstance().currentUser.get().reloadAuthResponse();

                    case 2:
                      authResponse = _context24.sent;
                      return _context24.abrupt("return", {
                        accessToken: authResponse.access_token,
                        idToken: authResponse.id_token
                      });

                    case 4:
                    case "end":
                      return _context24.stop();
                  }
                }
              }, _callee24);
            }));
          }
        }, {
          key: "signOut",
          value: function signOut() {
            return __awaiter(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee25() {
              return regeneratorRuntime.wrap(function _callee25$(_context25) {
                while (1) {
                  switch (_context25.prev = _context25.next) {
                    case 0:
                      return _context25.abrupt("return", gapi.auth2.getAuthInstance().signOut());

                    case 1:
                    case "end":
                      return _context25.stop();
                  }
                }
              }, _callee25);
            }));
          }
        }, {
          key: "addUserChangeListener",
          value: function addUserChangeListener() {
            return __awaiter(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee26() {
              var _this7 = this;

              return regeneratorRuntime.wrap(function _callee26$(_context26) {
                while (1) {
                  switch (_context26.prev = _context26.next) {
                    case 0:
                      _context26.next = 2;
                      return this.gapiLoaded;

                    case 2:
                      gapi.auth2.getAuthInstance().currentUser.listen(function (googleUser) {
                        _this7.notifyListeners("userChange", googleUser.isSignedIn() ? _this7.getUserFrom(googleUser) : null);
                      });

                    case 3:
                    case "end":
                      return _context26.stop();
                  }
                }
              }, _callee26, this);
            }));
          }
        }, {
          key: "getUserFrom",
          value: function getUserFrom(googleUser) {
            var user = {};
            var profile = googleUser.getBasicProfile();
            user.email = profile.getEmail();
            user.familyName = profile.getFamilyName();
            user.givenName = profile.getGivenName();
            user.id = profile.getId();
            user.imageUrl = profile.getImageUrl();
            user.name = profile.getName();
            var authResponse = googleUser.getAuthResponse(true);
            user.authentication = {
              accessToken: authResponse.access_token,
              idToken: authResponse.id_token
            };
            return user;
          }
        }]);

        return GoogleAuthWeb;
      }(_capacitor_core__WEBPACK_IMPORTED_MODULE_0__["WebPlugin"]);

      var GoogleAuth = new GoogleAuthWeb();
      Object(_capacitor_core__WEBPACK_IMPORTED_MODULE_0__["registerWebPlugin"])(GoogleAuth); //# sourceMappingURL=web.js.map

      /***/
    },

    /***/
    "qCgS":
    /*!********************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-menu/page-tabs-user-menu.component.html ***!
      \********************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function qCgS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect class=\"ion-ripple-color\"></ion-ripple-effect>\n  <svg-icon class=\"main-icon\" src=\"assets/icon/svg/{{icon}}.svg\"></svg-icon>\n  <div class=\"title\">\n    <ng-content></ng-content>\n  </div>\n  <div class=\"icon-wrapper\">\n    <svg-icon class=\"icon\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n  </div>\n</div>\n";
      /***/
    },

    /***/
    "rE3Y":
    /*!************************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/accessibility.js ***!
      \************************************************************************************************************************/

    /*! exports provided: AccessibilityPluginWeb, Accessibility */

    /***/
    function rE3Y(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AccessibilityPluginWeb", function () {
        return AccessibilityPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Accessibility", function () {
        return Accessibility;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var AccessibilityPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(AccessibilityPluginWeb, _super);

        function AccessibilityPluginWeb() {
          return _super.call(this, {
            name: 'Accessibility',
            platforms: ['web']
          }) || this;
        }

        AccessibilityPluginWeb.prototype.isScreenReaderEnabled = function () {
          throw new Error('Feature not available in the browser');
        };

        AccessibilityPluginWeb.prototype.speak = function (options) {
          if (!('speechSynthesis' in window)) {
            return Promise.reject('Browser does not support the Speech Synthesis API');
          }

          var utterance = new SpeechSynthesisUtterance(options.value);

          if (options.language) {
            utterance.lang = options.language;
          }

          window.speechSynthesis.speak(utterance);
          return Promise.resolve();
        };

        return AccessibilityPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Accessibility = new AccessibilityPluginWeb(); //# sourceMappingURL=accessibility.js.map

      /***/
    },

    /***/
    "s/pR":
    /*!*************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-auth/page-tabs-user-screen-auth.component.ts ***!
      \*************************************************************************************************************************/

    /*! exports provided: PageTabsUserScreenAuthComponent */

    /***/
    function sPR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsUserScreenAuthComponent", function () {
        return PageTabsUserScreenAuthComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_user_screen_auth_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-user-screen-auth.component.html */
      "f9tZ");
      /* harmony import */


      var _page_tabs_user_screen_auth_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-user-screen-auth.component.scss */
      "8Pie");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _core_abstractions_RxJsUnsubscriber__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../../../@core/abstractions/RxJsUnsubscriber */
      "IB9i");
      /* harmony import */


      var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../../../../@core/services/user-info.service */
      "tTdR");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../../../../@core/services/platform/mobile-share.service */
      "lAEh");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _popups_popup_feedback_popup_feedback_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../../../../popups/popup-feedback/popup-feedback.component */
      "KlGS");
      /* harmony import */


      var _core_services_platform_rate_app_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ../../../../../@core/services/platform/rate-app.service */
      "JE9H");
      /* harmony import */


      var _popups_popup_change_pass_popup_change_pass_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ../../../../../popups/popup-change-pass/popup-change-pass.component */
      "6iwe");

      var PageTabsUserScreenAuthComponent = /*#__PURE__*/function (_core_abstractions_Rx2) {
        _inherits(PageTabsUserScreenAuthComponent, _core_abstractions_Rx2);

        var _super4 = _createSuper(PageTabsUserScreenAuthComponent);

        function PageTabsUserScreenAuthComponent(userService, shareService, modalController, rateAppService) {
          var _this8;

          _classCallCheck(this, PageTabsUserScreenAuthComponent);

          _this8 = _super4.call(this);
          _this8.userService = userService;
          _this8.shareService = shareService;
          _this8.modalController = modalController;
          _this8.rateAppService = rateAppService;
          _this8.userForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormGroup"]({
            gender: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]()
          });
          _this8.currentUser = null;
          _this8.genderReference = Object.keys(userService.genderReference).map(function (x) {
            return {
              value: x,
              title: userService.genderReference[x]
            };
          });
          return _this8;
        }

        _createClass(PageTabsUserScreenAuthComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this9 = this;

            this.userService.authUser$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["takeUntil"])(this.unsubscribe$)).subscribe(function (user) {
              var _a; // TODO: replace to deepEqual


              if (!!_this9.currentUser && ((_a = _this9.currentUser) === null || _a === void 0 ? void 0 : _a.gender) === (user === null || user === void 0 ? void 0 : user.gender)) {
                return;
              }

              _this9.userForm.controls.gender.setValue(user.gender);

              _this9.currentUser = Object.assign({}, user);
            });
            this.userForm.valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["takeUntil"])(this.unsubscribe$)).subscribe(function (form) {
              _this9.currentUser.gender = form.gender;

              _this9.userService.updateUser(Object.assign(Object.assign({}, _this9.userService.authUser$.value), {
                gender: form.gender
              })).then();
            });
          }
        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            _get(_getPrototypeOf(PageTabsUserScreenAuthComponent.prototype), "ngOnDestroy", this).call(this);
          }
        }, {
          key: "rate",
          value: function rate() {
            this.rateAppService.rateUs();
          }
        }, {
          key: "share",
          value: function share() {
            this.shareService.shareApp().then();
          }
        }, {
          key: "openFeedback",
          value: function openFeedback() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee27() {
              return regeneratorRuntime.wrap(function _callee27$(_context27) {
                while (1) {
                  switch (_context27.prev = _context27.next) {
                    case 0:
                      _context27.next = 2;
                      return this.presentModalFeedback();

                    case 2:
                    case "end":
                      return _context27.stop();
                  }
                }
              }, _callee27, this);
            }));
          }
        }, {
          key: "refreshPassword",
          value: function refreshPassword() {
            this.presentModalRefreshPassword().then();
          }
        }, {
          key: "presentModalFeedback",
          value: function presentModalFeedback() {
            var _a, _b;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee28() {
              var modal;
              return regeneratorRuntime.wrap(function _callee28$(_context28) {
                while (1) {
                  switch (_context28.prev = _context28.next) {
                    case 0:
                      _context28.next = 2;
                      return this.modalController.create({
                        component: _popups_popup_feedback_popup_feedback_component__WEBPACK_IMPORTED_MODULE_10__["PopupFeedbackComponent"],
                        componentProps: {
                          email: (_b = (_a = this.userService.authUser$) === null || _a === void 0 ? void 0 : _a.value) === null || _b === void 0 ? void 0 : _b.email
                        }
                      });

                    case 2:
                      modal = _context28.sent;
                      _context28.next = 5;
                      return modal.present();

                    case 5:
                      return _context28.abrupt("return", _context28.sent);

                    case 6:
                    case "end":
                      return _context28.stop();
                  }
                }
              }, _callee28, this);
            }));
          }
        }, {
          key: "presentModalRefreshPassword",
          value: function presentModalRefreshPassword() {
            var _a, _b;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee29() {
              var modal;
              return regeneratorRuntime.wrap(function _callee29$(_context29) {
                while (1) {
                  switch (_context29.prev = _context29.next) {
                    case 0:
                      _context29.next = 2;
                      return this.modalController.create({
                        component: _popups_popup_change_pass_popup_change_pass_component__WEBPACK_IMPORTED_MODULE_12__["PopupChangePassComponent"],
                        componentProps: {
                          email: (_b = (_a = this.userService.authUser$) === null || _a === void 0 ? void 0 : _a.value) === null || _b === void 0 ? void 0 : _b.email
                        }
                      });

                    case 2:
                      modal = _context29.sent;
                      _context29.next = 5;
                      return modal.present();

                    case 5:
                      return _context29.abrupt("return", _context29.sent);

                    case 6:
                    case "end":
                      return _context29.stop();
                  }
                }
              }, _callee29, this);
            }));
          }
        }]);

        return PageTabsUserScreenAuthComponent;
      }(_core_abstractions_RxJsUnsubscriber__WEBPACK_IMPORTED_MODULE_4__["RxJsUnsubscriber"]);

      PageTabsUserScreenAuthComponent.ctorParameters = function () {
        return [{
          type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_5__["UserInfoService"]
        }, {
          type: _core_services_platform_mobile_share_service__WEBPACK_IMPORTED_MODULE_8__["MobileShareService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["ModalController"]
        }, {
          type: _core_services_platform_rate_app_service__WEBPACK_IMPORTED_MODULE_11__["RateAppService"]
        }];
      };

      PageTabsUserScreenAuthComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-user-screen-auth',
        template: _raw_loader_page_tabs_user_screen_auth_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_user_screen_auth_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsUserScreenAuthComponent);
      /***/
    },

    /***/
    "sm/y":
    /*!*************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-reg/page-tabs-user-screen-reg.component.scss ***!
      \*************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function smY(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ":host {\n  height: 100%;\n  display: inherit;\n  flex-flow: inherit;\n  gap: inherit;\n}\n\napp-shared-input:nth-last-of-type(1) {\n  margin-bottom: 2vh;\n}\n\n.agree-container {\n  display: flex;\n  gap: 4.27vw;\n  font-size: 1.72vh;\n}\n\n.agree-container a {\n  color: #2CB172;\n}\n\n.button {\n  width: 100%;\n  margin-bottom: 3vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy11c2VyLXNjcmVlbi1yZWcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBQ0U7RUFDRSxjQUFBO0FBQ0o7O0FBR0E7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7QUFBRiIsImZpbGUiOiJwYWdlLXRhYnMtdXNlci1zY3JlZW4tcmVnLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGluaGVyaXQ7XG4gIGZsZXgtZmxvdzogaW5oZXJpdDtcbiAgZ2FwOiBpbmhlcml0O1xufVxuXG5hcHAtc2hhcmVkLWlucHV0Om50aC1sYXN0LW9mLXR5cGUoMSkge1xuICBtYXJnaW4tYm90dG9tOiAydmg7XG59XG5cbi5hZ3JlZS1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBnYXA6IDQuMjd2dztcbiAgZm9udC1zaXplOiAxLjcydmg7XG5cbiAgYSB7XG4gICAgY29sb3I6ICMyQ0IxNzI7XG4gIH1cbn1cblxuLmJ1dHRvbiB7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tYm90dG9tOiAzdmg7XG59XG4iXX0= */";
      /***/
    },

    /***/
    "t250":
    /*!**************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-regbutton/page-tabs-user-regbutton.component.ts ***!
      \**************************************************************************************************************************/

    /*! exports provided: PageTabsUserRegbuttonComponent */

    /***/
    function t250(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsUserRegbuttonComponent", function () {
        return PageTabsUserRegbuttonComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_user_regbutton_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-user-regbutton.component.html */
      "bX9d");
      /* harmony import */


      var _page_tabs_user_regbutton_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-user-regbutton.component.scss */
      "7xk4");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var PageTabsUserRegbuttonComponent = /*#__PURE__*/function () {
        function PageTabsUserRegbuttonComponent() {
          _classCallCheck(this, PageTabsUserRegbuttonComponent);

          this.changePage = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        }

        _createClass(PageTabsUserRegbuttonComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "buttonClick",
          value: function buttonClick(type) {
            this.changePage.emit(type);
          }
        }]);

        return PageTabsUserRegbuttonComponent;
      }();

      PageTabsUserRegbuttonComponent.ctorParameters = function () {
        return [];
      };

      PageTabsUserRegbuttonComponent.propDecorators = {
        pageType: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        changePage: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      PageTabsUserRegbuttonComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-user-regbutton',
        template: _raw_loader_page_tabs_user_regbutton_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_user_regbutton_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsUserRegbuttonComponent);
      /***/
    },

    /***/
    "tXLs":
    /*!********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-user/page-tabs-user.component.html ***!
      \********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function tXLs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container\">\n  <ng-container [ngSwitch]=\"pageType$ | async\">\n    <ng-container *ngSwitchCase=\"'auth'\">\n      <div class=\"header\"> {{ (userInfo$ | async).name }} </div>\n      <div class=\"subheader\">\n        <span>{{ (userInfo$ | async).email }}</span>\n        <a (click)=\"exitAccount()\"> Выйти </a>\n      </div>\n    </ng-container>\n    <ng-container *ngSwitchDefault>\n      <div class=\"header\"> Профиль </div>\n      <div class=\"subheader\"> Войдите или создайте аккаунт </div>\n      <app-page-tabs-user-regbutton\n        [pageType]=\"pageType$ | async\"\n        (changePage)=\"switchPage($event)\"\n      ></app-page-tabs-user-regbutton>\n    </ng-container>\n  </ng-container>\n\n  <ng-container [ngSwitch]=\"pageType$ | async\">\n    <app-page-tabs-user-screen-login class=\"page-wrapper\" *ngSwitchCase=\"'login'\"></app-page-tabs-user-screen-login>\n    <app-page-tabs-user-screen-reg class=\"page-wrapper\" *ngSwitchCase=\"'reg'\"></app-page-tabs-user-screen-reg>\n    <app-page-tabs-user-screen-auth class=\"page-wrapper\" *ngSwitchCase=\"'auth'\"></app-page-tabs-user-screen-auth>\n  </ng-container>\n\n</div>\n";
      /***/
    },

    /***/
    "tx9K":
    /*!*******************************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-login/page-tabs-user-screen-login.component.html ***!
      \*******************************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function tx9K(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-shared-input [formControl]=\"loginForm.get('email')\" label=\"Электронная почта\" type=\"email\"></app-shared-input>\n<app-shared-input [formControl]=\"loginForm.get('password')\" label=\"Пароль\" type=\"password\"></app-shared-input>\n<app-shared-form-error *ngIf=\"!loginForm.valid && loginForm.dirty\">\n  Не верно заполнен email или пароль\n</app-shared-form-error>\n\n<a class=\"forget-password\" (click)=\"refreshPassword()\"> Забыли пароль? </a>\n\n<app-shared-button (click)=\"loginClick()\" class=\"button\" type=\"main\">\n  Войти\n</app-shared-button>\n<app-page-tabs-user-outsource></app-page-tabs-user-outsource>\n\n<div class=\"menu-container\">\n  <div class=\"flex-free-space\"></div>\n  <app-page-tabs-user-menu (click)=\"rate()\" icon=\"star\"> Оценить приложение </app-page-tabs-user-menu>\n  <app-page-tabs-user-menu (click)=\"share()\" icon=\"crowd\"> Поделиться с друзьями </app-page-tabs-user-menu>\n  <app-page-tabs-user-menu (click)=\"openFeedback()\" icon=\"fire\"> Обратная связь </app-page-tabs-user-menu>\n</div>\n";
      /***/
    },

    /***/
    "uBk0":
    /*!**********************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/geolocation.js ***!
      \**********************************************************************************************************************/

    /*! exports provided: GeolocationPluginWeb, Geolocation */

    /***/
    function uBk0(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GeolocationPluginWeb", function () {
        return GeolocationPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Geolocation", function () {
        return Geolocation;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");
      /* harmony import */


      var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../util */
      "vW6J");

      var GeolocationPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(GeolocationPluginWeb, _super);

        function GeolocationPluginWeb() {
          return _super.call(this, {
            name: 'Geolocation',
            platforms: ['web']
          }) || this;
        }

        GeolocationPluginWeb.prototype.getCurrentPosition = function (options) {
          var _this = this;

          return new Promise(function (resolve, reject) {
            return _this.requestPermissions().then(function (_result) {
              window.navigator.geolocation.getCurrentPosition(function (pos) {
                resolve(pos);
              }, function (err) {
                reject(err);
              }, Object(_util__WEBPACK_IMPORTED_MODULE_2__["extend"])({
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
              }, options));
            });
          });
        };

        GeolocationPluginWeb.prototype.watchPosition = function (options, callback) {
          var id = window.navigator.geolocation.watchPosition(function (pos) {
            callback(pos);
          }, function (err) {
            callback(null, err);
          }, Object(_util__WEBPACK_IMPORTED_MODULE_2__["extend"])({
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          }, options));
          return "" + id;
        };

        GeolocationPluginWeb.prototype.clearWatch = function (options) {
          window.navigator.geolocation.clearWatch(parseInt(options.id, 10));
          return Promise.resolve();
        };

        return GeolocationPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Geolocation = new GeolocationPluginWeb(); //# sourceMappingURL=geolocation.js.map

      /***/
    },

    /***/
    "uQ6z":
    /*!***********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/popup-feedback/popup-feedback.component.html ***!
      \***********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function uQ6z(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container\">\n  <svg-icon (click)=\"close()\" class=\"icon icon__back\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n  <div class=\"header\"> Обратная связь </div>\n  <div class=\"subheader\"> Если у вас возникли пожелания или проблемы с приложением, то напишите нам об этом </div>\n  <app-shared-input [formControl]=\"form.get('email')\" label=\"Ваш email\" type=\"email\"></app-shared-input>\n  <app-shared-select [formControl]=\"form.get('feedbackCategory')\" [values]=\"selectionThemes$ | async\" label=\"Выберите тему\"></app-shared-select>\n  <app-shared-textarea [formControl]=\"form.get('message')\" label=\"Ваше сообщение\"></app-shared-textarea>\n  <app-shared-form-error *ngIf=\"!form.valid && form.dirty\"> Заполните все поля формы </app-shared-form-error>\n  <div class=\"flex-free-space\"></div>\n  <app-shared-button (click)=\"send()\" type=\"main\" style=\"width: 100%\">\n    Отправить сообщение\n  </app-shared-button>\n</div>\n";
      /***/
    },

    /***/
    "v9ri":
    /*!****************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-user/components/page-tabs-user-outsource/page-tabs-user-outsource.component.scss ***!
      \****************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function v9ri(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  width: inherit;\n}\n.container .label {\n  width: 100%;\n  margin-bottom: 1.97vh;\n  font-size: 14px;\n  font-weight: 400;\n  text-align: center;\n  color: #9198A0;\n}\n.container .icon-container {\n  display: flex;\n  width: 100%;\n  gap: 20px;\n  justify-content: center;\n}\n.container .icon {\n  width: 40px;\n  height: 40px;\n  background: #9198A0;\n  border-radius: 50%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy11c2VyLW91dHNvdXJjZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUFDRjtBQUNFO0VBQ0UsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBQ0o7QUFFRTtFQUNFLGFBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHVCQUFBO0FBQUo7QUFHRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQURKIiwiZmlsZSI6InBhZ2UtdGFicy11c2VyLW91dHNvdXJjZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICB3aWR0aDogaW5oZXJpdDtcblxuICAubGFiZWwge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbi1ib3R0b206IDEuOTd2aDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICM5MTk4QTA7XG4gIH1cblxuICAuaWNvbi1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgZ2FwOiAyMHB4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICB9XG5cbiAgLmljb24ge1xuICAgIHdpZHRoOiA0MHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBiYWNrZ3JvdW5kOiAjOTE5OEEwO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgfVxufVxuIl19 */";
      /***/
    },

    /***/
    "vW6J":
    /*!***********************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/util.js ***!
      \***********************************************************************************************************/

    /*! exports provided: extend, uuid4 */

    /***/
    function vW6J(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "extend", function () {
        return extend;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "uuid4", function () {
        return uuid4;
      });

      var extend = function extend(target) {
        var objs = [];

        for (var _i = 1; _i < arguments.length; _i++) {
          objs[_i - 1] = arguments[_i];
        }

        objs.forEach(function (o) {
          if (o && typeof o === 'object') {
            for (var k in o) {
              if (o.hasOwnProperty(k)) {
                target[k] = o[k];
              }
            }
          }
        });
        return target;
      };

      var uuid4 = function uuid4() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
          var r = Math.random() * 16 | 0,
              v = c === 'x' ? r : r & 0x3 | 0x8;
          return v.toString(16);
        });
      }; //# sourceMappingURL=util.js.map

      /***/

    },

    /***/
    "wVb9":
    /*!***************************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-user/pages/page-tabs-user-screen-reg/page-tabs-user-screen-reg.component.html ***!
      \***************************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function wVb9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-shared-input [formControl]=\"regForm.get('name')\" label=\"Имя\" type=\"text\"></app-shared-input>\n<app-shared-form-error *ngIf=\"checkFieldError('name')\">Обязательное поле</app-shared-form-error>\n<app-shared-input [formControl]=\"regForm.get('email')\" label=\"Электронная почта\" type=\"email\"></app-shared-input>\n<app-shared-form-error *ngIf=\"checkFieldError('email')\"> Введите корректный email </app-shared-form-error>\n<app-shared-input [formControl]=\"regForm.get('passwords').get('password')\" label=\"Пароль\" type=\"password\"></app-shared-input>\n<app-shared-input [formControl]=\"regForm.get('passwords').get('repeatPassword')\" label=\"Повторите пароль\" type=\"password\"></app-shared-input>\n<app-shared-form-error *ngIf=\"checkFieldError('passwords')\"> Пароли не совпадают </app-shared-form-error>\n\n<div class=\"agree-container\" (click)=\"agreeClick()\">\n  <app-shared-multiply-checker [isActive]=\"regForm.get('isPersonalDataAgree').valueChanges | async\"></app-shared-multiply-checker>\n  <div class=\"label\"> Я подтверждаю свое согласие на <a> обработку персональных данных </a> приложением </div>\n</div>\n<ng-container *ngIf=\"checkFieldError('isPersonalDataAgree')\"> Подтвердите обработку персональных данных </ng-container>\n\n<div class=\"flex-free-space\"></div>\n\n<app-shared-button (click)=\"regClick()\" class=\"button\" type=\"main\">\n  Создать\n</app-shared-button>\n";
      /***/
    },

    /***/
    "xlCS":
    /*!******************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/storage.js ***!
      \******************************************************************************************************************/

    /*! exports provided: StoragePluginWeb, Storage */

    /***/
    function xlCS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StoragePluginWeb", function () {
        return StoragePluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Storage", function () {
        return Storage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");

      var StoragePluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(StoragePluginWeb, _super);

        function StoragePluginWeb() {
          var _this = _super.call(this, {
            name: 'Storage',
            platforms: ['web']
          }) || this;

          _this.KEY_PREFIX = '_cap_';
          return _this;
        }

        StoragePluginWeb.prototype.get = function (options) {
          var _this = this;

          return new Promise(function (resolve, _reject) {
            resolve({
              value: window.localStorage.getItem(_this.makeKey(options.key))
            });
          });
        };

        StoragePluginWeb.prototype.set = function (options) {
          var _this = this;

          return new Promise(function (resolve, _reject) {
            window.localStorage.setItem(_this.makeKey(options.key), options.value);
            resolve();
          });
        };

        StoragePluginWeb.prototype.remove = function (options) {
          var _this = this;

          return new Promise(function (resolve, _reject) {
            window.localStorage.removeItem(_this.makeKey(options.key));
            resolve();
          });
        };

        StoragePluginWeb.prototype.keys = function () {
          var _this = this;

          return new Promise(function (resolve, _reject) {
            resolve({
              keys: Object.keys(localStorage).filter(function (k) {
                return _this.isKey(k);
              }).map(function (k) {
                return _this.getKey(k);
              })
            });
          });
        };

        StoragePluginWeb.prototype.clear = function () {
          var _this = this;

          return new Promise(function (resolve, _reject) {
            Object.keys(localStorage).filter(function (k) {
              return _this.isKey(k);
            }).forEach(function (k) {
              return window.localStorage.removeItem(k);
            });
            resolve();
          });
        };

        StoragePluginWeb.prototype.makeKey = function (key) {
          return this.KEY_PREFIX + key;
        };

        StoragePluginWeb.prototype.isKey = function (key) {
          return key.indexOf(this.KEY_PREFIX) === 0;
        };

        StoragePluginWeb.prototype.getKey = function (key) {
          return key.substr(this.KEY_PREFIX.length);
        };

        return StoragePluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Storage = new StoragePluginWeb(); //# sourceMappingURL=storage.js.map

      /***/
    },

    /***/
    "yKy8":
    /*!*****************************************************************************************************************!*\
      !*** ./node_modules/@codetrix-studio/capacitor-google-auth/node_modules/@capacitor/core/dist/esm/web/camera.js ***!
      \*****************************************************************************************************************/

    /*! exports provided: CameraPluginWeb, Camera */

    /***/
    function yKy8(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CameraPluginWeb", function () {
        return CameraPluginWeb;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Camera", function () {
        return Camera;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "NfBk");
      /* harmony import */


      var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./index */
      "gHRE");
      /* harmony import */


      var _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../core-plugin-definitions */
      "Ni5F");

      var CameraPluginWeb =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(CameraPluginWeb, _super);

        function CameraPluginWeb() {
          return _super.call(this, {
            name: 'Camera',
            platforms: ['web']
          }) || this;
        }

        CameraPluginWeb.prototype.getPhoto = function (options) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function () {
            var _this = this;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
              return [2
              /*return*/
              , new Promise(function (resolve, reject) {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, function () {
                  var cameraModal_1, e_1;

                  var _this = this;

                  return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_a) {
                    switch (_a.label) {
                      case 0:
                        if (!options.webUseInput) return [3
                        /*break*/
                        , 1];
                        this.fileInputExperience(options, resolve);
                        return [3
                        /*break*/
                        , 7];

                      case 1:
                        if (!customElements.get('pwa-camera-modal')) return [3
                        /*break*/
                        , 6];
                        cameraModal_1 = document.createElement('pwa-camera-modal');
                        document.body.appendChild(cameraModal_1);
                        _a.label = 2;

                      case 2:
                        _a.trys.push([2, 4,, 5]);

                        return [4
                        /*yield*/
                        , cameraModal_1.componentOnReady()];

                      case 3:
                        _a.sent();

                        cameraModal_1.addEventListener('onPhoto', function (e) {
                          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, function () {
                            var photo, _a;

                            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"])(this, function (_b) {
                              switch (_b.label) {
                                case 0:
                                  photo = e.detail;
                                  if (!(photo === null)) return [3
                                  /*break*/
                                  , 1];
                                  reject('User cancelled photos app');
                                  return [3
                                  /*break*/
                                  , 4];

                                case 1:
                                  if (!(photo instanceof Error)) return [3
                                  /*break*/
                                  , 2];
                                  reject(photo.message);
                                  return [3
                                  /*break*/
                                  , 4];

                                case 2:
                                  _a = resolve;
                                  return [4
                                  /*yield*/
                                  , this._getCameraPhoto(photo, options)];

                                case 3:
                                  _a.apply(void 0, [_b.sent()]);

                                  _b.label = 4;

                                case 4:
                                  cameraModal_1.dismiss();
                                  document.body.removeChild(cameraModal_1);
                                  return [2
                                  /*return*/
                                  ];
                              }
                            });
                          });
                        });
                        cameraModal_1.present();
                        return [3
                        /*break*/
                        , 5];

                      case 4:
                        e_1 = _a.sent();
                        this.fileInputExperience(options, resolve);
                        return [3
                        /*break*/
                        , 5];

                      case 5:
                        return [3
                        /*break*/
                        , 7];

                      case 6:
                        console.error("Unable to load PWA Element 'pwa-camera-modal'. See the docs: https://capacitorjs.com/docs/pwa-elements.");
                        this.fileInputExperience(options, resolve);
                        _a.label = 7;

                      case 7:
                        return [2
                        /*return*/
                        ];
                    }
                  });
                });
              })];
            });
          });
        };

        CameraPluginWeb.prototype.fileInputExperience = function (options, resolve) {
          var input = document.querySelector('#_capacitor-camera-input');

          var cleanup = function cleanup() {
            input.parentNode && input.parentNode.removeChild(input);
          };

          if (!input) {
            input = document.createElement('input');
            input.id = '_capacitor-camera-input';
            input.type = 'file';
            document.body.appendChild(input);
          }

          input.accept = 'image/*';
          input.capture = true;

          if (options.source === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraSource"].Photos || options.source === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraSource"].Prompt) {
            input.removeAttribute('capture');
          } else if (options.direction === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraDirection"].Front) {
            input.capture = 'user';
          } else if (options.direction === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraDirection"].Rear) {
            input.capture = 'environment';
          }

          input.addEventListener('change', function (_e) {
            var file = input.files[0];
            var format = 'jpeg';

            if (file.type === 'image/png') {
              format = 'png';
            } else if (file.type === 'image/gif') {
              format = 'gif';
            }

            if (options.resultType === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraResultType"].DataUrl || options.resultType === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraResultType"].Base64) {
              var reader_1 = new FileReader();
              reader_1.addEventListener('load', function () {
                if (options.resultType === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraResultType"].DataUrl) {
                  resolve({
                    dataUrl: reader_1.result,
                    format: format
                  });
                } else if (options.resultType === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraResultType"].Base64) {
                  var b64 = reader_1.result.split(',')[1];
                  resolve({
                    base64String: b64,
                    format: format
                  });
                }

                cleanup();
              });
              reader_1.readAsDataURL(file);
            } else {
              resolve({
                webPath: URL.createObjectURL(file),
                format: format
              });
              cleanup();
            }
          });
          input.click();
        };

        CameraPluginWeb.prototype._getCameraPhoto = function (photo, options) {
          return new Promise(function (resolve, reject) {
            var reader = new FileReader();
            var format = photo.type.split('/')[1];

            if (options.resultType === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraResultType"].Uri) {
              resolve({
                webPath: URL.createObjectURL(photo),
                format: format
              });
            } else {
              reader.readAsDataURL(photo);

              reader.onloadend = function () {
                var r = reader.result;

                if (options.resultType === _core_plugin_definitions__WEBPACK_IMPORTED_MODULE_2__["CameraResultType"].DataUrl) {
                  resolve({
                    dataUrl: r,
                    format: format
                  });
                } else {
                  resolve({
                    base64String: r.split(',')[1],
                    format: format
                  });
                }
              };

              reader.onerror = function (e) {
                reject(e);
              };
            }
          });
        };

        return CameraPluginWeb;
      }(_index__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"]);

      var Camera = new CameraPluginWeb(); //# sourceMappingURL=camera.js.map

      /***/
    }
  }]);
})();
//# sourceMappingURL=page-tabs-user-page-tabs-user-module-es5.js.map