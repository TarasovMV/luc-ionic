(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! /Users/avsv/Documents/GitHub/luc-ionic/src/main.ts */
      "zUnb");
      /***/
    },

    /***/
    "0SLh":
    /*!********************************************************!*\
      !*** ./src/app/@core/services/api/api-file.service.ts ***!
      \********************************************************/

    /*! exports provided: ApiFileService */

    /***/
    function SLh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiFileService", function () {
        return ApiFileService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../platform/app-config.service */
      "ophu");

      var ApiFileService = /*#__PURE__*/function () {
        function ApiFileService(appConfigService) {
          _classCallCheck(this, ApiFileService);

          this.restUrl = appConfigService.fileUrl;
        }

        _createClass(ApiFileService, [{
          key: "getStartRecoPhotoById",
          value: function getStartRecoPhotoById(id) {
            return "".concat(this.restUrl, "/api/Photo/start-screen-reco/").concat(id);
          }
        }, {
          key: "getTinderPhotoById",
          value: function getTinderPhotoById(id) {
            return "".concat(this.restUrl, "/api/Photo/tinder/").concat(id);
          }
        }, {
          key: "getArticlePhoto",
          value: function getArticlePhoto(url) {
            url = url.replace('/', '%2F');
            return "".concat(this.restUrl, "/api/Photo/").concat(url);
          }
        }]);

        return ApiFileService;
      }();

      ApiFileService.ctorParameters = function () {
        return [{
          type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"]
        }];
      };

      ApiFileService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ApiFileService);
      /***/
    },

    /***/
    "3WmZ":
    /*!*********************************************************!*\
      !*** ./src/app/@core/interceptors/error.interceptor.ts ***!
      \*********************************************************/

    /*! exports provided: ErrorInterceptor */

    /***/
    function WmZ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ErrorInterceptor", function () {
        return ErrorInterceptor;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var _services_app_token_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../services/app-token.service */
      "gcGz");

      var ErrorInterceptor = /*#__PURE__*/function () {
        function ErrorInterceptor(tokenService) {
          _classCallCheck(this, ErrorInterceptor);

          this.tokenService = tokenService;
        }

        _createClass(ErrorInterceptor, [{
          key: "intercept",
          value: function intercept(req, next) {
            var _this = this;

            return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(function (e) {
              var _a;

              switch (e.status) {
                case 475:
                  var token = (_a = e === null || e === void 0 ? void 0 : e.error) === null || _a === void 0 ? void 0 : _a.token;

                  if (token) {
                    _this.tokenService.userToken = token;
                    return next.handle(req);
                  }

                  console.error('Error 475 (continue): Token was not received');
                  break;
              }

              return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(e);
            }));
          }
        }]);

        return ErrorInterceptor;
      }();

      ErrorInterceptor.ctorParameters = function () {
        return [{
          type: _services_app_token_service__WEBPACK_IMPORTED_MODULE_4__["AppTokenService"]
        }];
      };

      ErrorInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ErrorInterceptor);
      /***/
    },

    /***/
    "5XVG":
    /*!************************************************!*\
      !*** ./src/app/@shared/pipes/safe-url.pipe.ts ***!
      \************************************************/

    /*! exports provided: SafeUrlPipe */

    /***/
    function XVG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SafeUrlPipe", function () {
        return SafeUrlPipe;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");

      var SafeUrlPipe = /*#__PURE__*/function () {
        function SafeUrlPipe(sanitizer) {
          _classCallCheck(this, SafeUrlPipe);

          this.sanitizer = sanitizer;
        }

        _createClass(SafeUrlPipe, [{
          key: "transform",
          value: function transform(url) {
            return this.sanitizer.bypassSecurityTrustResourceUrl(url);
          }
        }]);

        return SafeUrlPipe;
      }();

      SafeUrlPipe.ctorParameters = function () {
        return [{
          type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"]
        }];
      };

      SafeUrlPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'safeUrl'
      })], SafeUrlPipe);
      /***/
    },

    /***/
    "7RHv":
    /*!*************************************************************************************!*\
      !*** ./src/app/@shared/components/shared-form-error/shared-form-error.component.ts ***!
      \*************************************************************************************/

    /*! exports provided: SharedFormErrorComponent */

    /***/
    function RHv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharedFormErrorComponent", function () {
        return SharedFormErrorComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_shared_form_error_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./shared-form-error.component.html */
      "9zqh");
      /* harmony import */


      var _shared_form_error_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./shared-form-error.component.scss */
      "mLhf");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var SharedFormErrorComponent = /*#__PURE__*/function () {
        function SharedFormErrorComponent() {
          _classCallCheck(this, SharedFormErrorComponent);
        }

        _createClass(SharedFormErrorComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return SharedFormErrorComponent;
      }();

      SharedFormErrorComponent.ctorParameters = function () {
        return [];
      };

      SharedFormErrorComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-form-error',
        template: _raw_loader_shared_form_error_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_form_error_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SharedFormErrorComponent);
      /***/
    },

    /***/
    "8cGW":
    /*!*******************************************************************************!*\
      !*** ./src/app/@shared/components/shared-select/shared-select.component.scss ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function cGW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-item {\n  --min-height: 7.5vh;\n  --padding-start: 0;\n}\n\nion-label {\n  font-size: 1.97vh !important;\n  font-weight: 500 !important;\n  color: #99A0AB !important;\n}\n\nion-select {\n  max-width: unset;\n}\n\nion-select::part(placeholder) {\n  font-size: 1.97vh !important;\n  font-weight: 500 !important;\n  color: #99A0AB !important;\n  opacity: 1 !important;\n}\n\nion-select::part(text) {\n  font-size: 1.97vh !important;\n  font-weight: 500 !important;\n  color: #222222 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1zZWxlY3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSw0QkFBQTtFQUNBLDJCQUFBO0VBQ0EseUJBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBS0U7RUFDRSw0QkFBQTtFQUNBLDJCQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtBQUhKOztBQU1FO0VBQ0UsNEJBQUE7RUFDQSwyQkFBQTtFQUNBLHlCQUFBO0FBSkoiLCJmaWxlIjoic2hhcmVkLXNlbGVjdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcbiAgLS1taW4taGVpZ2h0OiA3LjV2aDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xufVxuXG5pb24tbGFiZWwge1xuICBmb250LXNpemU6IDEuOTd2aCAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogNTAwICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjOTlBMEFCICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1zZWxlY3Qge1xuICBtYXgtd2lkdGg6IHVuc2V0O1xuXG4gICY6OnBhcnQoaWNvbikge1xuXG4gIH1cblxuICAmOjpwYXJ0KHBsYWNlaG9sZGVyKSB7XG4gICAgZm9udC1zaXplOiAxLjk3dmggIWltcG9ydGFudDtcbiAgICBmb250LXdlaWdodDogNTAwICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICM5OUEwQUIgIWltcG9ydGFudDtcbiAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XG4gIH1cblxuICAmOjpwYXJ0KHRleHQpIHtcbiAgICBmb250LXNpemU6IDEuOTd2aCAhaW1wb3J0YW50O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDAgIWltcG9ydGFudDtcbiAgICBjb2xvcjogIzIyMjIyMiAhaW1wb3J0YW50O1xuICB9XG59XG4iXX0= */";
      /***/
    },

    /***/
    "9jvt":
    /*!*******************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-input/shared-input.component.html ***!
      \*******************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function jvt(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-item class=\"input-container\">\n  <ion-label class=\"label\" position=\"floating\"> {{ label }} </ion-label>\n  <ion-input *ngIf=\"!formControl\" autocomplete=\"nope\" (change)=\"valueChange.emit($event.target.value)\" [value]=\"value\" class=\"input\" [type]=\"type\"></ion-input>\n  <ion-input *ngIf=\"!!formControl\" autocomplete=\"nope\" [formControl]=\"formControl\" class=\"input\" [type]=\"type\"></ion-input>\n</ion-item>\n";
      /***/
    },

    /***/
    "9mOG":
    /*!*****************************************************************************************!*\
      !*** ./src/app/@shared/components/shared-image-slider/shared-image-slider.component.ts ***!
      \*****************************************************************************************/

    /*! exports provided: SharedImageSliderComponent */

    /***/
    function mOG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharedImageSliderComponent", function () {
        return SharedImageSliderComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_shared_image_slider_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./shared-image-slider.component.html */
      "HeKZ");
      /* harmony import */


      var _shared_image_slider_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./shared-image-slider.component.scss */
      "LT+l");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "qCKp");

      var SharedImageSliderComponent = /*#__PURE__*/function () {
        function SharedImageSliderComponent() {
          _classCallCheck(this, SharedImageSliderComponent);

          this.imagesUrl = [];
          this.counter$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](1);
        }

        _createClass(SharedImageSliderComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "slideDetectChange",
          value: function slideDetectChange() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var currentIdx;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.ionSlide.getActiveIndex();

                    case 2:
                      currentIdx = _context.sent;
                      this.counter$.next(currentIdx + 1);

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return SharedImageSliderComponent;
      }();

      SharedImageSliderComponent.ctorParameters = function () {
        return [];
      };

      SharedImageSliderComponent.propDecorators = {
        ionSlide: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"],
          args: ['ionSlides']
        }],
        imagesUrl: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      SharedImageSliderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-image-slider',
        template: _raw_loader_shared_image_slider_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_image_slider_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SharedImageSliderComponent);
      /***/
    },

    /***/
    "9zqh":
    /*!*****************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-form-error/shared-form-error.component.html ***!
      \*****************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function zqh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<span> <ng-content></ng-content> </span>\n";
      /***/
    },

    /***/
    "ACNr":
    /*!*******************************************************************************!*\
      !*** ./src/app/@shared/components/shared-button/shared-button.component.scss ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function ACNr(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "button {\n  width: inherit;\n  outline: none;\n  height: 6.28vh;\n  border-radius: 1vh;\n}\n\n.main {\n  background: #2CB172;\n  color: #FFFFFF;\n}\n\n.main-sub {\n  color: #2CB172;\n  background: none;\n}\n\n.alternative {\n  background: #41485D;\n  color: #FFFFFF;\n}\n\n.alternative-sub {\n  color: #6B7683;\n  background: none;\n}\n\n.skeleton {\n  background: #DCE0EB;\n  color: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1idXR0b24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0FBQ0YiLCJmaWxlIjoic2hhcmVkLWJ1dHRvbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImJ1dHRvbiB7XG4gIHdpZHRoOiBpbmhlcml0O1xuICBvdXRsaW5lOiBub25lO1xuICBoZWlnaHQ6IDYuMjh2aDtcbiAgYm9yZGVyLXJhZGl1czogMXZoO1xufVxuXG4ubWFpbiB7XG4gIGJhY2tncm91bmQ6ICMyQ0IxNzI7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuXG4ubWFpbi1zdWIge1xuICBjb2xvcjogIzJDQjE3MjtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuLmFsdGVybmF0aXZlIHtcbiAgYmFja2dyb3VuZDogIzQxNDg1RDtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi5hbHRlcm5hdGl2ZS1zdWIge1xuICBjb2xvcjogIzZCNzY4MztcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuLnNrZWxldG9uIHtcbiAgYmFja2dyb3VuZDogI0RDRTBFQjtcbiAgY29sb3I6IHRyYW5zcGFyZW50O1xufVxuIl19 */";
      /***/
    },

    /***/
    "AytR":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function AytR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "C1aD":
    /*!******************************************************************!*\
      !*** ./src/app/@core/interceptors/authentication.interceptor.ts ***!
      \******************************************************************/

    /*! exports provided: AuthenticationInterceptor */

    /***/
    function C1aD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AuthenticationInterceptor", function () {
        return AuthenticationInterceptor;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _services_app_token_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/app-token.service */
      "gcGz");

      var AuthenticationInterceptor = /*#__PURE__*/function () {
        function AuthenticationInterceptor(tokenService) {
          _classCallCheck(this, AuthenticationInterceptor);

          this.tokenService = tokenService;
        }

        _createClass(AuthenticationInterceptor, [{
          key: "intercept",
          value: function intercept(req, next) {
            req = req.clone({
              headers: req.headers.append('Authorization', "Bearer ".concat(this.tokenService.userToken))
            });
            return next.handle(req);
          }
        }]);

        return AuthenticationInterceptor;
      }();

      AuthenticationInterceptor.ctorParameters = function () {
        return [{
          type: _services_app_token_service__WEBPACK_IMPORTED_MODULE_2__["AppTokenService"]
        }];
      };

      AuthenticationInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AuthenticationInterceptor);
      /***/
    },

    /***/
    "CBGP":
    /*!*************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-textarea/shared-textarea.component.html ***!
      \*************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function CBGP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-item class=\"input-container\">\n  <ion-label class=\"label\" position=\"floating\"> {{ label }} </ion-label>\n  <ion-textarea *ngIf=\"formControl\" [formControl]=\"formControl\" auto-grow></ion-textarea>\n</ion-item>\n";
      /***/
    },

    /***/
    "DwYw":
    /*!*****************************************************************************!*\
      !*** ./src/app/@shared/components/shared-button/shared-button.component.ts ***!
      \*****************************************************************************/

    /*! exports provided: SharedButtonComponent */

    /***/
    function DwYw(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharedButtonComponent", function () {
        return SharedButtonComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_shared_button_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./shared-button.component.html */
      "ikas");
      /* harmony import */


      var _shared_button_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./shared-button.component.scss */
      "ACNr");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var SharedButtonComponent = /*#__PURE__*/function () {
        function SharedButtonComponent() {
          _classCallCheck(this, SharedButtonComponent);

          this.type = 'main';
        }

        _createClass(SharedButtonComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return SharedButtonComponent;
      }();

      SharedButtonComponent.ctorParameters = function () {
        return [];
      };

      SharedButtonComponent.propDecorators = {
        type: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      SharedButtonComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-button',
        template: _raw_loader_shared_button_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_button_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SharedButtonComponent);
      /***/
    },

    /***/
    "FctL":
    /*!*********************************************************************************!*\
      !*** ./src/app/@shared/components/shared-textarea/shared-textarea.component.ts ***!
      \*********************************************************************************/

    /*! exports provided: SharedTextareaComponent */

    /***/
    function FctL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharedTextareaComponent", function () {
        return SharedTextareaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_shared_textarea_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./shared-textarea.component.html */
      "CBGP");
      /* harmony import */


      var _shared_textarea_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./shared-textarea.component.scss */
      "p7KD");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var SharedTextareaComponent = /*#__PURE__*/function () {
        function SharedTextareaComponent() {
          _classCallCheck(this, SharedTextareaComponent);

          this.label = '';
        }

        _createClass(SharedTextareaComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return SharedTextareaComponent;
      }();

      SharedTextareaComponent.ctorParameters = function () {
        return [];
      };

      SharedTextareaComponent.propDecorators = {
        label: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        formControl: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      SharedTextareaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-textarea',
        template: _raw_loader_shared_textarea_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_textarea_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SharedTextareaComponent);
      /***/
    },

    /***/
    "HeKZ":
    /*!*********************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-image-slider/shared-image-slider.component.html ***!
      \*********************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function HeKZ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"wrapper\">\n  <div class=\"counter\"> {{ counter$ | async }} из {{ imagesUrl.length }} </div>\n\n  <ion-slides (ionSlideDidChange)=\"slideDetectChange()\" #ionSlides style=\"height: 100%; width: 100%\">\n    <ion-slide *ngFor=\"let img of imagesUrl\">\n      <img [src]=\"img\"/>\n    </ion-slide>\n  </ion-slides>\n</div>\n";
      /***/
    },

    /***/
    "IHQ7":
    /*!*************************************************************!*\
      !*** ./src/app/@core/services/platform/keyboard.service.ts ***!
      \*************************************************************/

    /*! exports provided: KeyboardService */

    /***/
    function IHQ7(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "KeyboardService", function () {
        return KeyboardService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @capacitor/core */
      "gcOT");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs */
      "qCKp");

      var Keyboard = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].Keyboard;

      var KeyboardService = /*#__PURE__*/function () {
        function KeyboardService() {
          _classCallCheck(this, KeyboardService);

          this.keyboardHeight$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](0);
        } // TODO: add theme


        _createClass(KeyboardService, [{
          key: "setInitSettings",
          value: function setInitSettings(platform, appWindow) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.prev = 0;
                      this.actionListeners(platform, appWindow);
                      _context2.next = 4;
                      return Keyboard.setStyle({
                        style: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["KeyboardStyle"].Light
                      });

                    case 4:
                      _context2.next = 6;
                      return Keyboard.setResizeMode({
                        mode: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["KeyboardResize"].None
                      });

                    case 6:
                      _context2.next = 10;
                      break;

                    case 8:
                      _context2.prev = 8;
                      _context2.t0 = _context2["catch"](0);

                    case 10:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this, [[0, 8]]);
            }));
          }
        }, {
          key: "actionListeners",
          value: function actionListeners(platform, appWindow) {
            var _this2 = this;

            platform.keyboardDidShow.subscribe(function (event) {
              return _this2.keyboardHeight$.next(event.keyboardHeight);
            });
            platform.keyboardDidHide.subscribe(function () {
              return _this2.keyboardHeight$.next(0);
            });
            this.keyboardHeight$.subscribe(function (height) {
              return appWindow.el.style = "height: calc(100vh - ".concat(height, "px)");
            });
          }
        }]);

        return KeyboardService;
      }();

      KeyboardService.ctorParameters = function () {
        return [];
      };

      KeyboardService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], KeyboardService);
      /***/
    },

    /***/
    "JGf/":
    /*!**************************************************!*\
      !*** ./src/app/@core/services/logger.service.ts ***!
      \**************************************************/

    /*! exports provided: LoggerService */

    /***/
    function JGf(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LoggerService", function () {
        return LoggerService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var LoggerService = /*#__PURE__*/function () {
        function LoggerService() {
          _classCallCheck(this, LoggerService);

          this.logMessage = function (message) {
            return message;
          };
        }
        /**
         *
         * @param type
         * @param message
         */


        _createClass(LoggerService, [{
          key: "log",
          value: function log(type, message) {
            var prepareMessage = this.logMessage(message);

            switch (type) {
              case 'error':
                console.error(prepareMessage);
                break;

              case 'warning':
                console.warn(prepareMessage);
                break;

              case 'info':
                console.log(prepareMessage);
                break;
            }
          }
        }]);

        return LoggerService;
      }();

      LoggerService.ctorParameters = function () {
        return [];
      };

      LoggerService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], LoggerService);
      /***/
    },

    /***/
    "KwcL":
    /*!*************************************************************************************************************************************************!*\
      !*** ./node_modules/@ionic/pwa-elements/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
      \*************************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function KwcL(module, exports, __webpack_require__) {
      var map = {
        "./pwa-action-sheet.entry.js": ["jDxf", 43],
        "./pwa-camera-modal-instance.entry.js": ["37vE", 44],
        "./pwa-camera-modal.entry.js": ["cJxf", 45],
        "./pwa-camera.entry.js": ["eGHz", 46],
        "./pwa-toast.entry.js": ["fHjd", 47]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return __webpack_require__.e(ids[1]).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function webpackAsyncContextKeys() {
        return Object.keys(map);
      };

      webpackAsyncContext.id = "KwcL";
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    "LT+l":
    /*!*******************************************************************************************!*\
      !*** ./src/app/@shared/components/shared-image-slider/shared-image-slider.component.scss ***!
      \*******************************************************************************************/

    /*! exports provided: default */

    /***/
    function LTL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".wrapper {\n  position: relative;\n  width: 100%;\n  height: 100%;\n}\n.wrapper .counter {\n  position: absolute;\n  right: 5.3vw;\n  top: 5.3vw;\n  padding: 1vh;\n  z-index: 2;\n  font-size: 1.72vh;\n  color: #FFFFFF;\n  background: rgba(34, 34, 34, 0.65);\n  border-radius: 1vh;\n}\n.wrapper img {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1pbWFnZS1zbGlkZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQ0Y7QUFDRTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtDQUFBO0VBQ0Esa0JBQUE7QUFDSjtBQUVFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBQUoiLCJmaWxlIjoic2hhcmVkLWltYWdlLXNsaWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwcGVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuXG4gIC5jb3VudGVyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgcmlnaHQ6IDUuM3Z3O1xuICAgIHRvcDogNS4zdnc7XG4gICAgcGFkZGluZzogMXZoO1xuICAgIHotaW5kZXg6IDI7XG4gICAgZm9udC1zaXplOiAxLjcydmg7XG4gICAgY29sb3I6ICNGRkZGRkY7XG4gICAgYmFja2dyb3VuZDogcmdiYSgzNCwgMzQsIDM0LCAwLjY1KTtcbiAgICBib3JkZXItcmFkaXVzOiAxdmg7XG4gIH1cblxuICBpbWcge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgfVxufVxuIl19 */";
      /***/
    },

    /***/
    "Sy1n":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function Sy1n(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./app.component.html */
      "VzVu");
      /* harmony import */


      var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app.component.scss */
      "ynWL");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "54vc");
      /* harmony import */


      var _core_services_platform_status_bar_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./@core/services/platform/status-bar.service */
      "qCjG");
      /* harmony import */


      var _core_services_platform_keyboard_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./@core/services/platform/keyboard.service */
      "IHQ7");
      /* harmony import */


      var _core_services_outsource_auth_user_agent_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./@core/services/outsource-auth/user-agent.service */
      "Uqa0");
      /* harmony import */


      var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./@core/services/user-info.service */
      "tTdR");

      var AppComponent = /*#__PURE__*/function () {
        function AppComponent(platform, splashScreen, statusBarService, keyboardService, userAgentService, userInfoService) {
          _classCallCheck(this, AppComponent);

          this.platform = platform;
          this.splashScreen = splashScreen;
          this.statusBarService = statusBarService;
          this.keyboardService = keyboardService;
          this.userAgentService = userAgentService;
          this.userInfoService = userInfoService;
        }

        _createClass(AppComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      this.initializeApp();

                    case 1:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "initializeApp",
          value: function initializeApp() {
            var _this3 = this;

            this.platform.ready().then(function () {
              _this3.splashScreen.hide();

              _this3.statusBarService.setDefault();

              _this3.keyboardService.setInitSettings(_this3.platform, _this3.appWindow); // this.userAgentService.setUserAgent(); // TODO: not work

            });
          }
        }]);

        return AppComponent;
      }();

      AppComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
        }, {
          type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"]
        }, {
          type: _core_services_platform_status_bar_service__WEBPACK_IMPORTED_MODULE_6__["StatusBarService"]
        }, {
          type: _core_services_platform_keyboard_service__WEBPACK_IMPORTED_MODULE_7__["KeyboardService"]
        }, {
          type: _core_services_outsource_auth_user_agent_service__WEBPACK_IMPORTED_MODULE_8__["UserAgentService"]
        }, {
          type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_9__["UserInfoService"]
        }];
      };

      AppComponent.propDecorators = {
        appWindow: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"],
          args: ['appWindow', {
            "static": true
          }]
        }]
      };
      AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], AppComponent);
      /***/
    },

    /***/
    "TtwI":
    /*!*****************************************************************************!*\
      !*** ./src/app/@shared/components/shared-input/shared-input.component.scss ***!
      \*****************************************************************************/

    /*! exports provided: default */

    /***/
    function TtwI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".input-container {\n  --min-height: 7.5vh;\n  --padding-start: 0;\n}\n.input-container .label {\n  margin: 0;\n  font-size: 1.97vh;\n  font-weight: 500;\n  color: #99A0AB;\n}\n.input-container .input {\n  --padding-top: 0;\n  --padding-bottom: 0;\n  font-size: 1.97vh;\n  color: #222222;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1pbnB1dC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7QUFDRjtBQUNFO0VBQ0UsU0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBQ0o7QUFFRTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFBSiIsImZpbGUiOiJzaGFyZWQtaW5wdXQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW5wdXQtY29udGFpbmVyIHtcbiAgLS1taW4taGVpZ2h0OiA3LjV2aDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuXG4gIC5sYWJlbCB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgY29sb3I6ICM5OUEwQUI7XG4gIH1cblxuICAuaW5wdXQge1xuICAgIC0tcGFkZGluZy10b3A6IDA7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMDtcbiAgICBmb250LXNpemU6IDEuOTd2aDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgfVxufVxuIl19 */";
      /***/
    },

    /***/
    "URgT":
    /*!*****************************************************************************!*\
      !*** ./src/app/@shared/components/shared-select/shared-select.component.ts ***!
      \*****************************************************************************/

    /*! exports provided: SharedSelectComponent */

    /***/
    function URgT(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharedSelectComponent", function () {
        return SharedSelectComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_shared_select_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./shared-select.component.html */
      "ue9h");
      /* harmony import */


      var _shared_select_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./shared-select.component.scss */
      "8cGW");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var SharedSelectComponent = /*#__PURE__*/function () {
        function SharedSelectComponent() {
          _classCallCheck(this, SharedSelectComponent);

          this.label = '';
          this.values = [];
        }

        _createClass(SharedSelectComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return SharedSelectComponent;
      }();

      SharedSelectComponent.ctorParameters = function () {
        return [];
      };

      SharedSelectComponent.propDecorators = {
        label: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        formControl: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        values: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      SharedSelectComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-select',
        template: _raw_loader_shared_select_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_select_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SharedSelectComponent);
      /***/
    },

    /***/
    "Uqa0":
    /*!*********************************************************************!*\
      !*** ./src/app/@core/services/outsource-auth/user-agent.service.ts ***!
      \*********************************************************************/

    /*! exports provided: UserAgentService */

    /***/
    function Uqa0(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UserAgentService", function () {
        return UserAgentService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_native_user_agent_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic-native/user-agent/ngx */
      "poBw");

      var UserAgentService = /*#__PURE__*/function () {
        function UserAgentService(userAgent) {
          _classCallCheck(this, UserAgentService);

          this.userAgent = userAgent;
        }

        _createClass(UserAgentService, [{
          key: "setUserAgent",
          value: function setUserAgent() {
            try {
              this.userAgent.set('Mozilla/5.0 Google').then(function (res) {
                return console.log(res);
              })["catch"](function (error) {
                return console.error(error);
              });
            } catch (e) {
              console.error(e);
            }
          }
        }]);

        return UserAgentService;
      }();

      UserAgentService.ctorParameters = function () {
        return [{
          type: _ionic_native_user_agent_ngx__WEBPACK_IMPORTED_MODULE_2__["UserAgent"]
        }];
      };

      UserAgentService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], UserAgentService);
      /***/
    },

    /***/
    "V5UK":
    /*!**************************************!*\
      !*** ./src/app/@core/core.module.ts ***!
      \**************************************/

    /*! exports provided: CoreModule */

    /***/
    function V5UK(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CoreModule", function () {
        return CoreModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _services_platform_app_config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./services/platform/app-config.service */
      "ophu");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _ionic_native_user_agent_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/user-agent/ngx */
      "poBw");
      /* harmony import */


      var _interceptors_error_interceptor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./interceptors/error.interceptor */
      "3WmZ");
      /* harmony import */


      var _interceptors_authentication_interceptor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./interceptors/authentication.interceptor */
      "C1aD");
      /* harmony import */


      var _capacitor_community_camera_preview__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @capacitor-community/camera-preview */
      "SFQQ");
      /* harmony import */


      var _services_app_token_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./services/app-token.service */
      "gcGz");
      /* harmony import */


      var _ionic_native_app_rate_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @ionic-native/app-rate/ngx */
      "k0k6"); // camera web view


      var CoreModule = function CoreModule() {
        _classCallCheck(this, CoreModule);
      };

      CoreModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"]],
        providers: [_ionic_native_app_rate_ngx__WEBPACK_IMPORTED_MODULE_10__["AppRate"], _ionic_native_user_agent_ngx__WEBPACK_IMPORTED_MODULE_5__["UserAgent"], {
          provide: _angular_core__WEBPACK_IMPORTED_MODULE_1__["APP_INITIALIZER"],
          useFactory: appInit,
          deps: [_services_platform_app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"]],
          multi: true
        }, {
          provide: _angular_core__WEBPACK_IMPORTED_MODULE_1__["APP_INITIALIZER"],
          useFactory: loadToken,
          deps: [_services_app_token_service__WEBPACK_IMPORTED_MODULE_9__["AppTokenService"]],
          multi: true
        }, {
          provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"],
          useClass: _interceptors_error_interceptor__WEBPACK_IMPORTED_MODULE_6__["ErrorInterceptor"],
          multi: true
        }, {
          provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"],
          useClass: _interceptors_authentication_interceptor__WEBPACK_IMPORTED_MODULE_7__["AuthenticationInterceptor"],
          multi: true
        }]
      })], CoreModule);

      function appInit(appConfigService) {
        return function () {
          return appConfigService.load();
        };
      }

      function loadToken(tokenService) {
        return function () {
          return tokenService.loadToken();
        };
      }
      /***/

    },

    /***/
    "VzVu":
    /*!**************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
      \**************************************************************************/

    /*! exports provided: default */

    /***/
    function VzVu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-app #appWindow>\n  <ion-content>\n    <ion-router-outlet></ion-router-outlet>\n  </ion-content>\n</ion-app>\n";
      /***/
    },

    /***/
    "ZAI4":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function ZAI4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "54vc");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "VYYF");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./app-routing.module */
      "vY5A");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./app.component */
      "Sy1n");
      /* harmony import */


      var _core_core_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./@core/core.module */
      "V5UK");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./@shared/shared.module */
      "pk6O");
      /* harmony import */


      var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/platform-browser/animations */
      "R1ws");
      /* harmony import */


      var capacitor_plugin_vk_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! capacitor-plugin-vk-auth */
      "M2fr");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1"); // import {LocationStrategy} from '@angular/common';


      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__["BrowserAnimationsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"].forRoot(), _ionic_storage__WEBPACK_IMPORTED_MODULE_12__["IonicStorageModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"], _core_core_module__WEBPACK_IMPORTED_MODULE_8__["CoreModule"], _shared_shared_module__WEBPACK_IMPORTED_MODULE_9__["SharedModule"]],
        providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__["SplashScreen"], capacitor_plugin_vk_auth__WEBPACK_IMPORTED_MODULE_11__["VKAuthWeb"]],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
      })], AppModule);
      /***/
    },

    /***/
    "ZmEp":
    /*!***************************************************************************************************!*\
      !*** ./src/app/@shared/components/shared-multiply-checker/shared-multiply-checker.component.scss ***!
      \***************************************************************************************************/

    /*! exports provided: default */

    /***/
    function ZmEp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".checker {\n  display: flex;\n  width: 2.43vh;\n  height: 2.43vh;\n  border: solid 0.25vh #6B7683;\n  border-radius: 0.25vh;\n  transition: 0.3s;\n}\n.checker__active {\n  background: #3A83F1;\n  border-color: #3A83F1;\n  transition: 0.3s;\n}\n.checker__icon {\n  width: 60%;\n  height: 100%;\n  margin: auto;\n  color: #ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1tdWx0aXBseS1jaGVja2VyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsNEJBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0FBQ0Y7QUFDRTtFQUNFLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSxnQkFBQTtBQUNKO0FBRUU7RUFDRSxVQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBQUoiLCJmaWxlIjoic2hhcmVkLW11bHRpcGx5LWNoZWNrZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2hlY2tlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiAyLjQzdmg7XG4gIGhlaWdodDogMi40M3ZoO1xuICBib3JkZXI6IHNvbGlkIDAuMjV2aCAjNkI3NjgzO1xuICBib3JkZXItcmFkaXVzOiAwLjI1dmg7XG4gIHRyYW5zaXRpb246IC4zcztcblxuICAmX19hY3RpdmUge1xuICAgIGJhY2tncm91bmQ6ICMzQTgzRjE7XG4gICAgYm9yZGVyLWNvbG9yOiAjM0E4M0YxO1xuICAgIHRyYW5zaXRpb246IC4zcztcbiAgfVxuXG4gICZfX2ljb24ge1xuICAgIHdpZHRoOiA2MCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBjb2xvcjogI2ZmZmZmZjtcbiAgfVxufVxuIl19 */";
      /***/
    },

    /***/
    "gcGz":
    /*!*****************************************************!*\
      !*** ./src/app/@core/services/app-token.service.ts ***!
      \*****************************************************/

    /*! exports provided: AppTokenService */

    /***/
    function gcGz(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppTokenService", function () {
        return AppTokenService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1");

      var AppTokenService = /*#__PURE__*/function () {
        function AppTokenService(storage) {
          _classCallCheck(this, AppTokenService);

          this.storage = storage;
          this.userAuthTokenPath = 'user-token';
          this.userAuthAnonTokenPath = 'user-token-anon';
          this.userAuthAnonToken = null;
          this.userToken$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        }

        _createClass(AppTokenService, [{
          key: "debugClear",
          value: function debugClear() {
            this.storage.set(this.userAuthTokenPath, null).then();
            this.storage.set(this.userAuthAnonTokenPath, null).then();
          }
        }, {
          key: "clear",
          value: function clear() {
            this.storage.set(this.userAuthTokenPath, null).then();
            this.userToken$.next(this.userAuthAnonToken);
          }
        }, {
          key: "saveToken",
          value: function saveToken(token, path) {
            this.storage.set(path, token).then();
          }
        }, {
          key: "loadToken",
          value: function loadToken() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var anonToken, token;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.storage.get(this.userAuthAnonTokenPath);

                    case 2:
                      anonToken = _context4.sent;
                      _context4.next = 5;
                      return this.storage.get(this.userAuthTokenPath);

                    case 5:
                      token = _context4.sent;
                      this.userAuthAnonToken = anonToken;
                      this.userToken$.next(token || anonToken);

                    case 8:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "userTokenAuth",
          set: function set(value) {
            this.saveToken(value, this.userAuthTokenPath);
            this.userToken$.next(value);
          }
        }, {
          key: "userToken",
          set: function set(value) {
            if (!value) {
              this.clear();
              return;
            }

            var path = this.userAuthTokenPath;

            if (!this.userAuthAnonToken && !this.userToken$.getValue() || this.userToken$.getValue() === this.userAuthAnonToken) {
              this.userAuthAnonToken = value;
              path = this.userAuthAnonTokenPath;
            }

            this.saveToken(value, path);
            this.userToken$.next(value);
          },
          get: function get() {
            return this.userToken$.getValue();
          }
        }]);

        return AppTokenService;
      }();

      AppTokenService.ctorParameters = function () {
        return [{
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"]
        }];
      };

      AppTokenService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AppTokenService);
      /***/
    },

    /***/
    "ikas":
    /*!*********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-button/shared-button.component.html ***!
      \*********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function ikas(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<button [ngClass]=\"type\" class=\"ion-activatable ripple-parent\">\n  <ion-ripple-effect></ion-ripple-effect>\n  <ng-content></ng-content>\n</button>\n";
      /***/
    },

    /***/
    "kLfG":
    /*!*****************************************************************************************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
      \*****************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function kLfG(module, exports, __webpack_require__) {
      var map = {
        "./ion-action-sheet.entry.js": ["dUtr", "common", 0],
        "./ion-alert.entry.js": ["Q8AI", "common", 1],
        "./ion-app_8.entry.js": ["hgI1", "common", 2],
        "./ion-avatar_3.entry.js": ["CfoV", "common", 3],
        "./ion-back-button.entry.js": ["Nt02", "common", 4],
        "./ion-backdrop.entry.js": ["Q2Bp", 5],
        "./ion-button_2.entry.js": ["0Pbj", "common", 6],
        "./ion-card_5.entry.js": ["ydQj", "common", 7],
        "./ion-checkbox.entry.js": ["4fMi", "common", 8],
        "./ion-chip.entry.js": ["czK9", "common", 9],
        "./ion-col_3.entry.js": ["/CAe", 10],
        "./ion-datetime_3.entry.js": ["WgF3", "common", 11],
        "./ion-fab_3.entry.js": ["uQcF", "common", 12],
        "./ion-img.entry.js": ["wHD8", 13],
        "./ion-infinite-scroll_2.entry.js": ["2lz6", 14],
        "./ion-input.entry.js": ["ercB", "common", 15],
        "./ion-item-option_3.entry.js": ["MGMP", "common", 16],
        "./ion-item_8.entry.js": ["9bur", "common", 17],
        "./ion-loading.entry.js": ["cABk", "common", 18],
        "./ion-menu_3.entry.js": ["kyFE", "common", 19],
        "./ion-modal.entry.js": ["TvZU", "common", 20],
        "./ion-nav_2.entry.js": ["vnES", "common", 21],
        "./ion-popover.entry.js": ["qCuA", "common", 22],
        "./ion-progress-bar.entry.js": ["0tOe", "common", 23],
        "./ion-radio_2.entry.js": ["h11V", "common", 24],
        "./ion-range.entry.js": ["XGij", "common", 25],
        "./ion-refresher_2.entry.js": ["nYbb", "common", 26],
        "./ion-reorder_2.entry.js": ["smMY", "common", 27],
        "./ion-ripple-effect.entry.js": ["STjf", 28],
        "./ion-route_4.entry.js": ["k5eQ", "common", 29],
        "./ion-searchbar.entry.js": ["OR5t", "common", 30],
        "./ion-segment_2.entry.js": ["fSgp", "common", 31],
        "./ion-select_3.entry.js": ["lfGF", "common", 32],
        "./ion-slide_2.entry.js": ["5xYT", 33],
        "./ion-spinner.entry.js": ["nI0H", "common", 34],
        "./ion-split-pane.entry.js": ["NAQR", 35],
        "./ion-tab-bar_2.entry.js": ["knkW", "common", 36],
        "./ion-tab_2.entry.js": ["TpdJ", "common", 37],
        "./ion-text.entry.js": ["ISmu", "common", 38],
        "./ion-textarea.entry.js": ["U7LX", "common", 39],
        "./ion-toast.entry.js": ["L3sA", "common", 40],
        "./ion-toggle.entry.js": ["IUOf", "common", 41],
        "./ion-virtual-scroll.entry.js": ["8Mb5", 42]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function webpackAsyncContextKeys() {
        return Object.keys(map);
      };

      webpackAsyncContext.id = "kLfG";
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    "lA1K":
    /*!********************************************************!*\
      !*** ./src/app/@core/services/api/api-user.service.ts ***!
      \********************************************************/

    /*! exports provided: ApiUserService */

    /***/
    function lA1K(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiUserService", function () {
        return ApiUserService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../platform/app-config.service */
      "ophu");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _logger_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../logger.service */
      "JGf/");

      var ApiUserService = /*#__PURE__*/function () {
        function ApiUserService(appConfigService, http, loggerService) {
          _classCallCheck(this, ApiUserService);

          this.http = http;
          this.loggerService = loggerService;
          this.restUrl = appConfigService.restUrl;
        }

        _createClass(ApiUserService, [{
          key: "userAnonymousRegister",
          value: function userAnonymousRegister(gender, birthdate, selectedRecommendations) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var body;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      body = {
                        gender: gender,
                        birthdate: birthdate,
                        selectedRecommendations: selectedRecommendations
                      };
                      _context5.prev = 1;
                      _context5.next = 4;
                      return this.http.post("".concat(this.restUrl, "/api/User/register/anonymous"), body).toPromise();

                    case 4:
                      return _context5.abrupt("return", _context5.sent);

                    case 7:
                      _context5.prev = 7;
                      _context5.t0 = _context5["catch"](1);
                      console.error('userAnonymousRegister', JSON.stringify(_context5.t0));
                      return _context5.abrupt("return", null);

                    case 11:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this, [[1, 7]]);
            }));
          }
        }, {
          key: "userRegister",
          value: function userRegister(data) {
            var _a;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var body;
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      body = {
                        name: data === null || data === void 0 ? void 0 : data.name,
                        email: data === null || data === void 0 ? void 0 : data.email,
                        password: (_a = data === null || data === void 0 ? void 0 : data.passwords) === null || _a === void 0 ? void 0 : _a.password
                      };
                      _context6.prev = 1;
                      _context6.next = 4;
                      return this.http.post("".concat(this.restUrl, "/api/User/register"), body).toPromise();

                    case 4:
                      return _context6.abrupt("return", _context6.sent);

                    case 7:
                      _context6.prev = 7;
                      _context6.t0 = _context6["catch"](1);
                      console.error('userRegister', JSON.stringify(_context6.t0));
                      return _context6.abrupt("return", null);

                    case 11:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this, [[1, 7]]);
            }));
          }
        }, {
          key: "userUpdate",
          value: function userUpdate(body) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      _context7.prev = 0;
                      _context7.next = 3;
                      return this.http.put("".concat(this.restUrl, "/api/User"), body).toPromise();

                    case 3:
                      return _context7.abrupt("return", _context7.sent);

                    case 6:
                      _context7.prev = 6;
                      _context7.t0 = _context7["catch"](0);
                      return _context7.abrupt("return", null);

                    case 9:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this, [[0, 6]]);
            }));
          }
        }, {
          key: "userLogin",
          value: function userLogin(data) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
              var body;
              return regeneratorRuntime.wrap(function _callee8$(_context8) {
                while (1) {
                  switch (_context8.prev = _context8.next) {
                    case 0:
                      body = {
                        email: data === null || data === void 0 ? void 0 : data.email,
                        password: data === null || data === void 0 ? void 0 : data.password
                      };
                      _context8.prev = 1;
                      _context8.next = 4;
                      return this.http.post("".concat(this.restUrl, "/api/User/auth"), body).toPromise();

                    case 4:
                      return _context8.abrupt("return", _context8.sent);

                    case 7:
                      _context8.prev = 7;
                      _context8.t0 = _context8["catch"](1);
                      console.error('userLogin', JSON.stringify(_context8.t0));
                      return _context8.abrupt("return", null);

                    case 11:
                    case "end":
                      return _context8.stop();
                  }
                }
              }, _callee8, this, [[1, 7]]);
            }));
          }
        }, {
          key: "userGoogle",
          value: function userGoogle(body) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
              return regeneratorRuntime.wrap(function _callee9$(_context9) {
                while (1) {
                  switch (_context9.prev = _context9.next) {
                    case 0:
                      _context9.prev = 0;
                      _context9.next = 3;
                      return this.http.post("".concat(this.restUrl, "/api/User/auth/google"), body).toPromise();

                    case 3:
                      return _context9.abrupt("return", _context9.sent);

                    case 6:
                      _context9.prev = 6;
                      _context9.t0 = _context9["catch"](0);
                      console.error('userGoogle', JSON.stringify(_context9.t0));
                      return _context9.abrupt("return", null);

                    case 10:
                    case "end":
                      return _context9.stop();
                  }
                }
              }, _callee9, this, [[0, 6]]);
            }));
          }
        }, {
          key: "userVk",
          value: function userVk(token) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
              var body;
              return regeneratorRuntime.wrap(function _callee10$(_context10) {
                while (1) {
                  switch (_context10.prev = _context10.next) {
                    case 0:
                      body = {
                        vkOAuthToken: token
                      };
                      _context10.prev = 1;
                      _context10.next = 4;
                      return this.http.post("".concat(this.restUrl, "/api/User/auth/vk"), body).toPromise();

                    case 4:
                      return _context10.abrupt("return", _context10.sent);

                    case 7:
                      _context10.prev = 7;
                      _context10.t0 = _context10["catch"](1);
                      console.error('userVk', JSON.stringify(_context10.t0));
                      return _context10.abrupt("return", null);

                    case 11:
                    case "end":
                      return _context10.stop();
                  }
                }
              }, _callee10, this, [[1, 7]]);
            }));
          }
        }, {
          key: "userCurrent",
          value: function userCurrent() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
              return regeneratorRuntime.wrap(function _callee11$(_context11) {
                while (1) {
                  switch (_context11.prev = _context11.next) {
                    case 0:
                      _context11.prev = 0;
                      _context11.next = 3;
                      return this.http.get("".concat(this.restUrl, "/api/User/current")).toPromise();

                    case 3:
                      return _context11.abrupt("return", _context11.sent);

                    case 6:
                      _context11.prev = 6;
                      _context11.t0 = _context11["catch"](0);
                      console.error('userCurrent', JSON.stringify(_context11.t0));
                      return _context11.abrupt("return", null);

                    case 10:
                    case "end":
                      return _context11.stop();
                  }
                }
              }, _callee11, this, [[0, 6]]);
            }));
          }
        }, {
          key: "sendReport",
          value: function sendReport(feedback) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
              return regeneratorRuntime.wrap(function _callee12$(_context12) {
                while (1) {
                  switch (_context12.prev = _context12.next) {
                    case 0:
                      _context12.prev = 0;
                      _context12.next = 3;
                      return this.http.post("".concat(this.restUrl, "/api/Feedback"), feedback).toPromise();

                    case 3:
                      return _context12.abrupt("return", true);

                    case 6:
                      _context12.prev = 6;
                      _context12.t0 = _context12["catch"](0);
                      console.error('sendReport', _context12.t0);
                      return _context12.abrupt("return", false);

                    case 10:
                    case "end":
                      return _context12.stop();
                  }
                }
              }, _callee12, this, [[0, 6]]);
            }));
          }
        }, {
          key: "getReportReference",
          value: function getReportReference() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
              return regeneratorRuntime.wrap(function _callee13$(_context13) {
                while (1) {
                  switch (_context13.prev = _context13.next) {
                    case 0:
                      _context13.prev = 0;
                      _context13.next = 3;
                      return this.http.get("".concat(this.restUrl, "/api/Feedback/categories")).toPromise();

                    case 3:
                      return _context13.abrupt("return", _context13.sent);

                    case 6:
                      _context13.prev = 6;
                      _context13.t0 = _context13["catch"](0);
                      console.error('getReportReference', _context13.t0);
                      return _context13.abrupt("return", []);

                    case 10:
                    case "end":
                      return _context13.stop();
                  }
                }
              }, _callee13, this, [[0, 6]]);
            }));
          }
        }, {
          key: "getFavorites",
          value: function getFavorites() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
              return regeneratorRuntime.wrap(function _callee14$(_context14) {
                while (1) {
                  switch (_context14.prev = _context14.next) {
                    case 0:
                      _context14.prev = 0;
                      _context14.next = 3;
                      return this.http.get("".concat(this.restUrl, "/api/Favourites")).toPromise();

                    case 3:
                      return _context14.abrupt("return", _context14.sent);

                    case 6:
                      _context14.prev = 6;
                      _context14.t0 = _context14["catch"](0);
                      console.error('getFavorites', _context14.t0);
                      return _context14.abrupt("return", null);

                    case 10:
                    case "end":
                      return _context14.stop();
                  }
                }
              }, _callee14, this, [[0, 6]]);
            }));
          }
        }, {
          key: "addFavorites",
          value: function addFavorites(feedId) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
              return regeneratorRuntime.wrap(function _callee15$(_context15) {
                while (1) {
                  switch (_context15.prev = _context15.next) {
                    case 0:
                      _context15.next = 2;
                      return this.http.post("".concat(this.restUrl, "/api/Favourites"), {
                        feedId: feedId
                      }).toPromise();

                    case 2:
                      return _context15.abrupt("return", _context15.sent);

                    case 3:
                    case "end":
                      return _context15.stop();
                  }
                }
              }, _callee15, this);
            }));
          }
        }, {
          key: "deleteFavorites",
          value: function deleteFavorites(feedId) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
              return regeneratorRuntime.wrap(function _callee16$(_context16) {
                while (1) {
                  switch (_context16.prev = _context16.next) {
                    case 0:
                      _context16.next = 2;
                      return this.http["delete"]("".concat(this.restUrl, "/api/Favourites/").concat(feedId)).toPromise();

                    case 2:
                      return _context16.abrupt("return", _context16.sent);

                    case 3:
                    case "end":
                      return _context16.stop();
                  }
                }
              }, _callee16, this);
            }));
          }
        }, {
          key: "getAllArticles",
          value: function getAllArticles() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
              return regeneratorRuntime.wrap(function _callee17$(_context17) {
                while (1) {
                  switch (_context17.prev = _context17.next) {
                    case 0:
                      _context17.prev = 0;
                      _context17.next = 3;
                      return this.http.get("".concat(this.restUrl, "/api/Articles/all")).toPromise();

                    case 3:
                      return _context17.abrupt("return", _context17.sent);

                    case 6:
                      _context17.prev = 6;
                      _context17.t0 = _context17["catch"](0);
                      console.error('getAllArticles', _context17.t0);
                      return _context17.abrupt("return", []);

                    case 10:
                    case "end":
                      return _context17.stop();
                  }
                }
              }, _callee17, this, [[0, 6]]);
            }));
          }
        }, {
          key: "dropPassword",
          value: function dropPassword(email) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee18() {
              var body;
              return regeneratorRuntime.wrap(function _callee18$(_context18) {
                while (1) {
                  switch (_context18.prev = _context18.next) {
                    case 0:
                      body = {
                        email: email
                      };
                      _context18.prev = 1;
                      _context18.next = 4;
                      return this.http.post("".concat(this.restUrl, "/api/Password/reset-via-email"), body, {
                        responseType: 'text'
                      }).toPromise();

                    case 4:
                      return _context18.abrupt("return", true);

                    case 7:
                      _context18.prev = 7;
                      _context18.t0 = _context18["catch"](1);
                      console.error('dropPassword', _context18.t0);
                      return _context18.abrupt("return", false);

                    case 11:
                    case "end":
                      return _context18.stop();
                  }
                }
              }, _callee18, this, [[1, 7]]);
            }));
          }
        }, {
          key: "refreshPassword",
          value: function refreshPassword(currentPassword, newPassword) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee19() {
              var body;
              return regeneratorRuntime.wrap(function _callee19$(_context19) {
                while (1) {
                  switch (_context19.prev = _context19.next) {
                    case 0:
                      body = {
                        currentPassword: currentPassword,
                        newPassword: newPassword
                      };
                      _context19.prev = 1;
                      _context19.next = 4;
                      return this.http.post("".concat(this.restUrl, "/api/Password"), body).toPromise();

                    case 4:
                      return _context19.abrupt("return", true);

                    case 7:
                      _context19.prev = 7;
                      _context19.t0 = _context19["catch"](1);
                      console.error('refreshPassword', _context19.t0);
                      return _context19.abrupt("return", false);

                    case 11:
                    case "end":
                      return _context19.stop();
                  }
                }
              }, _callee19, this, [[1, 7]]);
            }));
          }
        }]);

        return ApiUserService;
      }();

      ApiUserService.ctorParameters = function () {
        return [{
          type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
        }, {
          type: _logger_service__WEBPACK_IMPORTED_MODULE_4__["LoggerService"]
        }];
      };

      ApiUserService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ApiUserService);
      /***/
    },

    /***/
    "mLhf":
    /*!***************************************************************************************!*\
      !*** ./src/app/@shared/components/shared-form-error/shared-form-error.component.scss ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function mLhf(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "span {\n  color: #FF3B30;\n  font-size: 1.72vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1mb3JtLWVycm9yLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGlCQUFBO0FBQ0YiLCJmaWxlIjoic2hhcmVkLWZvcm0tZXJyb3IuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJzcGFuIHtcbiAgY29sb3I6ICNGRjNCMzA7XG4gIGZvbnQtc2l6ZTogMS43MnZoO1xufVxuIl19 */";
      /***/
    },

    /***/
    "ophu":
    /*!***************************************************************!*\
      !*** ./src/app/@core/services/platform/app-config.service.ts ***!
      \***************************************************************/

    /*! exports provided: AppConfigService */

    /***/
    function ophu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppConfigService", function () {
        return AppConfigService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");

      var AppConfigService = /*#__PURE__*/function () {
        function AppConfigService(httpClient, platformLocation) {
          _classCallCheck(this, AppConfigService);

          this.httpClient = httpClient;
          this.platformLocation = platformLocation;
        }

        _createClass(AppConfigService, [{
          key: "loadAppConfig",
          value: function loadAppConfig() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee20() {
              return regeneratorRuntime.wrap(function _callee20$(_context20) {
                while (1) {
                  switch (_context20.prev = _context20.next) {
                    case 0:
                      _context20.next = 2;
                      return this.httpClient.get('assets/config.json').toPromise();

                    case 2:
                      this.appConfig = _context20.sent;

                    case 3:
                    case "end":
                      return _context20.stop();
                  }
                }
              }, _callee20, this);
            }));
          }
        }, {
          key: "load",
          value: function load() {
            var _this4 = this;

            return this.httpClient.get('assets/config.json').toPromise().then(function (x) {
              _this4.appConfig = x;
              return x;
            });
          }
        }, {
          key: "restUrl",
          get: function get() {
            if (!this.appConfig) {
              throw Error('Config file not loaded!');
            }

            return this.appConfig.restUrl;
          }
        }, {
          key: "userUrl",
          get: function get() {
            if (!this.appConfig) {
              throw Error('Config file not loaded!');
            }

            return this.appConfig.userUrl;
          }
        }, {
          key: "recognitionUrl",
          get: function get() {
            if (!this.appConfig) {
              throw Error('Config file not loaded!');
            }

            return this.appConfig.recognitionUrl;
          }
        }, {
          key: "fileUrl",
          get: function get() {
            if (!this.appConfig) {
              throw Error('Config file not loaded!');
            }

            return this.appConfig.fileUrl;
          }
        }, {
          key: "locationOrigin",
          get: function get() {
            return this.platformLocation.location.origin;
          }
        }]);

        return AppConfigService;
      }();

      AppConfigService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
        }, {
          type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["PlatformLocation"]
        }];
      };

      AppConfigService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AppConfigService);
      /***/
    },

    /***/
    "p7KD":
    /*!***********************************************************************************!*\
      !*** ./src/app/@shared/components/shared-textarea/shared-textarea.component.scss ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function p7KD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-item {\n  --min-height: 7.5vh;\n  --padding-start: 0;\n}\n\nion-label {\n  font-size: 1.97vh !important;\n  font-weight: 500 !important;\n  color: #99A0AB !important;\n}\n\nion-textarea {\n  --padding-top: 0;\n  --padding-bottom: 0;\n  font-size: 1.97vh;\n  color: #222222;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC10ZXh0YXJlYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLDRCQUFBO0VBQ0EsMkJBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQUNGIiwiZmlsZSI6InNoYXJlZC10ZXh0YXJlYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcbiAgLS1taW4taGVpZ2h0OiA3LjV2aDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xufVxuXG5pb24tbGFiZWwge1xuICBmb250LXNpemU6IDEuOTd2aCAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogNTAwICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjOTlBMEFCICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10ZXh0YXJlYSB7XG4gIC0tcGFkZGluZy10b3A6IDA7XG4gIC0tcGFkZGluZy1ib3R0b206IDA7XG4gIGZvbnQtc2l6ZTogMS45N3ZoO1xuICBjb2xvcjogIzIyMjIyMjtcbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "pk6O":
    /*!******************************************!*\
      !*** ./src/app/@shared/shared.module.ts ***!
      \******************************************/

    /*! exports provided: SharedModule */

    /***/
    function pk6O(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharedModule", function () {
        return SharedModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _pipes_safe_url_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./pipes/safe-url.pipe */
      "5XVG");
      /* harmony import */


      var angular_svg_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! angular-svg-icon */
      "OFbc");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_common_locales_fr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/common/locales/fr */
      "Hfs6");
      /* harmony import */


      var _angular_common_locales_fr__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_fr__WEBPACK_IMPORTED_MODULE_7__);
      /* harmony import */


      var _components_shared_button_shared_button_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./components/shared-button/shared-button.component */
      "DwYw");
      /* harmony import */


      var _components_shared_input_shared_input_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./components/shared-input/shared-input.component */
      "zHSy");
      /* harmony import */


      var _components_shared_multiply_checker_shared_multiply_checker_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ./components/shared-multiply-checker/shared-multiply-checker.component */
      "v/Ss");
      /* harmony import */


      var _components_shared_select_shared_select_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ./components/shared-select/shared-select.component */
      "URgT");
      /* harmony import */


      var _components_shared_textarea_shared_textarea_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ./components/shared-textarea/shared-textarea.component */
      "FctL");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _components_shared_form_error_shared_form_error_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ./components/shared-form-error/shared-form-error.component */
      "7RHv");
      /* harmony import */


      var _components_shared_image_slider_shared_image_slider_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! ./components/shared-image-slider/shared-image-slider.component */
      "9mOG");
      /* harmony import */


      var _pipes_category_split_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! ./pipes/category-split.pipe */
      "rJkM");

      Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["registerLocaleData"])(_angular_common_locales_fr__WEBPACK_IMPORTED_MODULE_7___default.a);

      var SharedModule = function SharedModule() {
        _classCallCheck(this, SharedModule);
      };

      SharedModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_pipes_safe_url_pipe__WEBPACK_IMPORTED_MODULE_4__["SafeUrlPipe"], _components_shared_button_shared_button_component__WEBPACK_IMPORTED_MODULE_8__["SharedButtonComponent"], _components_shared_input_shared_input_component__WEBPACK_IMPORTED_MODULE_9__["SharedInputComponent"], _components_shared_multiply_checker_shared_multiply_checker_component__WEBPACK_IMPORTED_MODULE_10__["SharedMultiplyCheckerComponent"], _components_shared_select_shared_select_component__WEBPACK_IMPORTED_MODULE_11__["SharedSelectComponent"], _components_shared_textarea_shared_textarea_component__WEBPACK_IMPORTED_MODULE_12__["SharedTextareaComponent"], _components_shared_form_error_shared_form_error_component__WEBPACK_IMPORTED_MODULE_14__["SharedFormErrorComponent"], _components_shared_image_slider_shared_image_slider_component__WEBPACK_IMPORTED_MODULE_15__["SharedImageSliderComponent"], _pipes_category_split_pipe__WEBPACK_IMPORTED_MODULE_16__["CategorySplitPipe"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], angular_svg_icon__WEBPACK_IMPORTED_MODULE_5__["AngularSvgIconModule"].forRoot(), _angular_forms__WEBPACK_IMPORTED_MODULE_13__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ReactiveFormsModule"]],
        exports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], angular_svg_icon__WEBPACK_IMPORTED_MODULE_5__["AngularSvgIconModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClientModule"], _components_shared_button_shared_button_component__WEBPACK_IMPORTED_MODULE_8__["SharedButtonComponent"], _components_shared_input_shared_input_component__WEBPACK_IMPORTED_MODULE_9__["SharedInputComponent"], _components_shared_multiply_checker_shared_multiply_checker_component__WEBPACK_IMPORTED_MODULE_10__["SharedMultiplyCheckerComponent"], _components_shared_select_shared_select_component__WEBPACK_IMPORTED_MODULE_11__["SharedSelectComponent"], _components_shared_textarea_shared_textarea_component__WEBPACK_IMPORTED_MODULE_12__["SharedTextareaComponent"], _components_shared_form_error_shared_form_error_component__WEBPACK_IMPORTED_MODULE_14__["SharedFormErrorComponent"], _components_shared_image_slider_shared_image_slider_component__WEBPACK_IMPORTED_MODULE_15__["SharedImageSliderComponent"], _pipes_safe_url_pipe__WEBPACK_IMPORTED_MODULE_4__["SafeUrlPipe"], _pipes_category_split_pipe__WEBPACK_IMPORTED_MODULE_16__["CategorySplitPipe"]]
      })], SharedModule);
      /***/
    },

    /***/
    "qCjG":
    /*!***************************************************************!*\
      !*** ./src/app/@core/services/platform/status-bar.service.ts ***!
      \***************************************************************/

    /*! exports provided: StatusBarService */

    /***/
    function qCjG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StatusBarService", function () {
        return StatusBarService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @capacitor/core */
      "gcOT");

      var StatusBar = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].StatusBar;

      var StatusBarService = /*#__PURE__*/function () {
        function StatusBarService() {
          _classCallCheck(this, StatusBarService);
        } // TODO: add theme


        _createClass(StatusBarService, [{
          key: "setDefault",
          value: function setDefault() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee21() {
              return regeneratorRuntime.wrap(function _callee21$(_context21) {
                while (1) {
                  switch (_context21.prev = _context21.next) {
                    case 0:
                      _context21.prev = 0;
                      _context21.next = 3;
                      return StatusBar.setOverlaysWebView({
                        overlay: true
                      });

                    case 3:
                      _context21.next = 5;
                      return StatusBar.show();

                    case 5:
                      _context21.next = 7;
                      return StatusBar.setStyle({
                        style: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["StatusBarStyle"].Light
                      });

                    case 7:
                      _context21.next = 9;
                      return StatusBar.setBackgroundColor({
                        color: '#ffffff'
                      });

                    case 9:
                      _context21.next = 14;
                      break;

                    case 11:
                      _context21.prev = 11;
                      _context21.t0 = _context21["catch"](0);
                      console.warn('StatusBar Error', _context21.t0);

                    case 14:
                    case "end":
                      return _context21.stop();
                  }
                }
              }, _callee21, null, [[0, 11]]);
            }));
          }
        }, {
          key: "hide",
          value: function hide() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee22() {
              return regeneratorRuntime.wrap(function _callee22$(_context22) {
                while (1) {
                  switch (_context22.prev = _context22.next) {
                    case 0:
                      _context22.prev = 0;
                      _context22.next = 3;
                      return StatusBar.hide();

                    case 3:
                      _context22.next = 8;
                      break;

                    case 5:
                      _context22.prev = 5;
                      _context22.t0 = _context22["catch"](0);
                      console.warn('StatusBar Error', _context22.t0);

                    case 8:
                    case "end":
                      return _context22.stop();
                  }
                }
              }, _callee22, null, [[0, 5]]);
            }));
          }
        }]);

        return StatusBarService;
      }();

      StatusBarService.ctorParameters = function () {
        return [];
      };

      StatusBarService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], StatusBarService);
      /***/
    },

    /***/
    "qWzX":
    /*!*****************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-multiply-checker/shared-multiply-checker.component.html ***!
      \*****************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function qWzX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"checker\" [class.checker__active]=\"isActive\">\n  <svg-icon class=\"checker__icon\" src=\"assets/icon/svg/check.svg\"></svg-icon>\n</div>\n";
      /***/
    },

    /***/
    "rJkM":
    /*!******************************************************!*\
      !*** ./src/app/@shared/pipes/category-split.pipe.ts ***!
      \******************************************************/

    /*! exports provided: CategorySplitPipe */

    /***/
    function rJkM(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CategorySplitPipe", function () {
        return CategorySplitPipe;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var CategorySplitPipe = /*#__PURE__*/function () {
        function CategorySplitPipe() {
          _classCallCheck(this, CategorySplitPipe);
        }

        _createClass(CategorySplitPipe, [{
          key: "transform",
          value: function transform(value) {
            var categoryArray = value.split('/');
            return categoryArray[categoryArray.length - 1];
          }
        }]);

        return CategorySplitPipe;
      }();

      CategorySplitPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'categorySplit'
      })], CategorySplitPipe);
      /***/
    },

    /***/
    "tTdR":
    /*!*****************************************************!*\
      !*** ./src/app/@core/services/user-info.service.ts ***!
      \*****************************************************/

    /*! exports provided: UserInfoService */

    /***/
    function tTdR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UserInfoService", function () {
        return UserInfoService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _api_api_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./api/api-user.service */
      "lA1K");
      /* harmony import */


      var _app_token_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./app-token.service */
      "gcGz");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1");
      /* harmony import */


      var _api_api_file_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./api/api-file.service */
      "0SLh");

      var UserInfoService = /*#__PURE__*/function () {
        function UserInfoService(apiUserService, apiFileService, tokenService, storage) {
          _classCallCheck(this, UserInfoService);

          this.apiUserService = apiUserService;
          this.apiFileService = apiFileService;
          this.tokenService = tokenService;
          this.storage = storage;
          this.initialGenderPath = 'initial-gender';
          this.genderReference = {
            male: 'Мужской',
            female: 'Женский'
          };
          this.authUser$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](null);
          this.selectedPreFavourites = [];

          this.isAnonUser = function (user) {
            return !(!!(user === null || user === void 0 ? void 0 : user.email) || !!user.name);
          }; // this.tokenService.debugClear();

        }

        _createClass(UserInfoService, [{
          key: "getAllArticles",
          value: function getAllArticles() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee23() {
              var _this5 = this;

              var articles;
              return regeneratorRuntime.wrap(function _callee23$(_context23) {
                while (1) {
                  switch (_context23.prev = _context23.next) {
                    case 0:
                      _context23.next = 2;
                      return this.apiUserService.getAllArticles();

                    case 2:
                      articles = _context23.sent;
                      articles.map(function (x) {
                        return x.jsonContent;
                      }).map(function (x) {
                        return x.blocks;
                      }).forEach(function (x) {
                        return x.filter(function (k) {
                          return k.type === 'photo';
                        }).forEach(function (k) {
                          return k.urls = k.urls.map(function (u) {
                            return _this5.apiFileService.getArticlePhoto(u);
                          });
                        });
                      });
                      articles.forEach(function (x) {
                        x.title = x.jsonContent.title;
                        x.imageUrl = x.jsonContent.blocks.find(function (b) {
                          return b.type === 'photo';
                        }).urls[0];
                      });
                      return _context23.abrupt("return", articles);

                    case 6:
                    case "end":
                      return _context23.stop();
                  }
                }
              }, _callee23, this);
            }));
          }
        }, {
          key: "setInitialGender",
          value: function setInitialGender(value) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee24() {
              return regeneratorRuntime.wrap(function _callee24$(_context24) {
                while (1) {
                  switch (_context24.prev = _context24.next) {
                    case 0:
                      value = value !== null && value !== void 0 ? value : 'female';
                      _context24.next = 3;
                      return this.storage.set(this.initialGenderPath, value);

                    case 3:
                    case "end":
                      return _context24.stop();
                  }
                }
              }, _callee24, this);
            }));
          }
        }, {
          key: "getInitialGender",
          value: function getInitialGender() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee25() {
              var value;
              return regeneratorRuntime.wrap(function _callee25$(_context25) {
                while (1) {
                  switch (_context25.prev = _context25.next) {
                    case 0:
                      _context25.next = 2;
                      return this.storage.get(this.initialGenderPath);

                    case 2:
                      value = _context25.sent;
                      return _context25.abrupt("return", value !== null && value !== void 0 ? value : 'female');

                    case 4:
                    case "end":
                      return _context25.stop();
                  }
                }
              }, _callee25, this);
            }));
          }
        }, {
          key: "updateUser",
          value: function updateUser(user) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee26() {
              var res;
              return regeneratorRuntime.wrap(function _callee26$(_context26) {
                while (1) {
                  switch (_context26.prev = _context26.next) {
                    case 0:
                      _context26.next = 2;
                      return this.apiUserService.userUpdate(user);

                    case 2:
                      res = _context26.sent;
                      res = res !== null && res !== void 0 ? res : Object.assign({}, this.authUser$.getValue());
                      this.authUser$.next(res);
                      return _context26.abrupt("return", res);

                    case 6:
                    case "end":
                      return _context26.stop();
                  }
                }
              }, _callee26, this);
            }));
          }
        }, {
          key: "setUser",
          value: function setUser(user) {
            if (!user) {
              return;
            }

            this.authUser$.next(Object.assign({}, user));

            if (!!(user === null || user === void 0 ? void 0 : user.token)) {
              this.tokenService.userTokenAuth = user.token;
            }
          }
        }, {
          key: "clearUser",
          value: function clearUser() {
            this.authUser$.next(null);
            this.tokenService.userToken = null;
          }
        }, {
          key: "init",
          value: function init() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee27() {
              var user;
              return regeneratorRuntime.wrap(function _callee27$(_context27) {
                while (1) {
                  switch (_context27.prev = _context27.next) {
                    case 0:
                      if (!this.authUser$.getValue()) {
                        _context27.next = 2;
                        break;
                      }

                      return _context27.abrupt("return");

                    case 2:
                      _context27.next = 4;
                      return this.getUserFromStorage();

                    case 4:
                      user = _context27.sent;

                      if (!(!user || this.isAnonUser(user))) {
                        _context27.next = 10;
                        break;
                      }

                      if (this.tokenService.userToken) {
                        _context27.next = 9;
                        break;
                      }

                      _context27.next = 9;
                      return this.anonymousRegister();

                    case 9:
                      return _context27.abrupt("return");

                    case 10:
                      this.setUser(user);

                    case 11:
                    case "end":
                      return _context27.stop();
                  }
                }
              }, _callee27, this);
            }));
          }
        }, {
          key: "getUserFromStorage",
          value: function getUserFromStorage() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee28() {
              return regeneratorRuntime.wrap(function _callee28$(_context28) {
                while (1) {
                  switch (_context28.prev = _context28.next) {
                    case 0:
                      _context28.next = 2;
                      return this.apiUserService.userCurrent();

                    case 2:
                      return _context28.abrupt("return", _context28.sent);

                    case 3:
                    case "end":
                      return _context28.stop();
                  }
                }
              }, _callee28, this);
            }));
          }
        }, {
          key: "anonymousRegister",
          value: function anonymousRegister() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee29() {
              var gender, anonUser;
              return regeneratorRuntime.wrap(function _callee29$(_context29) {
                while (1) {
                  switch (_context29.prev = _context29.next) {
                    case 0:
                      _context29.next = 2;
                      return this.getInitialGender();

                    case 2:
                      gender = _context29.sent;
                      _context29.next = 5;
                      return this.apiUserService.userAnonymousRegister(gender, new Date(), this.selectedPreFavourites);

                    case 5:
                      anonUser = _context29.sent;

                      if (anonUser) {
                        _context29.next = 8;
                        break;
                      }

                      return _context29.abrupt("return");

                    case 8:
                      this.tokenService.userToken = anonUser === null || anonUser === void 0 ? void 0 : anonUser.token;

                    case 9:
                    case "end":
                      return _context29.stop();
                  }
                }
              }, _callee29, this);
            }));
          }
        }]);

        return UserInfoService;
      }();

      UserInfoService.ctorParameters = function () {
        return [{
          type: _api_api_user_service__WEBPACK_IMPORTED_MODULE_3__["ApiUserService"]
        }, {
          type: _api_api_file_service__WEBPACK_IMPORTED_MODULE_6__["ApiFileService"]
        }, {
          type: _app_token_service__WEBPACK_IMPORTED_MODULE_4__["AppTokenService"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"]
        }];
      };

      UserInfoService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], UserInfoService);
      /***/
    },

    /***/
    "ue9h":
    /*!*********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-select/shared-select.component.html ***!
      \*********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function ue9h(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-item>\n  <ion-label position=\"floating\"> {{ label }} </ion-label>\n  <ion-select *ngIf=\"formControl\" [formControl]=\"formControl\" cancelText=\"Отмена\" mode=\"md\" interface=\"action-sheet\">\n    <ion-select-option *ngFor=\"let value of values\" [value]=\"value.value\"> {{ value.title }} </ion-select-option>\n  </ion-select>\n</ion-item>\n";
      /***/
    },

    /***/
    "v/Ss":
    /*!*************************************************************************************************!*\
      !*** ./src/app/@shared/components/shared-multiply-checker/shared-multiply-checker.component.ts ***!
      \*************************************************************************************************/

    /*! exports provided: SharedMultiplyCheckerComponent */

    /***/
    function vSs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharedMultiplyCheckerComponent", function () {
        return SharedMultiplyCheckerComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_shared_multiply_checker_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./shared-multiply-checker.component.html */
      "qWzX");
      /* harmony import */


      var _shared_multiply_checker_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./shared-multiply-checker.component.scss */
      "ZmEp");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var SharedMultiplyCheckerComponent = /*#__PURE__*/function () {
        function SharedMultiplyCheckerComponent() {
          _classCallCheck(this, SharedMultiplyCheckerComponent);

          this.isActive = false;
        }

        _createClass(SharedMultiplyCheckerComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return SharedMultiplyCheckerComponent;
      }();

      SharedMultiplyCheckerComponent.ctorParameters = function () {
        return [];
      };

      SharedMultiplyCheckerComponent.propDecorators = {
        isActive: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      SharedMultiplyCheckerComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-multiply-checker',
        template: _raw_loader_shared_multiply_checker_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_multiply_checker_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SharedMultiplyCheckerComponent);
      /***/
    },

    /***/
    "vY5A":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function vY5A(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _core_guards_authentication_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./@core/guards/authentication.guard */
      "vbgO");

      var routes = [{
        path: 'preview',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-page-preview-page-preview-module */
          "pages-page-preview-page-preview-module").then(__webpack_require__.bind(null,
          /*! ./pages/page-preview/page-preview.module */
          "1XnR")).then(function (m) {
            return m.PagePreviewModule;
          });
        },
        canActivate: [_core_guards_authentication_guard__WEBPACK_IMPORTED_MODULE_3__["AuthenticationGuard"]]
      }, {
        path: 'user_init',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-page-user-init-page-user-init-module */
          "pages-page-user-init-page-user-init-module").then(__webpack_require__.bind(null,
          /*! ./pages/page-user-init/page-user-init.module */
          "VzqC")).then(function (m) {
            return m.PageUserInitModule;
          });
        }
      }, {
        path: 'pre_favorites',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-page-prefavorites-page-prefavorites-module */
          "pages-page-prefavorites-page-prefavorites-module").then(__webpack_require__.bind(null,
          /*! ./pages/page-prefavorites/page-prefavorites.module */
          "LZbA")).then(function (m) {
            return m.PagePrefavoritesModule;
          });
        }
      }, {
        path: 'main',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | main-main-module */
          "main-main-module").then(__webpack_require__.bind(null,
          /*! ./main/main.module */
          "XpXM")).then(function (m) {
            return m.MainModule;
          });
        }
      }, {
        path: '**',
        redirectTo: 'preview',
        pathMatch: 'full'
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
          preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["NoPreloading"]
        })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AppRoutingModule);
      /***/
    },

    /***/
    "vbgO":
    /*!******************************************************!*\
      !*** ./src/app/@core/guards/authentication.guard.ts ***!
      \******************************************************/

    /*! exports provided: AuthenticationGuard */

    /***/
    function vbgO(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AuthenticationGuard", function () {
        return AuthenticationGuard;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _services_app_token_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/app-token.service */
      "gcGz");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var AuthenticationGuard = /*#__PURE__*/function () {
        function AuthenticationGuard(tokenService, navCtrl) {
          _classCallCheck(this, AuthenticationGuard);

          this.tokenService = tokenService;
          this.navCtrl = navCtrl;
        }

        _createClass(AuthenticationGuard, [{
          key: "canActivate",
          value: function canActivate(route, state) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee30() {
              return regeneratorRuntime.wrap(function _callee30$(_context30) {
                while (1) {
                  switch (_context30.prev = _context30.next) {
                    case 0:
                      if (!this.tokenService.userToken) {
                        _context30.next = 5;
                        break;
                      }

                      this.navCtrl.navigateRoot('/main').then();
                      return _context30.abrupt("return", false);

                    case 5:
                      return _context30.abrupt("return", true);

                    case 6:
                    case "end":
                      return _context30.stop();
                  }
                }
              }, _callee30, this);
            }));
          }
        }]);

        return AuthenticationGuard;
      }();

      AuthenticationGuard.ctorParameters = function () {
        return [{
          type: _services_app_token_service__WEBPACK_IMPORTED_MODULE_2__["AppTokenService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
        }];
      };

      AuthenticationGuard = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AuthenticationGuard);
      /***/
    },

    /***/
    "ynWL":
    /*!************************************!*\
      !*** ./src/app/app.component.scss ***!
      \************************************/

    /*! exports provided: default */

    /***/
    function ynWL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".camera-preview {\n  height: 100%;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0FBQ0YiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhbWVyYS1wcmV2aWV3IHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "zHSy":
    /*!***************************************************************************!*\
      !*** ./src/app/@shared/components/shared-input/shared-input.component.ts ***!
      \***************************************************************************/

    /*! exports provided: SharedInputComponent */

    /***/
    function zHSy(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SharedInputComponent", function () {
        return SharedInputComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_shared_input_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./shared-input.component.html */
      "9jvt");
      /* harmony import */


      var _shared_input_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./shared-input.component.scss */
      "TtwI");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var SharedInputComponent = /*#__PURE__*/function () {
        function SharedInputComponent() {
          _classCallCheck(this, SharedInputComponent);

          this.value = '';
          this.valueChange = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.label = '';
          this.type = 'text';
        }

        _createClass(SharedInputComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return SharedInputComponent;
      }();

      SharedInputComponent.ctorParameters = function () {
        return [];
      };

      SharedInputComponent.propDecorators = {
        formControl: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        value: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        valueChange: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        label: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        type: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      SharedInputComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-input',
        template: _raw_loader_shared_input_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_input_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SharedInputComponent);
      /***/
    },

    /***/
    "zUnb":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function zUnb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/platform-browser-dynamic */
      "a3Wg");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "ZAI4");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./environments/environment */
      "AytR");
      /* harmony import */


      var _ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/pwa-elements/loader */
      "2Zi2");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.log(err);
      }); // Call the element loader after the platform has been bootstrapped

      Object(_ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_4__["defineCustomElements"])(window).then(function (r) {
        return r;
      });
      /***/
    },

    /***/
    "zn8P":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function zn8P(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "zn8P";
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map