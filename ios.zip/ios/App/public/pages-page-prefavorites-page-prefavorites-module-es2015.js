(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-page-prefavorites-page-prefavorites-module"],{

/***/ "1ZGv":
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/page-prefavorites/components/page-prefavorites-item/page-prefavorites-item.component.ts ***!
  \***************************************************************************************************************/
/*! exports provided: PagePrefavoritesItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagePrefavoritesItemComponent", function() { return PagePrefavoritesItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_prefavorites_item_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-prefavorites-item.component.html */ "QJbL");
/* harmony import */ var _page_prefavorites_item_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-prefavorites-item.component.scss */ "DUIf");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PagePrefavoritesItemComponent = class PagePrefavoritesItemComponent {
    constructor() {
        this.isSelected = false;
    }
    ngOnInit() {
    }
};
PagePrefavoritesItemComponent.ctorParameters = () => [];
PagePrefavoritesItemComponent.propDecorators = {
    image: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    isSelected: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PagePrefavoritesItemComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-prefavorites-item',
        template: _raw_loader_page_prefavorites_item_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_prefavorites_item_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PagePrefavoritesItemComponent);



/***/ }),

/***/ "7mVc":
/*!************************************************************!*\
  !*** ./src/app/@core/services/recognition-info.service.ts ***!
  \************************************************************/
/*! exports provided: RecognitionInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecognitionInfoService", function() { return RecognitionInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _user_info_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-info.service */ "tTdR");
/* harmony import */ var _api_api_recognition_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api/api-recognition.service */ "p0lb");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");





let RecognitionInfoService = class RecognitionInfoService {
    constructor(userInfoService, apiRecognitionService) {
        this.userInfoService = userInfoService;
        this.apiRecognitionService = apiRecognitionService;
        this.recommendCards$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]([null, null, null]);
    }
    textResultMapper(result) {
        var _a;
        return {
            scoreId: result === null || result === void 0 ? void 0 : result.id,
            previews: (_a = result === null || result === void 0 ? void 0 : result.searchResults) !== null && _a !== void 0 ? _a : [],
        };
    }
    getStartReco() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const gender = yield this.userInfoService.getInitialGender();
            return yield this.apiRecognitionService.getStartScreenReco(gender);
        });
    }
    getMainRecommends() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.isMainRecommendsLoaded()) {
                return;
            }
            const res = yield this.apiRecognitionService.getMainRecommends();
            this.recommendCards$.next(res);
        });
    }
    isMainRecommendsLoaded() {
        return !this.recommendCards$.getValue().every(x => x === null);
    }
};
RecognitionInfoService.ctorParameters = () => [
    { type: _user_info_service__WEBPACK_IMPORTED_MODULE_2__["UserInfoService"] },
    { type: _api_api_recognition_service__WEBPACK_IMPORTED_MODULE_3__["ApiRecognitionService"] }
];
RecognitionInfoService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RecognitionInfoService);



/***/ }),

/***/ "8/1j":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-prefavorites/page-prefavorites.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"header\"> Выберите что вам нравится </div>\n  <div class=\"subheader\"> На основе вашего выбора, мы будем рекоменовать вам одежду </div>\n  <div class=\"content-wrapper\">\n    <app-page-prefavorites-item\n      *ngFor=\"let item of (itemsGroup?.itemsObserver$ | async) || []\"\n      class=\"item\"\n      [image]=\"item.imageUrl\"\n      [isSelected]=\"item.isSelected\"\n      (click)=\"itemsGroup.select(item)\"\n    ></app-page-prefavorites-item>\n  </div>\n  <div class=\"button-container\" [class.button-container__unactive]=\"!(itemsGroup?.isValid$ | async)\">\n    <app-shared-button (click)=\"continue()\"> Продолжить </app-shared-button>\n  </div>\n</div>\n");

/***/ }),

/***/ "DUIf":
/*!*****************************************************************************************************************!*\
  !*** ./src/app/pages/page-prefavorites/components/page-prefavorites-item/page-prefavorites-item.component.scss ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  width: inherit;\n  height: inherit;\n  overflow: hidden;\n  background: #DCE0EB;\n  border-radius: 3.2vw;\n}\n.container .selected-wrapper {\n  opacity: 0;\n  display: flex;\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  background: rgba(47, 52, 65, 0.5);\n  z-index: 1;\n  transition: 0.3s;\n}\n.container .selected-circle {\n  margin: auto;\n  padding: 0.4vh;\n  width: 2.5vh;\n  height: 2.5vh;\n  background: #45BF78;\n  border-radius: 50%;\n  box-shadow: 0 0.3vh 0.25vh rgba(0, 0, 0, 0.25);\n  color: #FFFFFF;\n}\n.container__selected .selected-wrapper {\n  opacity: 1;\n  transition: 0.3s;\n}\n.container .image {\n  -o-object-fit: cover;\n     object-fit: cover;\n  width: 100%;\n  height: 100%;\n}\n.container .image__active {\n  opacity: 1;\n  transition: 0.5s;\n}\n.container .image__disable {\n  opacity: 0;\n  transition: 0.5s;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJlZmF2b3JpdGVzLWl0ZW0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7QUFDRjtBQUNFO0VBQ0UsVUFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUNBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUFDSjtBQUVFO0VBQ0UsWUFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSw4Q0FBQTtFQUNBLGNBQUE7QUFBSjtBQUlJO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0FBRk47QUFNRTtFQUNFLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUpKO0FBTUk7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7QUFKTjtBQU9JO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0FBTE4iLCJmaWxlIjoicGFnZS1wcmVmYXZvcml0ZXMtaXRlbS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICB3aWR0aDogaW5oZXJpdDtcbiAgaGVpZ2h0OiBpbmhlcml0O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBiYWNrZ3JvdW5kOiAjRENFMEVCO1xuICBib3JkZXItcmFkaXVzOiAzLjJ2dztcblxuICAuc2VsZWN0ZWQtd3JhcHBlciB7XG4gICAgb3BhY2l0eTogMDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgYmFja2dyb3VuZDogcmdiYSgjMkYzNDQxLCAuNSk7XG4gICAgei1pbmRleDogMTtcbiAgICB0cmFuc2l0aW9uOiAuM3M7XG4gIH1cblxuICAuc2VsZWN0ZWQtY2lyY2xlIHtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgcGFkZGluZzogLjR2aDtcbiAgICB3aWR0aDogMi41dmg7XG4gICAgaGVpZ2h0OiAyLjV2aDtcbiAgICBiYWNrZ3JvdW5kOiAjNDVCRjc4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBib3gtc2hhZG93OiAwIDAuM3ZoIDAuMjV2aCByZ2JhKDAsIDAsIDAsIDAuMjUpO1xuICAgIGNvbG9yOiAjRkZGRkZGO1xuICB9XG5cbiAgJl9fc2VsZWN0ZWQge1xuICAgIC5zZWxlY3RlZC13cmFwcGVyIHtcbiAgICAgIG9wYWNpdHk6IDE7XG4gICAgICB0cmFuc2l0aW9uOiAuM3M7XG4gICAgfVxuICB9XG5cbiAgLmltYWdlIHtcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG5cbiAgICAmX19hY3RpdmUge1xuICAgICAgb3BhY2l0eTogMTtcbiAgICAgIHRyYW5zaXRpb246LjVzO1xuICAgIH1cblxuICAgICZfX2Rpc2FibGUge1xuICAgICAgb3BhY2l0eTogMDtcbiAgICAgIHRyYW5zaXRpb246IC41cztcbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "JJls":
/*!***********************************************************!*\
  !*** ./src/app/@shared/functions/base64-file.function.ts ***!
  \***********************************************************/
/*! exports provided: dataURLtoFile, urlToDataUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dataURLtoFile", function() { return dataURLtoFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "urlToDataUrl", function() { return urlToDataUrl; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");

function dataURLtoFile(dataUrl, filename = 'default') {
    const arr = dataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
}
function urlToDataUrl(imageUrl) {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
        const proxy = 'https://api.codetabs.com/v1/proxy?quest=';
        let res;
        try {
            res = yield fetch(imageUrl);
        }
        catch (e) {
            res = yield fetch(proxy + imageUrl);
        }
        const blob = yield res.blob();
        console.log(res);
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                resolve(reader.result);
            };
            reader.readAsDataURL(blob);
        });
    });
}


/***/ }),

/***/ "LZbA":
/*!*********************************************************************!*\
  !*** ./src/app/pages/page-prefavorites/page-prefavorites.module.ts ***!
  \*********************************************************************/
/*! exports provided: PagePrefavoritesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagePrefavoritesModule", function() { return PagePrefavoritesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _page_prefavorites_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-prefavorites.component */ "yWQA");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _components_page_prefavorites_item_page_prefavorites_item_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/page-prefavorites-item/page-prefavorites-item.component */ "1ZGv");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../@shared/shared.module */ "pk6O");







let PagePrefavoritesModule = class PagePrefavoritesModule {
};
PagePrefavoritesModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_prefavorites_component__WEBPACK_IMPORTED_MODULE_3__["PagePrefavoritesComponent"], _components_page_prefavorites_item_page_prefavorites_item_component__WEBPACK_IMPORTED_MODULE_5__["PagePrefavoritesItemComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__["SharedModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{ path: '', component: _page_prefavorites_component__WEBPACK_IMPORTED_MODULE_3__["PagePrefavoritesComponent"] }]),
        ]
    })
], PagePrefavoritesModule);



/***/ }),

/***/ "QJbL":
/*!*******************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-prefavorites/components/page-prefavorites-item/page-prefavorites-item.component.html ***!
  \*******************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container ion-activatable ripple-parent\" [class.container__selected]=\"isSelected\">\n  <ion-ripple-effect></ion-ripple-effect>\n  <div class=\"selected-wrapper\">\n    <div class=\"selected-circle\">\n      <svg-icon src=\"assets/icon/svg/check.svg\"></svg-icon>\n    </div>\n  </div>\n  <img class=\"image\" [ngClass]=\"'image__' + (!!image ? 'active' : 'disable')\" alt=\"\" [src]=\"image | safeUrl\">\n</div>\n");

/***/ }),

/***/ "Ym/p":
/*!**************************************************************************!*\
  !*** ./src/app/pages/page-prefavorites/page-prefavorites.component.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  flex-flow: column;\n  width: 100%;\n  height: 100%;\n  gap: 1.97vh;\n  padding: 0 4.27vw;\n  box-sizing: border-box;\n  overflow-y: scroll;\n  background: white;\n}\n.container .header {\n  font-size: 2.71vh;\n  font-weight: 700;\n  color: #222222;\n  margin-top: 2.46vh;\n}\n.container .subheader {\n  font-size: 1.9vh;\n  font-weight: 400;\n  color: #222222;\n}\n.container .content-wrapper {\n  display: flex;\n  flex-wrap: wrap;\n  row-gap: 4vw;\n  -moz-column-gap: 4vw;\n       column-gap: 4vw;\n}\n.container .content-wrapper .item {\n  width: 27.6vw;\n  height: 34.13vw;\n}\n.container .content-wrapper .item:last-child {\n  margin-bottom: calc(6.28vh + 6.27vw + 4.27vw);\n}\n.container .button-container {\n  position: absolute;\n  width: 100%;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  padding: 4.27vw 4.27vw 6.27vw 4.27vw;\n  box-sizing: border-box;\n  -webkit-backdrop-filter: blur(40px);\n          backdrop-filter: blur(40px);\n  z-index: 1;\n}\n.container .button-container app-shared-button {\n  width: 100%;\n  opacity: 1;\n  transition: 0.3s;\n}\n.container .button-container__unactive app-shared-button {\n  opacity: 0.5;\n  transition: 0.3s;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BhZ2UtcHJlZmF2b3JpdGVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFDRjtBQUNFO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUNKO0FBRUU7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUFKO0FBR0U7RUFDRSxhQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtPQUFBLGVBQUE7QUFESjtBQUdJO0VBQ0UsYUFBQTtFQUNBLGVBQUE7QUFETjtBQUdNO0VBQ0UsNkNBQUE7QUFEUjtBQU1FO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0Esb0NBQUE7RUFDQSxzQkFBQTtFQUNBLG1DQUFBO1VBQUEsMkJBQUE7RUFDQSxVQUFBO0FBSko7QUFNSTtFQUNFLFdBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUFKTjtBQVFNO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0FBTlIiLCJmaWxlIjoicGFnZS1wcmVmYXZvcml0ZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGdhcDogMS45N3ZoO1xuICBwYWRkaW5nOiAwIDQuMjd2dztcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcblxuICAuaGVhZGVyIHtcbiAgICBmb250LXNpemU6IDIuNzF2aDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGNvbG9yOiAjMjIyMjIyO1xuICAgIG1hcmdpbi10b3A6IDIuNDZ2aDtcbiAgfVxuXG4gIC5zdWJoZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogMS45dmg7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgfVxuXG4gIC5jb250ZW50LXdyYXBwZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC13cmFwOiB3cmFwO1xuICAgIHJvdy1nYXA6IDR2dztcbiAgICBjb2x1bW4tZ2FwOiA0dnc7XG5cbiAgICAuaXRlbSB7XG4gICAgICB3aWR0aDogMjcuNnZ3O1xuICAgICAgaGVpZ2h0OiAzNC4xM3Z3O1xuXG4gICAgICAmOmxhc3QtY2hpbGQge1xuICAgICAgICBtYXJnaW4tYm90dG9tOiBjYWxjKDYuMjh2aCArIDYuMjd2dyArIDQuMjd2dyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLmJ1dHRvbi1jb250YWluZXIge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBib3R0b206IDA7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICBwYWRkaW5nOiA0LjI3dncgNC4yN3Z3IDYuMjd2dyA0LjI3dnc7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNDBweCk7XG4gICAgei1pbmRleDogMTtcblxuICAgIGFwcC1zaGFyZWQtYnV0dG9uIHtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgb3BhY2l0eTogMTtcbiAgICAgIHRyYW5zaXRpb246IC4zcztcbiAgICB9XG5cbiAgICAmX191bmFjdGl2ZSB7XG4gICAgICBhcHAtc2hhcmVkLWJ1dHRvbiB7XG4gICAgICAgIG9wYWNpdHk6IC41O1xuICAgICAgICB0cmFuc2l0aW9uOiAuM3M7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "dLP4":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/page-prefavorites/classes/page-prefavorites-item-group.class.ts ***!
  \***************************************************************************************/
/*! exports provided: PagePrefavoritesItemGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagePrefavoritesItemGroup", function() { return PagePrefavoritesItemGroup; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");


class PagePrefavoritesItemGroup {
    // get result(): IStartScreenReco[] {
    // }
    constructor(items) {
        this.verifyCount = 3;
        this.items$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"]([]);
        this.itemsObserver$ = this.items$;
        this.isValid$ = this.items$.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(x => { var _a; return ((_a = x.filter(i => i.isSelected)) === null || _a === void 0 ? void 0 : _a.length) >= this.verifyCount; }));
        this.initItems = items;
        this.items = items.map(x => (Object.assign(Object.assign({}, x), { file: `data:image/png;base64, ${x.file}`, isSelected: false })));
    }
    get items() {
        var _a;
        return (_a = this.items$.getValue()) !== null && _a !== void 0 ? _a : [];
    }
    set items(value) {
        value = (value === null || value === void 0 ? void 0 : value.length) ? value : [];
        this.items$.next(value);
    }
    get activeItems() {
        var _a, _b;
        return (_b = (_a = this.items) === null || _a === void 0 ? void 0 : _a.filter(x => !!x.isSelected)) !== null && _b !== void 0 ? _b : [];
    }
    get isValid() {
        var _a;
        return ((_a = this.items.filter(i => i.isSelected)) === null || _a === void 0 ? void 0 : _a.length) >= this.verifyCount;
    }
    select(item) {
        item.isSelected = !item.isSelected;
        this.items = [...this.items];
    }
}


/***/ }),

/***/ "p0lb":
/*!***************************************************************!*\
  !*** ./src/app/@core/services/api/api-recognition.service.ts ***!
  \***************************************************************/
/*! exports provided: ApiRecognitionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiRecognitionService", function() { return ApiRecognitionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../platform/app-config.service */ "ophu");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../@shared/functions/base64-file.function */ "JJls");





let ApiRecognitionService = class ApiRecognitionService {
    constructor(appConfigService, http) {
        this.http = http;
        this.restUrl = appConfigService.recognitionUrl;
    }
    getMainRecommends() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                const url = `${this.restUrl}/api/MainScreen/feeds`;
                return yield this.http.get(url).toPromise();
            }
            catch (e) {
                console.error('getMainRecommends', e);
                return [];
            }
        });
    }
    getStartScreenReco(gender) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/StartScreenReco?gender=${gender}`).toPromise();
            }
            catch (e) {
                console.error('getStartScreenReco', e);
                return [];
            }
        });
    }
    searchByPhoto(dataUrl) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const imgFile = Object(_shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_4__["dataURLtoFile"])(dataUrl);
            const body = new FormData();
            body.append('imageFile', imgFile, imgFile.name);
            try {
                return yield this.http.post(`${this.restUrl}/api/Reco`, body).toPromise();
            }
            catch (e) {
                console.error('searchByPhoto', e);
                return null;
            }
        });
    }
    searchByDot(searchId, dot) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.post(`${this.restUrl}/api/Reco/search/${searchId}`, dot).toPromise();
            }
            catch (e) {
                console.error('searchByDot', e);
                return null;
            }
        });
    }
    searchByText(search) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/Text?query=${search}`).toPromise();
            }
            catch (e) {
                console.error('searchByText', e);
                return null;
            }
        });
    }
    getFullItem(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                const url = `${this.restUrl} /api/Reco/feed/${id}`;
                return yield this.http.get(`${this.restUrl}/api/Reco/feed/${id}`).toPromise();
            }
            catch (e) {
                console.error('getFullItem', e);
                return null;
            }
        });
    }
};
ApiRecognitionService.ctorParameters = () => [
    { type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
ApiRecognitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApiRecognitionService);



/***/ }),

/***/ "yWQA":
/*!************************************************************************!*\
  !*** ./src/app/pages/page-prefavorites/page-prefavorites.component.ts ***!
  \************************************************************************/
/*! exports provided: PagePrefavoritesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagePrefavoritesComponent", function() { return PagePrefavoritesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_prefavorites_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-prefavorites.component.html */ "8/1j");
/* harmony import */ var _page_prefavorites_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-prefavorites.component.scss */ "Ym/p");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _classes_page_prefavorites_item_group_class__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./classes/page-prefavorites-item-group.class */ "dLP4");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../@core/services/user-info.service */ "tTdR");
/* harmony import */ var _core_services_api_api_file_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../@core/services/api/api-file.service */ "0SLh");










let PagePrefavoritesComponent = class PagePrefavoritesComponent {
    constructor(navCtrl, userInfoService, recognitionInfoService, apiFileService) {
        this.navCtrl = navCtrl;
        this.userInfoService = userInfoService;
        this.recognitionInfoService = recognitionInfoService;
        this.apiFileService = apiFileService;
        this.nextRouteUrl = '/main';
        this.isLoad$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["BehaviorSubject"](true);
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const items = yield this.recognitionInfoService.getStartReco();
            items.forEach(x => x.imageUrl = this.apiFileService.getStartRecoPhotoById(x.id));
            this.itemsGroup = new _classes_page_prefavorites_item_group_class__WEBPACK_IMPORTED_MODULE_4__["PagePrefavoritesItemGroup"](items);
            this.isLoad$.next(false);
        });
    }
    continue() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!this.itemsGroup.isValid) {
                return;
            }
            this.userInfoService.selectedPreFavourites = this.itemsGroup.activeItems.map(x => ({ id: x.id }));
            yield this.navCtrl.navigateRoot(this.nextRouteUrl);
        });
    }
};
PagePrefavoritesComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_8__["UserInfoService"] },
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_6__["RecognitionInfoService"] },
    { type: _core_services_api_api_file_service__WEBPACK_IMPORTED_MODULE_9__["ApiFileService"] }
];
PagePrefavoritesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-prefavorites',
        template: _raw_loader_page_prefavorites_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_prefavorites_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PagePrefavoritesComponent);



/***/ })

}]);
//# sourceMappingURL=pages-page-prefavorites-page-prefavorites-module-es2015.js.map