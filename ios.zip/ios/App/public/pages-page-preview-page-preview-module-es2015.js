(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-page-preview-page-preview-module"],{

/***/ "+Q2S":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/page-preview/page-preview-pager/page-preview-pager.component.ts ***!
  \***************************************************************************************/
/*! exports provided: PagePreviewPagerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagePreviewPagerComponent", function() { return PagePreviewPagerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_preview_pager_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-preview-pager.component.html */ "808N");
/* harmony import */ var _page_preview_pager_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-preview-pager.component.scss */ "ytbZ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PagePreviewPagerComponent = class PagePreviewPagerComponent {
    constructor() {
        this.data = [];
    }
    ngOnInit() {
    }
};
PagePreviewPagerComponent.ctorParameters = () => [];
PagePreviewPagerComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PagePreviewPagerComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-preview-pager',
        template: _raw_loader_page_preview_pager_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_preview_pager_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PagePreviewPagerComponent);



/***/ }),

/***/ "1XnR":
/*!***********************************************************!*\
  !*** ./src/app/pages/page-preview/page-preview.module.ts ***!
  \***********************************************************/
/*! exports provided: PagePreviewModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagePreviewModule", function() { return PagePreviewModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _page_preview_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-preview.component */ "oLnM");
/* harmony import */ var _page_preview_card_page_preview_card_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./page-preview-card/page-preview-card.component */ "CzLr");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../@shared/shared.module */ "pk6O");
/* harmony import */ var _page_preview_pager_page_preview_pager_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./page-preview-pager/page-preview-pager.component */ "+Q2S");








let PagePreviewModule = class PagePreviewModule {
};
PagePreviewModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_preview_component__WEBPACK_IMPORTED_MODULE_4__["PagePreviewComponent"], _page_preview_card_page_preview_card_component__WEBPACK_IMPORTED_MODULE_5__["PagePreviewCardComponent"], _page_preview_pager_page_preview_pager_component__WEBPACK_IMPORTED_MODULE_7__["PagePreviewPagerComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__["SharedModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild([{ path: '', component: _page_preview_component__WEBPACK_IMPORTED_MODULE_4__["PagePreviewComponent"] }]),
        ]
    })
], PagePreviewModule);



/***/ }),

/***/ "808N":
/*!*******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-preview/page-preview-pager/page-preview-pager.component.html ***!
  \*******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"preview-pager-container\">\n  <ng-container *ngFor=\"let circle of data\">\n    <div class=\"circle\" [class.circle__active]=\"circle.isActive\"></div>\n  </ng-container>\n</div>\n");

/***/ }),

/***/ "AUoC":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-preview/page-preview.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"logo-wrapper\">\n    <div class=\"logo\">\n      <svg-icon class=\"logo__icon\" src=\"assets/icon/svg/luc-logo.svg\"></svg-icon>\n    </div>\n  </div>\n  <div style=\"flex-grow: 1\"></div>\n  <div class=\"slides-container\">\n    <ion-slides (ionSlidesDidLoad)=\"slideDetectChange()\" (ionSlideDidChange)=\"slideDetectChange()\" #ionSlides>\n      <ng-container *ngFor=\"let card of cards | async\">\n        <ion-slide>\n          <app-page-preview-card [data]=\"card\"></app-page-preview-card>\n        </ion-slide>\n      </ng-container>\n    </ion-slides>\n  </div>\n  <app-page-preview-pager [data]=\"cards | async\"></app-page-preview-pager>\n  <div style=\"flex-grow: 1\"></div>\n  <app-shared-button type=\"alternative-sub\" style=\"width: 100%\" (click)=\"clickNext()\">\n    {{ !((cards | async)[(cards | async).length - 1]).isActive ? 'Далее' : 'Начать' }}\n  </app-shared-button>\n</div>\n");

/***/ }),

/***/ "CzLr":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/page-preview/page-preview-card/page-preview-card.component.ts ***!
  \*************************************************************************************/
/*! exports provided: PagePreviewCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagePreviewCardComponent", function() { return PagePreviewCardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_preview_card_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-preview-card.component.html */ "FHEz");
/* harmony import */ var _page_preview_card_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-preview-card.component.scss */ "xICm");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PagePreviewCardComponent = class PagePreviewCardComponent {
    constructor() {
        this.data = null;
    }
    ngOnInit() {
    }
};
PagePreviewCardComponent.ctorParameters = () => [];
PagePreviewCardComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PagePreviewCardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-preview-card',
        template: _raw_loader_page_preview_card_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_preview_card_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PagePreviewCardComponent);



/***/ }),

/***/ "FHEz":
/*!*****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-preview/page-preview-card/page-preview-card.component.html ***!
  \*****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--<div class=\"image-wrapper\"></div>-->\n<!--<div class=\"title-wrapper\">-->\n<!--  <p>{{data.title}}</p>-->\n<!--</div>-->\n<!--<div class=\"description-wrapper\">-->\n<!--  <p>{{data.description}}</p>-->\n<!--</div>-->\n\n<div class=\"container\">\n  <div class=\"title-wrapper\">\n    <p>{{data.title}}</p>\n  </div>\n  <div class=\"description-wrapper\">\n    <p>{{data.description}}</p>\n  </div>\n</div>\n");

/***/ }),

/***/ "QOJZ":
/*!****************************************************************!*\
  !*** ./src/app/pages/page-preview/page-preview.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  padding: 3.7vh 5.33vw 20px 5.33vw;\n  box-sizing: border-box;\n  background: white;\n}\n\n.logo-wrapper {\n  display: flex;\n}\n\n.logo-wrapper .logo {\n  margin: auto;\n  height: 2.46vh;\n  width: 7.39vh;\n}\n\n.logo-wrapper .logo__icon {\n  color: #2CB172;\n  width: 100%;\n  height: 100%;\n}\n\n.slides-container {\n  width: 100vw;\n  margin: -5.33vw;\n}\n\nion-slide {\n  width: 100%;\n  padding: 0 5.33vw;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BhZ2UtcHJldmlldy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsaUNBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0FBREY7O0FBSUE7RUFDRSxhQUFBO0FBREY7O0FBR0U7RUFDRSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7QUFESjs7QUFHSTtFQUNFLGNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUROOztBQU1BO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUFIRjs7QUFNQTtFQUNFLFdBQUE7RUFDQSxpQkFBQTtBQUhGIiwiZmlsZSI6InBhZ2UtcHJldmlldy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiRwYWRkaW5nLXc6IDUuMzN2dztcblxuLmNvbnRhaW5lciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBwYWRkaW5nOiAzLjd2aCAkcGFkZGluZy13IDIwcHggJHBhZGRpbmctdztcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5sb2dvLXdyYXBwZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuXG4gIC5sb2dvIHtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgaGVpZ2h0OiAyLjQ2dmg7XG4gICAgd2lkdGg6IDcuMzl2aDtcblxuICAgICZfX2ljb24ge1xuICAgICAgY29sb3I6ICMyQ0IxNzI7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICB9XG4gIH1cbn1cblxuLnNsaWRlcy1jb250YWluZXIge1xuICB3aWR0aDogMTAwdnc7XG4gIG1hcmdpbjogMCAtJHBhZGRpbmctdztcbn1cblxuaW9uLXNsaWRlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDAgJHBhZGRpbmctdztcbn1cbiJdfQ== */");

/***/ }),

/***/ "oLnM":
/*!**************************************************************!*\
  !*** ./src/app/pages/page-preview/page-preview.component.ts ***!
  \**************************************************************/
/*! exports provided: PagePreviewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagePreviewComponent", function() { return PagePreviewComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_preview_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-preview.component.html */ "AUoC");
/* harmony import */ var _page_preview_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-preview.component.scss */ "QOJZ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _page_preview_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-preview.data */ "v5fu");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "qCKp");







let PagePreviewComponent = class PagePreviewComponent {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
        this.cards$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"](_page_preview_data__WEBPACK_IMPORTED_MODULE_4__["CARDS_SOURCE"]);
        this.cards = this.cards$.asObservable();
        this.nextRouteUrl = '/user_init';
    }
    ngOnInit() { }
    slideDetectChange() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const currentIdx = yield this.ionSlide.getActiveIndex();
            const tmpCards = this.cards$.getValue();
            tmpCards.forEach((el, idx) => {
                if (idx === currentIdx) {
                    el.isActive = true;
                    return;
                }
                el.isActive = false;
            });
            this.cards$.next(tmpCards);
        });
    }
    clickNext() {
        var _a, _b;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if ((_b = (_a = this.cards$.getValue()) === null || _a === void 0 ? void 0 : _a.slice(-1)[0]) === null || _b === void 0 ? void 0 : _b.isActive) {
                yield this.routeNext();
            }
            else {
                yield this.slideNext();
            }
        });
    }
    slideNext() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.ionSlide.slideNext();
        });
    }
    routeNext() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.navCtrl.navigateRoot(this.nextRouteUrl);
        });
    }
};
PagePreviewComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] }
];
PagePreviewComponent.propDecorators = {
    ionSlide: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['ionSlides',] }]
};
PagePreviewComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-preview',
        template: _raw_loader_page_preview_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_preview_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PagePreviewComponent);



/***/ }),

/***/ "v5fu":
/*!*********************************************************!*\
  !*** ./src/app/pages/page-preview/page-preview.data.ts ***!
  \*********************************************************/
/*! exports provided: CARDS_SOURCE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CARDS_SOURCE", function() { return CARDS_SOURCE; });
const CARDS_SOURCE = [
    {
        img: 'img1',
        title: 'Фотографируй',
        description: 'Благодаря умному поиску по фото ты с легкостью найдешь любимые модели среди множества брендов'
    },
    {
        img: 'img2',
        title: 'Пиши и находи',
        description: 'LUC прочитает твои мысли и подберет одежду в один клик',
    },
    {
        img: 'img3',
        title: 'Будь в тренде',
        description: 'Вдохновляйся луками популярных брендов и следи за модными образами знаменитостей',
    },
    {
        img: 'img4',
        title: 'Найди свой стиль',
        description: 'С помощью модных подборок LUC ты с легкостью найдешь свой неповторимый стиль',
    },
];


/***/ }),

/***/ "xICm":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/page-preview/page-preview-card/page-preview-card.component.scss ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".image-wrapper {\n  width: 26vh;\n  height: 26vh;\n  background: #EAEDF5;\n  border-radius: 50%;\n  margin: auto auto 11vh;\n}\n\n.container {\n  height: 60vh;\n  display: flex;\n  flex-flow: column;\n  justify-content: center;\n}\n\n.title-wrapper {\n  font-size: 2.7vh;\n  font-weight: 700;\n  color: #202D3D;\n}\n\n.description-wrapper {\n  font-size: 1.9vh;\n  color: #6B7683;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJldmlldy1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFDRjs7QUFHQTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQUFGIiwiZmlsZSI6InBhZ2UtcHJldmlldy1jYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmltYWdlLXdyYXBwZXIge1xuICB3aWR0aDogMjZ2aDtcbiAgaGVpZ2h0OiAyNnZoO1xuICBiYWNrZ3JvdW5kOiAjRUFFREY1O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIG1hcmdpbjogYXV0byBhdXRvIDExdmg7XG59XG5cbi5jb250YWluZXIge1xuICBoZWlnaHQ6IDYwdmg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLnRpdGxlLXdyYXBwZXIge1xuICBmb250LXNpemU6IDIuN3ZoO1xuICBmb250LXdlaWdodDogNzAwO1xuICBjb2xvcjogIzIwMkQzRDtcbiAgLy9tYXJnaW4tYm90dG9tOiAyLjh2aDtcbn1cblxuLmRlc2NyaXB0aW9uLXdyYXBwZXIge1xuICBmb250LXNpemU6IDEuOXZoO1xuICBjb2xvcjogIzZCNzY4Mztcbn1cbiJdfQ== */");

/***/ }),

/***/ "ytbZ":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/page-preview/page-preview-pager/page-preview-pager.component.scss ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".preview-pager-container {\n  display: flex;\n  justify-content: center;\n  gap: 1.07vw;\n  margin: 3vh 0 0 0;\n}\n.preview-pager-container .circle {\n  width: 4.27vw;\n  height: 0.8vw;\n  border-radius: 2.1vw;\n  background: #EAEDF5;\n  transition: 0.3s;\n}\n.preview-pager-container .circle__active {\n  background: #2CB172;\n  transition: 0.3s;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtcHJldmlldy1wYWdlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBQUNGO0FBQ0U7RUFDRSxhQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUNKO0FBQ0k7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0FBQ04iLCJmaWxlIjoicGFnZS1wcmV2aWV3LXBhZ2VyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnByZXZpZXctcGFnZXItY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGdhcDogMS4wN3Z3O1xuICBtYXJnaW46IDN2aCAwIDAgMDtcblxuICAuY2lyY2xlIHtcbiAgICB3aWR0aDogNC4yN3Z3O1xuICAgIGhlaWdodDogMC44dnc7XG4gICAgYm9yZGVyLXJhZGl1czogMi4xdnc7XG4gICAgYmFja2dyb3VuZDogI0VBRURGNTtcbiAgICB0cmFuc2l0aW9uOiAuM3M7XG5cbiAgICAmX19hY3RpdmUge1xuICAgICAgYmFja2dyb3VuZDogIzJDQjE3MjtcbiAgICAgIHRyYW5zaXRpb246IC4zcztcbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=pages-page-preview-page-preview-module-es2015.js.map