(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-page-tabs-page-tabs-module"],{

/***/ "0lsC":
/*!**********************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  flex-flow: column;\n  height: 100%;\n  background: white;\n}\n.container .page-wrapper {\n  position: relative;\n  width: 100%;\n  flex-grow: 1;\n}\n.container .footer {\n  width: 100%;\n  height: 7vh;\n  background: #F3F7FA;\n  display: flex;\n  justify-content: space-evenly;\n}\n.tab-icon {\n  margin: auto 0;\n  color: #ACB6C3;\n  transition: 0.2s;\n  width: 2.28vh;\n  height: 2.28vh;\n}\n.tab-icon__active {\n  color: #2CB172;\n  transition: 0.2s;\n}\nion-spinner {\n  margin: auto;\n  --color: #2CB172;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BhZ2UtdGFicy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQUNGO0FBQ0U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQ0o7QUFFRTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7QUFBSjtBQUlBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0FBREY7QUFHRTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtBQURKO0FBS0E7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7QUFGRiIsImZpbGUiOiJwYWdlLXRhYnMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG5cbiAgLnBhZ2Utd3JhcHBlciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgfVxuXG4gIC5mb290ZXIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogN3ZoO1xuICAgIGJhY2tncm91bmQ6ICNGM0Y3RkE7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcbiAgfVxufVxuXG4udGFiLWljb24ge1xuICBtYXJnaW46IGF1dG8gMDtcbiAgY29sb3I6ICNBQ0I2QzM7XG4gIHRyYW5zaXRpb246IC4ycztcbiAgd2lkdGg6IDIuMjh2aDtcbiAgaGVpZ2h0OiAyLjI4dmg7XG5cbiAgJl9fYWN0aXZlIHtcbiAgICBjb2xvcjogIzJDQjE3MjtcbiAgICB0cmFuc2l0aW9uOiAuMnM7XG4gIH1cbn1cblxuaW9uLXNwaW5uZXIge1xuICBtYXJnaW46IGF1dG87XG4gIC0tY29sb3I6ICMyQ0IxNzI7XG59XG4iXX0= */");

/***/ }),

/***/ "27Lq":
/*!*************************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: PageTabsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsRoutingModule", function() { return PageTabsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _page_tabs_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-tabs.component */ "SDmg");




const routes = [
    {
        path: '',
        redirectTo: 'main',
        pathMatch: 'full',
    },
    {
        path: '',
        component: _page_tabs_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsComponent"],
        children: [
            {
                path: 'main',
                loadChildren: () => Promise.all(/*! import() | page-tabs-main-page-tabs-main-module */[__webpack_require__.e("default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee"), __webpack_require__.e("page-tabs-main-page-tabs-main-module")]).then(__webpack_require__.bind(null, /*! ./page-tabs-main/page-tabs-main.module */ "sY6W")).then(m => m.PageTabsMainModule)
            },
            {
                path: 'tinder',
                loadChildren: () => Promise.all(/*! import() | page-tabs-tinder-page-tabs-tinder-module */[__webpack_require__.e("default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee"), __webpack_require__.e("common"), __webpack_require__.e("page-tabs-tinder-page-tabs-tinder-module")]).then(__webpack_require__.bind(null, /*! ./page-tabs-tinder/page-tabs-tinder.module */ "KNm0")).then(m => m.PageTabsTinderModule)
            },
            {
                path: 'favorites',
                loadChildren: () => Promise.all(/*! import() | page-tabs-favorites-page-tabs-favorites-module */[__webpack_require__.e("default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee"), __webpack_require__.e("page-tabs-favorites-page-tabs-favorites-module")]).then(__webpack_require__.bind(null, /*! ./page-tabs-favorites/page-tabs-favorites.module */ "dhg9")).then(m => m.PageTabsFavoritesModule)
            },
            {
                path: 'user',
                loadChildren: () => Promise.all(/*! import() | page-tabs-user-page-tabs-user-module */[__webpack_require__.e("common"), __webpack_require__.e("page-tabs-user-page-tabs-user-module")]).then(__webpack_require__.bind(null, /*! ./page-tabs-user/page-tabs-user.module */ "BTHi")).then(m => m.PageTabsUserModule)
            },
        ]
    },
    {
        path: '**',
        redirectTo: 'main',
        pathMatch: 'full',
    }
];
let PageTabsRoutingModule = class PageTabsRoutingModule {
};
PageTabsRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], PageTabsRoutingModule);



/***/ }),

/***/ "SDmg":
/*!********************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs.component.ts ***!
  \********************************************************/
/*! exports provided: PageTabsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsComponent", function() { return PageTabsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_tabs_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-tabs.component.html */ "W+mR");
/* harmony import */ var _page_tabs_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-tabs.component.scss */ "0lsC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../@core/services/user-info.service */ "tTdR");







let PageTabsComponent = class PageTabsComponent {
    constructor(navCtrl, userInfoService) {
        this.navCtrl = navCtrl;
        this.userInfoService = userInfoService;
        this.tabs = ['search', 'blocks', 'like', 'user'];
        this.tabsRouting = {
            search: 'main/tabs/main',
            blocks: 'main/tabs/tinder',
            like: 'main/tabs/favorites',
            user: 'main/tabs/user',
        };
        this.currentTab$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"]('search');
        this.isActive$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"](false);
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.userInfoService.init();
            this.isActive$.next(true);
        });
    }
    selectTab(tab) {
        var _a;
        this.navCtrl.navigateRoot((_a = this.tabsRouting[tab]) !== null && _a !== void 0 ? _a : this.tabsRouting[this.currentTab$.value]).then();
    }
    routing(event) {
        this.currentTab$.next(event === null || event === void 0 ? void 0 : event.tabName);
    }
};
PageTabsComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_6__["UserInfoService"] }
];
PageTabsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs',
        template: _raw_loader_page_tabs_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_tabs_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageTabsComponent);



/***/ }),

/***/ "W+mR":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <ng-container *ngIf=\"isActive$ | async; else loader\">\n    <ion-router-outlet  (activate)=\"routing($event)\" class=\"page-wrapper\"></ion-router-outlet>\n    <div class=\"footer\">\n      <svg-icon *ngFor=\"let tab of tabs\"\n                class=\"tab-icon\"\n                [class.tab-icon__active]=\"tab === (currentTab$ | async)\"\n                (click)=\"selectTab(tab)\"\n                src=\"assets/icon/svg/tabs/{{tab}}.svg\">\n      </svg-icon>\n    </div>\n  </ng-container>\n  <ng-template #loader>\n    <ion-spinner name=\"dots\"></ion-spinner>\n  </ng-template>\n</div>\n");

/***/ }),

/***/ "ja1/":
/*!*****************************************************!*\
  !*** ./src/app/pages/page-tabs/page-tabs.module.ts ***!
  \*****************************************************/
/*! exports provided: PageTabsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTabsModule", function() { return PageTabsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _page_tabs_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-tabs-routing.module */ "27Lq");
/* harmony import */ var _page_tabs_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-tabs.component */ "SDmg");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../@shared/shared.module */ "pk6O");






let PageTabsModule = class PageTabsModule {
};
PageTabsModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_tabs_component__WEBPACK_IMPORTED_MODULE_4__["PageTabsComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
            _page_tabs_routing_module__WEBPACK_IMPORTED_MODULE_3__["PageTabsRoutingModule"]
        ]
    })
], PageTabsModule);



/***/ })

}]);
//# sourceMappingURL=pages-page-tabs-page-tabs-module-es2015.js.map