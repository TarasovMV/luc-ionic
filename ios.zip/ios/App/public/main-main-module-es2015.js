(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main-main-module"],{

/***/ "3hl/":
/*!*********************************************!*\
  !*** ./src/app/main/main-routing.module.ts ***!
  \*********************************************/
/*! exports provided: MainRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainRoutingModule", function() { return MainRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");



const routes = [
    {
        path: '',
        children: [
            {
                path: 'camera',
                loadChildren: () => Promise.all(/*! import() | pages-page-camera-page-camera-module */[__webpack_require__.e("common"), __webpack_require__.e("pages-page-camera-page-camera-module")]).then(__webpack_require__.bind(null, /*! ../pages/page-camera/page-camera.module */ "XeY1")).then(m => m.PageCameraModule),
            },
            {
                path: 'scan',
                loadChildren: () => Promise.all(/*! import() | pages-page-scan-page-scan-module */[__webpack_require__.e("default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee"), __webpack_require__.e("pages-page-scan-page-scan-module")]).then(__webpack_require__.bind(null, /*! ../pages/page-scan/page-scan.module */ "c2vx")).then(m => m.PageScanModule),
            },
            {
                path: 'product',
                loadChildren: () => __webpack_require__.e(/*! import() | pages-page-product-page-product-module */ "default~page-tabs-favorites-page-tabs-favorites-module~page-tabs-main-page-tabs-main-module~page-tab~e57bd0ee").then(__webpack_require__.bind(null, /*! ../pages/page-product/page-product.module */ "A6qN")).then(m => m.PageProductModule),
            },
            {
                path: 'tabs',
                loadChildren: () => __webpack_require__.e(/*! import() | pages-page-tabs-page-tabs-module */ "pages-page-tabs-page-tabs-module").then(__webpack_require__.bind(null, /*! ../pages/page-tabs/page-tabs.module */ "ja1/")).then(m => m.PageTabsModule),
            },
            {
                path: '**',
                redirectTo: 'tabs',
                pathMatch: 'full',
            },
        ],
    },
];
let MainRoutingModule = class MainRoutingModule {
};
MainRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], MainRoutingModule);



/***/ }),

/***/ "XpXM":
/*!*************************************!*\
  !*** ./src/app/main/main.module.ts ***!
  \*************************************/
/*! exports provided: MainModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainModule", function() { return MainModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _main_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./main-routing.module */ "3hl/");




let MainModule = class MainModule {
};
MainModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _main_routing_module__WEBPACK_IMPORTED_MODULE_3__["MainRoutingModule"]
        ]
    })
], MainModule);



/***/ })

}]);
//# sourceMappingURL=main-main-module-es2015.js.map