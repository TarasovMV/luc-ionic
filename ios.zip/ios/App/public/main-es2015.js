(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/avsv/Documents/GitHub/luc-ionic/src/main.ts */"zUnb");


/***/ }),

/***/ "0SLh":
/*!********************************************************!*\
  !*** ./src/app/@core/services/api/api-file.service.ts ***!
  \********************************************************/
/*! exports provided: ApiFileService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiFileService", function() { return ApiFileService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../platform/app-config.service */ "ophu");



let ApiFileService = class ApiFileService {
    constructor(appConfigService) {
        this.restUrl = appConfigService.fileUrl;
    }
    getStartRecoPhotoById(id) {
        return `${this.restUrl}/api/Photo/start-screen-reco/${id}`;
    }
    getTinderPhotoById(id) {
        return `${this.restUrl}/api/Photo/tinder/${id}`;
    }
    getArticlePhoto(url) {
        url = url.replace('/', '%2F');
        return `${this.restUrl}/api/Photo/${url}`;
    }
};
ApiFileService.ctorParameters = () => [
    { type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"] }
];
ApiFileService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApiFileService);



/***/ }),

/***/ "3WmZ":
/*!*********************************************************!*\
  !*** ./src/app/@core/interceptors/error.interceptor.ts ***!
  \*********************************************************/
/*! exports provided: ErrorInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ErrorInterceptor", function() { return ErrorInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _services_app_token_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/app-token.service */ "gcGz");





let ErrorInterceptor = class ErrorInterceptor {
    constructor(tokenService) {
        this.tokenService = tokenService;
    }
    intercept(req, next) {
        return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])((e) => {
            var _a;
            switch (e.status) {
                case 475:
                    const token = (_a = e === null || e === void 0 ? void 0 : e.error) === null || _a === void 0 ? void 0 : _a.token;
                    if (token) {
                        this.tokenService.userToken = token;
                        return next.handle(req);
                    }
                    console.error('Error 475 (continue): Token was not received');
                    break;
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(e);
        }));
    }
};
ErrorInterceptor.ctorParameters = () => [
    { type: _services_app_token_service__WEBPACK_IMPORTED_MODULE_4__["AppTokenService"] }
];
ErrorInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ErrorInterceptor);



/***/ }),

/***/ "5XVG":
/*!************************************************!*\
  !*** ./src/app/@shared/pipes/safe-url.pipe.ts ***!
  \************************************************/
/*! exports provided: SafeUrlPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SafeUrlPipe", function() { return SafeUrlPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");



let SafeUrlPipe = class SafeUrlPipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(url) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
};
SafeUrlPipe.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] }
];
SafeUrlPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'safeUrl'
    })
], SafeUrlPipe);



/***/ }),

/***/ "7RHv":
/*!*************************************************************************************!*\
  !*** ./src/app/@shared/components/shared-form-error/shared-form-error.component.ts ***!
  \*************************************************************************************/
/*! exports provided: SharedFormErrorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFormErrorComponent", function() { return SharedFormErrorComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_form_error_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-form-error.component.html */ "9zqh");
/* harmony import */ var _shared_form_error_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-form-error.component.scss */ "mLhf");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedFormErrorComponent = class SharedFormErrorComponent {
    constructor() {
    }
    ngOnInit() {
    }
};
SharedFormErrorComponent.ctorParameters = () => [];
SharedFormErrorComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-form-error',
        template: _raw_loader_shared_form_error_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_form_error_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedFormErrorComponent);



/***/ }),

/***/ "8cGW":
/*!*******************************************************************************!*\
  !*** ./src/app/@shared/components/shared-select/shared-select.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-item {\n  --min-height: 7.5vh;\n  --padding-start: 0;\n}\n\nion-label {\n  font-size: 1.97vh !important;\n  font-weight: 500 !important;\n  color: #99A0AB !important;\n}\n\nion-select {\n  max-width: unset;\n}\n\nion-select::part(placeholder) {\n  font-size: 1.97vh !important;\n  font-weight: 500 !important;\n  color: #99A0AB !important;\n  opacity: 1 !important;\n}\n\nion-select::part(text) {\n  font-size: 1.97vh !important;\n  font-weight: 500 !important;\n  color: #222222 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1zZWxlY3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSw0QkFBQTtFQUNBLDJCQUFBO0VBQ0EseUJBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBS0U7RUFDRSw0QkFBQTtFQUNBLDJCQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtBQUhKOztBQU1FO0VBQ0UsNEJBQUE7RUFDQSwyQkFBQTtFQUNBLHlCQUFBO0FBSkoiLCJmaWxlIjoic2hhcmVkLXNlbGVjdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcbiAgLS1taW4taGVpZ2h0OiA3LjV2aDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xufVxuXG5pb24tbGFiZWwge1xuICBmb250LXNpemU6IDEuOTd2aCAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogNTAwICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjOTlBMEFCICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1zZWxlY3Qge1xuICBtYXgtd2lkdGg6IHVuc2V0O1xuXG4gICY6OnBhcnQoaWNvbikge1xuXG4gIH1cblxuICAmOjpwYXJ0KHBsYWNlaG9sZGVyKSB7XG4gICAgZm9udC1zaXplOiAxLjk3dmggIWltcG9ydGFudDtcbiAgICBmb250LXdlaWdodDogNTAwICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICM5OUEwQUIgIWltcG9ydGFudDtcbiAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XG4gIH1cblxuICAmOjpwYXJ0KHRleHQpIHtcbiAgICBmb250LXNpemU6IDEuOTd2aCAhaW1wb3J0YW50O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDAgIWltcG9ydGFudDtcbiAgICBjb2xvcjogIzIyMjIyMiAhaW1wb3J0YW50O1xuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "9jvt":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-input/shared-input.component.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-item class=\"input-container\">\n  <ion-label class=\"label\" position=\"floating\"> {{ label }} </ion-label>\n  <ion-input *ngIf=\"!formControl\" autocomplete=\"nope\" (change)=\"valueChange.emit($event.target.value)\" [value]=\"value\" class=\"input\" [type]=\"type\"></ion-input>\n  <ion-input *ngIf=\"!!formControl\" autocomplete=\"nope\" [formControl]=\"formControl\" class=\"input\" [type]=\"type\"></ion-input>\n</ion-item>\n");

/***/ }),

/***/ "9mOG":
/*!*****************************************************************************************!*\
  !*** ./src/app/@shared/components/shared-image-slider/shared-image-slider.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: SharedImageSliderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedImageSliderComponent", function() { return SharedImageSliderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_image_slider_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-image-slider.component.html */ "HeKZ");
/* harmony import */ var _shared_image_slider_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-image-slider.component.scss */ "LT+l");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");





let SharedImageSliderComponent = class SharedImageSliderComponent {
    constructor() {
        this.imagesUrl = [];
        this.counter$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](1);
    }
    ngOnInit() {
    }
    slideDetectChange() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const currentIdx = yield this.ionSlide.getActiveIndex();
            this.counter$.next(currentIdx + 1);
        });
    }
};
SharedImageSliderComponent.ctorParameters = () => [];
SharedImageSliderComponent.propDecorators = {
    ionSlide: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['ionSlides',] }],
    imagesUrl: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedImageSliderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-image-slider',
        template: _raw_loader_shared_image_slider_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_image_slider_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedImageSliderComponent);



/***/ }),

/***/ "9zqh":
/*!*****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-form-error/shared-form-error.component.html ***!
  \*****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<span> <ng-content></ng-content> </span>\n");

/***/ }),

/***/ "ACNr":
/*!*******************************************************************************!*\
  !*** ./src/app/@shared/components/shared-button/shared-button.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("button {\n  width: inherit;\n  outline: none;\n  height: 6.28vh;\n  border-radius: 1vh;\n}\n\n.main {\n  background: #2CB172;\n  color: #FFFFFF;\n}\n\n.main-sub {\n  color: #2CB172;\n  background: none;\n}\n\n.alternative {\n  background: #41485D;\n  color: #FFFFFF;\n}\n\n.alternative-sub {\n  color: #6B7683;\n  background: none;\n}\n\n.skeleton {\n  background: #DCE0EB;\n  color: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1idXR0b24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0FBQ0YiLCJmaWxlIjoic2hhcmVkLWJ1dHRvbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImJ1dHRvbiB7XG4gIHdpZHRoOiBpbmhlcml0O1xuICBvdXRsaW5lOiBub25lO1xuICBoZWlnaHQ6IDYuMjh2aDtcbiAgYm9yZGVyLXJhZGl1czogMXZoO1xufVxuXG4ubWFpbiB7XG4gIGJhY2tncm91bmQ6ICMyQ0IxNzI7XG4gIGNvbG9yOiAjRkZGRkZGO1xufVxuXG4ubWFpbi1zdWIge1xuICBjb2xvcjogIzJDQjE3MjtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuLmFsdGVybmF0aXZlIHtcbiAgYmFja2dyb3VuZDogIzQxNDg1RDtcbiAgY29sb3I6ICNGRkZGRkY7XG59XG5cbi5hbHRlcm5hdGl2ZS1zdWIge1xuICBjb2xvcjogIzZCNzY4MztcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuLnNrZWxldG9uIHtcbiAgYmFja2dyb3VuZDogI0RDRTBFQjtcbiAgY29sb3I6IHRyYW5zcGFyZW50O1xufVxuIl19 */");

/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "C1aD":
/*!******************************************************************!*\
  !*** ./src/app/@core/interceptors/authentication.interceptor.ts ***!
  \******************************************************************/
/*! exports provided: AuthenticationInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthenticationInterceptor", function() { return AuthenticationInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_app_token_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/app-token.service */ "gcGz");



let AuthenticationInterceptor = class AuthenticationInterceptor {
    constructor(tokenService) {
        this.tokenService = tokenService;
    }
    intercept(req, next) {
        req = req.clone({
            headers: req.headers.append('Authorization', `Bearer ${this.tokenService.userToken}`),
        });
        return next.handle(req);
    }
};
AuthenticationInterceptor.ctorParameters = () => [
    { type: _services_app_token_service__WEBPACK_IMPORTED_MODULE_2__["AppTokenService"] }
];
AuthenticationInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthenticationInterceptor);



/***/ }),

/***/ "CBGP":
/*!*************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-textarea/shared-textarea.component.html ***!
  \*************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-item class=\"input-container\">\n  <ion-label class=\"label\" position=\"floating\"> {{ label }} </ion-label>\n  <ion-textarea *ngIf=\"formControl\" [formControl]=\"formControl\" auto-grow></ion-textarea>\n</ion-item>\n");

/***/ }),

/***/ "DwYw":
/*!*****************************************************************************!*\
  !*** ./src/app/@shared/components/shared-button/shared-button.component.ts ***!
  \*****************************************************************************/
/*! exports provided: SharedButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedButtonComponent", function() { return SharedButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_button_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-button.component.html */ "ikas");
/* harmony import */ var _shared_button_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-button.component.scss */ "ACNr");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedButtonComponent = class SharedButtonComponent {
    constructor() {
        this.type = 'main';
    }
    ngOnInit() {
    }
};
SharedButtonComponent.ctorParameters = () => [];
SharedButtonComponent.propDecorators = {
    type: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedButtonComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-button',
        template: _raw_loader_shared_button_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_button_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedButtonComponent);



/***/ }),

/***/ "FctL":
/*!*********************************************************************************!*\
  !*** ./src/app/@shared/components/shared-textarea/shared-textarea.component.ts ***!
  \*********************************************************************************/
/*! exports provided: SharedTextareaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedTextareaComponent", function() { return SharedTextareaComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_textarea_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-textarea.component.html */ "CBGP");
/* harmony import */ var _shared_textarea_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-textarea.component.scss */ "p7KD");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedTextareaComponent = class SharedTextareaComponent {
    constructor() {
        this.label = '';
    }
    ngOnInit() {
    }
};
SharedTextareaComponent.ctorParameters = () => [];
SharedTextareaComponent.propDecorators = {
    label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    formControl: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedTextareaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-textarea',
        template: _raw_loader_shared_textarea_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_textarea_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedTextareaComponent);



/***/ }),

/***/ "HeKZ":
/*!*********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-image-slider/shared-image-slider.component.html ***!
  \*********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"wrapper\">\n  <div class=\"counter\"> {{ counter$ | async }} из {{ imagesUrl.length }} </div>\n\n  <ion-slides (ionSlideDidChange)=\"slideDetectChange()\" #ionSlides style=\"height: 100%; width: 100%\">\n    <ion-slide *ngFor=\"let img of imagesUrl\">\n      <img [src]=\"img\"/>\n    </ion-slide>\n  </ion-slides>\n</div>\n");

/***/ }),

/***/ "IHQ7":
/*!*************************************************************!*\
  !*** ./src/app/@core/services/platform/keyboard.service.ts ***!
  \*************************************************************/
/*! exports provided: KeyboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyboardService", function() { return KeyboardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ "gcOT");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");




const { Keyboard } = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"];
let KeyboardService = class KeyboardService {
    constructor() {
        this.keyboardHeight$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](0);
    }
    // TODO: add theme
    setInitSettings(platform, appWindow) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                this.actionListeners(platform, appWindow);
                yield Keyboard.setStyle({ style: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["KeyboardStyle"].Light });
                yield Keyboard.setResizeMode({ mode: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["KeyboardResize"].None });
            }
            catch (_a) { }
        });
    }
    actionListeners(platform, appWindow) {
        platform.keyboardDidShow.subscribe((event) => this.keyboardHeight$.next(event.keyboardHeight));
        platform.keyboardDidHide.subscribe(() => this.keyboardHeight$.next(0));
        this.keyboardHeight$.subscribe((height) => appWindow.el.style = `height: calc(100vh - ${height}px)`);
    }
};
KeyboardService.ctorParameters = () => [];
KeyboardService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], KeyboardService);



/***/ }),

/***/ "JGf/":
/*!**************************************************!*\
  !*** ./src/app/@core/services/logger.service.ts ***!
  \**************************************************/
/*! exports provided: LoggerService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoggerService", function() { return LoggerService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let LoggerService = class LoggerService {
    constructor() {
        this.logMessage = (message) => {
            return message;
        };
    }
    /**
     *
     * @param type
     * @param message
     */
    log(type, message) {
        const prepareMessage = this.logMessage(message);
        switch (type) {
            case 'error':
                console.error(prepareMessage);
                break;
            case 'warning':
                console.warn(prepareMessage);
                break;
            case 'info':
                console.log(prepareMessage);
                break;
        }
    }
};
LoggerService.ctorParameters = () => [];
LoggerService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], LoggerService);



/***/ }),

/***/ "KwcL":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/pwa-elements/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./pwa-action-sheet.entry.js": [
		"jDxf",
		43
	],
	"./pwa-camera-modal-instance.entry.js": [
		"37vE",
		44
	],
	"./pwa-camera-modal.entry.js": [
		"cJxf",
		45
	],
	"./pwa-camera.entry.js": [
		"eGHz",
		46
	],
	"./pwa-toast.entry.js": [
		"fHjd",
		47
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "KwcL";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "LT+l":
/*!*******************************************************************************************!*\
  !*** ./src/app/@shared/components/shared-image-slider/shared-image-slider.component.scss ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".wrapper {\n  position: relative;\n  width: 100%;\n  height: 100%;\n}\n.wrapper .counter {\n  position: absolute;\n  right: 5.3vw;\n  top: 5.3vw;\n  padding: 1vh;\n  z-index: 2;\n  font-size: 1.72vh;\n  color: #FFFFFF;\n  background: rgba(34, 34, 34, 0.65);\n  border-radius: 1vh;\n}\n.wrapper img {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1pbWFnZS1zbGlkZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQ0Y7QUFDRTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtDQUFBO0VBQ0Esa0JBQUE7QUFDSjtBQUVFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBQUoiLCJmaWxlIjoic2hhcmVkLWltYWdlLXNsaWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwcGVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuXG4gIC5jb3VudGVyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgcmlnaHQ6IDUuM3Z3O1xuICAgIHRvcDogNS4zdnc7XG4gICAgcGFkZGluZzogMXZoO1xuICAgIHotaW5kZXg6IDI7XG4gICAgZm9udC1zaXplOiAxLjcydmg7XG4gICAgY29sb3I6ICNGRkZGRkY7XG4gICAgYmFja2dyb3VuZDogcmdiYSgzNCwgMzQsIDM0LCAwLjY1KTtcbiAgICBib3JkZXItcmFkaXVzOiAxdmg7XG4gIH1cblxuICBpbWcge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./app.component.html */ "VzVu");
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.scss */ "ynWL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "54vc");
/* harmony import */ var _core_services_platform_status_bar_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./@core/services/platform/status-bar.service */ "qCjG");
/* harmony import */ var _core_services_platform_keyboard_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./@core/services/platform/keyboard.service */ "IHQ7");
/* harmony import */ var _core_services_outsource_auth_user_agent_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./@core/services/outsource-auth/user-agent.service */ "Uqa0");
/* harmony import */ var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./@core/services/user-info.service */ "tTdR");










let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBarService, keyboardService, userAgentService, userInfoService) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBarService = statusBarService;
        this.keyboardService = keyboardService;
        this.userAgentService = userAgentService;
        this.userInfoService = userInfoService;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.initializeApp();
        });
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.splashScreen.hide();
            this.statusBarService.setDefault();
            this.keyboardService.setInitSettings(this.platform, this.appWindow);
            // this.userAgentService.setUserAgent(); // TODO: not work
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"] },
    { type: _core_services_platform_status_bar_service__WEBPACK_IMPORTED_MODULE_6__["StatusBarService"] },
    { type: _core_services_platform_keyboard_service__WEBPACK_IMPORTED_MODULE_7__["KeyboardService"] },
    { type: _core_services_outsource_auth_user_agent_service__WEBPACK_IMPORTED_MODULE_8__["UserAgentService"] },
    { type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_9__["UserInfoService"] }
];
AppComponent.propDecorators = {
    appWindow: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['appWindow', { static: true },] }]
};
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AppComponent);



/***/ }),

/***/ "TtwI":
/*!*****************************************************************************!*\
  !*** ./src/app/@shared/components/shared-input/shared-input.component.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".input-container {\n  --min-height: 7.5vh;\n  --padding-start: 0;\n}\n.input-container .label {\n  margin: 0;\n  font-size: 1.97vh;\n  font-weight: 500;\n  color: #99A0AB;\n}\n.input-container .input {\n  --padding-top: 0;\n  --padding-bottom: 0;\n  font-size: 1.97vh;\n  color: #222222;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1pbnB1dC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7QUFDRjtBQUNFO0VBQ0UsU0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBQ0o7QUFFRTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFBSiIsImZpbGUiOiJzaGFyZWQtaW5wdXQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW5wdXQtY29udGFpbmVyIHtcbiAgLS1taW4taGVpZ2h0OiA3LjV2aDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuXG4gIC5sYWJlbCB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgY29sb3I6ICM5OUEwQUI7XG4gIH1cblxuICAuaW5wdXQge1xuICAgIC0tcGFkZGluZy10b3A6IDA7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMDtcbiAgICBmb250LXNpemU6IDEuOTd2aDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "URgT":
/*!*****************************************************************************!*\
  !*** ./src/app/@shared/components/shared-select/shared-select.component.ts ***!
  \*****************************************************************************/
/*! exports provided: SharedSelectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedSelectComponent", function() { return SharedSelectComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_select_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-select.component.html */ "ue9h");
/* harmony import */ var _shared_select_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-select.component.scss */ "8cGW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedSelectComponent = class SharedSelectComponent {
    constructor() {
        this.label = '';
        this.values = [];
    }
    ngOnInit() {
    }
};
SharedSelectComponent.ctorParameters = () => [];
SharedSelectComponent.propDecorators = {
    label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    formControl: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    values: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedSelectComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-select',
        template: _raw_loader_shared_select_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_select_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedSelectComponent);



/***/ }),

/***/ "Uqa0":
/*!*********************************************************************!*\
  !*** ./src/app/@core/services/outsource-auth/user-agent.service.ts ***!
  \*********************************************************************/
/*! exports provided: UserAgentService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserAgentService", function() { return UserAgentService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_native_user_agent_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/user-agent/ngx */ "poBw");



let UserAgentService = class UserAgentService {
    constructor(userAgent) {
        this.userAgent = userAgent;
    }
    setUserAgent() {
        try {
            this.userAgent.set('Mozilla/5.0 Google')
                .then((res) => console.log(res))
                .catch((error) => console.error(error));
        }
        catch (e) {
            console.error(e);
        }
    }
};
UserAgentService.ctorParameters = () => [
    { type: _ionic_native_user_agent_ngx__WEBPACK_IMPORTED_MODULE_2__["UserAgent"] }
];
UserAgentService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UserAgentService);



/***/ }),

/***/ "V5UK":
/*!**************************************!*\
  !*** ./src/app/@core/core.module.ts ***!
  \**************************************/
/*! exports provided: CoreModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreModule", function() { return CoreModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _services_platform_app_config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/platform/app-config.service */ "ophu");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _ionic_native_user_agent_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/user-agent/ngx */ "poBw");
/* harmony import */ var _interceptors_error_interceptor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./interceptors/error.interceptor */ "3WmZ");
/* harmony import */ var _interceptors_authentication_interceptor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./interceptors/authentication.interceptor */ "C1aD");
/* harmony import */ var _capacitor_community_camera_preview__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @capacitor-community/camera-preview */ "SFQQ");
/* harmony import */ var _services_app_token_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./services/app-token.service */ "gcGz");
/* harmony import */ var _ionic_native_app_rate_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/app-rate/ngx */ "k0k6");








// camera web view



let CoreModule = class CoreModule {
};
CoreModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
        ],
        providers: [
            _ionic_native_app_rate_ngx__WEBPACK_IMPORTED_MODULE_10__["AppRate"],
            _ionic_native_user_agent_ngx__WEBPACK_IMPORTED_MODULE_5__["UserAgent"],
            { provide: _angular_core__WEBPACK_IMPORTED_MODULE_1__["APP_INITIALIZER"], useFactory: appInit, deps: [_services_platform_app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"]], multi: true },
            { provide: _angular_core__WEBPACK_IMPORTED_MODULE_1__["APP_INITIALIZER"], useFactory: loadToken, deps: [_services_app_token_service__WEBPACK_IMPORTED_MODULE_9__["AppTokenService"]], multi: true },
            { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"], useClass: _interceptors_error_interceptor__WEBPACK_IMPORTED_MODULE_6__["ErrorInterceptor"], multi: true },
            { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"], useClass: _interceptors_authentication_interceptor__WEBPACK_IMPORTED_MODULE_7__["AuthenticationInterceptor"], multi: true },
        ]
    })
], CoreModule);

function appInit(appConfigService) {
    return () => appConfigService.load();
}
function loadToken(tokenService) {
    return () => tokenService.loadToken();
}


/***/ }),

/***/ "VzVu":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app #appWindow>\n  <ion-content>\n    <ion-router-outlet></ion-router-outlet>\n  </ion-content>\n</ion-app>\n");

/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "54vc");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "VYYF");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./@core/core.module */ "V5UK");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./@shared/shared.module */ "pk6O");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser/animations */ "R1ws");
/* harmony import */ var capacitor_plugin_vk_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! capacitor-plugin-vk-auth */ "M2fr");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/storage */ "e8h1");













// import {LocationStrategy} from '@angular/common';
let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__["BrowserAnimationsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"].forRoot(),
            _ionic_storage__WEBPACK_IMPORTED_MODULE_12__["IonicStorageModule"].forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
            _core_core_module__WEBPACK_IMPORTED_MODULE_8__["CoreModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_9__["SharedModule"],
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__["SplashScreen"],
            capacitor_plugin_vk_auth__WEBPACK_IMPORTED_MODULE_11__["VKAuthWeb"],
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "ZmEp":
/*!***************************************************************************************************!*\
  !*** ./src/app/@shared/components/shared-multiply-checker/shared-multiply-checker.component.scss ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".checker {\n  display: flex;\n  width: 2.43vh;\n  height: 2.43vh;\n  border: solid 0.25vh #6B7683;\n  border-radius: 0.25vh;\n  transition: 0.3s;\n}\n.checker__active {\n  background: #3A83F1;\n  border-color: #3A83F1;\n  transition: 0.3s;\n}\n.checker__icon {\n  width: 60%;\n  height: 100%;\n  margin: auto;\n  color: #ffffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1tdWx0aXBseS1jaGVja2VyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsNEJBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0FBQ0Y7QUFDRTtFQUNFLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSxnQkFBQTtBQUNKO0FBRUU7RUFDRSxVQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBQUoiLCJmaWxlIjoic2hhcmVkLW11bHRpcGx5LWNoZWNrZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2hlY2tlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiAyLjQzdmg7XG4gIGhlaWdodDogMi40M3ZoO1xuICBib3JkZXI6IHNvbGlkIDAuMjV2aCAjNkI3NjgzO1xuICBib3JkZXItcmFkaXVzOiAwLjI1dmg7XG4gIHRyYW5zaXRpb246IC4zcztcblxuICAmX19hY3RpdmUge1xuICAgIGJhY2tncm91bmQ6ICMzQTgzRjE7XG4gICAgYm9yZGVyLWNvbG9yOiAjM0E4M0YxO1xuICAgIHRyYW5zaXRpb246IC4zcztcbiAgfVxuXG4gICZfX2ljb24ge1xuICAgIHdpZHRoOiA2MCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBjb2xvcjogI2ZmZmZmZjtcbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "gcGz":
/*!*****************************************************!*\
  !*** ./src/app/@core/services/app-token.service.ts ***!
  \*****************************************************/
/*! exports provided: AppTokenService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppTokenService", function() { return AppTokenService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ "e8h1");




let AppTokenService = class AppTokenService {
    constructor(storage) {
        this.storage = storage;
        this.userAuthTokenPath = 'user-token';
        this.userAuthAnonTokenPath = 'user-token-anon';
        this.userAuthAnonToken = null;
        this.userToken$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
    }
    set userTokenAuth(value) {
        this.saveToken(value, this.userAuthTokenPath);
        this.userToken$.next(value);
    }
    set userToken(value) {
        if (!value) {
            this.clear();
            return;
        }
        let path = this.userAuthTokenPath;
        if ((!this.userAuthAnonToken && !this.userToken$.getValue()) || this.userToken$.getValue() === this.userAuthAnonToken) {
            this.userAuthAnonToken = value;
            path = this.userAuthAnonTokenPath;
        }
        this.saveToken(value, path);
        this.userToken$.next(value);
    }
    get userToken() {
        return this.userToken$.getValue();
    }
    debugClear() {
        this.storage.set(this.userAuthTokenPath, null).then();
        this.storage.set(this.userAuthAnonTokenPath, null).then();
    }
    clear() {
        this.storage.set(this.userAuthTokenPath, null).then();
        this.userToken$.next(this.userAuthAnonToken);
    }
    saveToken(token, path) {
        this.storage.set(path, token).then();
    }
    loadToken() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const anonToken = yield this.storage.get(this.userAuthAnonTokenPath);
            const token = yield this.storage.get(this.userAuthTokenPath);
            this.userAuthAnonToken = anonToken;
            this.userToken$.next(token || anonToken);
        });
    }
};
AppTokenService.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"] }
];
AppTokenService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AppTokenService);



/***/ }),

/***/ "ikas":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-button/shared-button.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<button [ngClass]=\"type\" class=\"ion-activatable ripple-parent\">\n  <ion-ripple-effect></ion-ripple-effect>\n  <ng-content></ng-content>\n</button>\n");

/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "lA1K":
/*!********************************************************!*\
  !*** ./src/app/@core/services/api/api-user.service.ts ***!
  \********************************************************/
/*! exports provided: ApiUserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiUserService", function() { return ApiUserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../platform/app-config.service */ "ophu");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _logger_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../logger.service */ "JGf/");





let ApiUserService = class ApiUserService {
    constructor(appConfigService, http, loggerService) {
        this.http = http;
        this.loggerService = loggerService;
        this.restUrl = appConfigService.restUrl;
    }
    userAnonymousRegister(gender, birthdate, selectedRecommendations) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const body = {
                gender,
                birthdate,
                selectedRecommendations,
            };
            try {
                return yield this.http.post(`${this.restUrl}/api/User/register/anonymous`, body).toPromise();
            }
            catch (e) {
                console.error('userAnonymousRegister', JSON.stringify(e));
                return null;
            }
        });
    }
    userRegister(data) {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const body = {
                name: data === null || data === void 0 ? void 0 : data.name,
                email: data === null || data === void 0 ? void 0 : data.email,
                password: (_a = data === null || data === void 0 ? void 0 : data.passwords) === null || _a === void 0 ? void 0 : _a.password,
            };
            try {
                return yield this.http.post(`${this.restUrl}/api/User/register`, body).toPromise();
            }
            catch (e) {
                console.error('userRegister', JSON.stringify(e));
                return null;
            }
        });
    }
    userUpdate(body) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.put(`${this.restUrl}/api/User`, body).toPromise();
            }
            catch (e) {
                return null;
            }
        });
    }
    userLogin(data) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const body = {
                email: data === null || data === void 0 ? void 0 : data.email,
                password: data === null || data === void 0 ? void 0 : data.password,
            };
            try {
                return yield this.http.post(`${this.restUrl}/api/User/auth`, body).toPromise();
            }
            catch (e) {
                console.error('userLogin', JSON.stringify(e));
                return null;
            }
        });
    }
    userGoogle(body) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.post(`${this.restUrl}/api/User/auth/google`, body).toPromise();
            }
            catch (e) {
                console.error('userGoogle', JSON.stringify(e));
                return null;
            }
        });
    }
    userVk(token) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const body = {
                vkOAuthToken: token,
            };
            try {
                return yield this.http.post(`${this.restUrl}/api/User/auth/vk`, body).toPromise();
            }
            catch (e) {
                console.error('userVk', JSON.stringify(e));
                return null;
            }
        });
    }
    userCurrent() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/User/current`).toPromise();
            }
            catch (e) {
                console.error('userCurrent', JSON.stringify(e));
                return null;
            }
        });
    }
    sendReport(feedback) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                yield this.http.post(`${this.restUrl}/api/Feedback`, feedback).toPromise();
                return true;
            }
            catch (e) {
                console.error('sendReport', e);
                return false;
            }
        });
    }
    getReportReference() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/Feedback/categories`).toPromise();
            }
            catch (e) {
                console.error('getReportReference', e);
                return [];
            }
        });
    }
    getFavorites() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/Favourites`).toPromise();
            }
            catch (e) {
                console.error('getFavorites', e);
                return null;
            }
        });
    }
    addFavorites(feedId) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.http.post(`${this.restUrl}/api/Favourites`, { feedId }).toPromise();
        });
    }
    deleteFavorites(feedId) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.http.delete(`${this.restUrl}/api/Favourites/${feedId}`).toPromise();
        });
    }
    getAllArticles() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                return yield this.http.get(`${this.restUrl}/api/Articles/all`).toPromise();
            }
            catch (e) {
                console.error('getAllArticles', e);
                return [];
            }
        });
    }
    dropPassword(email) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const body = {
                email,
            };
            try {
                yield this.http.post(`${this.restUrl}/api/Password/reset-via-email`, body, { responseType: 'text' }).toPromise();
                return true;
            }
            catch (e) {
                console.error('dropPassword', e);
                return false;
            }
        });
    }
    refreshPassword(currentPassword, newPassword) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const body = {
                currentPassword,
                newPassword,
            };
            try {
                yield this.http.post(`${this.restUrl}/api/Password`, body).toPromise();
                return true;
            }
            catch (e) {
                console.error('refreshPassword', e);
                return false;
            }
        });
    }
};
ApiUserService.ctorParameters = () => [
    { type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _logger_service__WEBPACK_IMPORTED_MODULE_4__["LoggerService"] }
];
ApiUserService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApiUserService);



/***/ }),

/***/ "mLhf":
/*!***************************************************************************************!*\
  !*** ./src/app/@shared/components/shared-form-error/shared-form-error.component.scss ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("span {\n  color: #FF3B30;\n  font-size: 1.72vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC1mb3JtLWVycm9yLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGlCQUFBO0FBQ0YiLCJmaWxlIjoic2hhcmVkLWZvcm0tZXJyb3IuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJzcGFuIHtcbiAgY29sb3I6ICNGRjNCMzA7XG4gIGZvbnQtc2l6ZTogMS43MnZoO1xufVxuIl19 */");

/***/ }),

/***/ "ophu":
/*!***************************************************************!*\
  !*** ./src/app/@core/services/platform/app-config.service.ts ***!
  \***************************************************************/
/*! exports provided: AppConfigService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppConfigService", function() { return AppConfigService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");




let AppConfigService = class AppConfigService {
    constructor(httpClient, platformLocation) {
        this.httpClient = httpClient;
        this.platformLocation = platformLocation;
    }
    loadAppConfig() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.appConfig = yield this.httpClient.get('assets/config.json').toPromise();
        });
    }
    get restUrl() {
        if (!this.appConfig) {
            throw Error('Config file not loaded!');
        }
        return this.appConfig.restUrl;
    }
    get userUrl() {
        if (!this.appConfig) {
            throw Error('Config file not loaded!');
        }
        return this.appConfig.userUrl;
    }
    get recognitionUrl() {
        if (!this.appConfig) {
            throw Error('Config file not loaded!');
        }
        return this.appConfig.recognitionUrl;
    }
    get fileUrl() {
        if (!this.appConfig) {
            throw Error('Config file not loaded!');
        }
        return this.appConfig.fileUrl;
    }
    get locationOrigin() {
        return this.platformLocation.location.origin;
    }
    load() {
        return this.httpClient.get('assets/config.json')
            .toPromise()
            .then(x => {
            this.appConfig = x;
            return x;
        });
    }
};
AppConfigService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["PlatformLocation"] }
];
AppConfigService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AppConfigService);



/***/ }),

/***/ "p7KD":
/*!***********************************************************************************!*\
  !*** ./src/app/@shared/components/shared-textarea/shared-textarea.component.scss ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-item {\n  --min-height: 7.5vh;\n  --padding-start: 0;\n}\n\nion-label {\n  font-size: 1.97vh !important;\n  font-weight: 500 !important;\n  color: #99A0AB !important;\n}\n\nion-textarea {\n  --padding-top: 0;\n  --padding-bottom: 0;\n  font-size: 1.97vh;\n  color: #222222;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NoYXJlZC10ZXh0YXJlYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLDRCQUFBO0VBQ0EsMkJBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQUNGIiwiZmlsZSI6InNoYXJlZC10ZXh0YXJlYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcbiAgLS1taW4taGVpZ2h0OiA3LjV2aDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xufVxuXG5pb24tbGFiZWwge1xuICBmb250LXNpemU6IDEuOTd2aCAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogNTAwICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjOTlBMEFCICFpbXBvcnRhbnQ7XG59XG5cbmlvbi10ZXh0YXJlYSB7XG4gIC0tcGFkZGluZy10b3A6IDA7XG4gIC0tcGFkZGluZy1ib3R0b206IDA7XG4gIGZvbnQtc2l6ZTogMS45N3ZoO1xuICBjb2xvcjogIzIyMjIyMjtcbn1cbiJdfQ== */");

/***/ }),

/***/ "pk6O":
/*!******************************************!*\
  !*** ./src/app/@shared/shared.module.ts ***!
  \******************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _pipes_safe_url_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pipes/safe-url.pipe */ "5XVG");
/* harmony import */ var angular_svg_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-svg-icon */ "OFbc");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_common_locales_fr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/locales/fr */ "Hfs6");
/* harmony import */ var _angular_common_locales_fr__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_fr__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_shared_button_shared_button_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/shared-button/shared-button.component */ "DwYw");
/* harmony import */ var _components_shared_input_shared_input_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/shared-input/shared-input.component */ "zHSy");
/* harmony import */ var _components_shared_multiply_checker_shared_multiply_checker_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/shared-multiply-checker/shared-multiply-checker.component */ "v/Ss");
/* harmony import */ var _components_shared_select_shared_select_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/shared-select/shared-select.component */ "URgT");
/* harmony import */ var _components_shared_textarea_shared_textarea_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/shared-textarea/shared-textarea.component */ "FctL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _components_shared_form_error_shared_form_error_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/shared-form-error/shared-form-error.component */ "7RHv");
/* harmony import */ var _components_shared_image_slider_shared_image_slider_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/shared-image-slider/shared-image-slider.component */ "9mOG");
/* harmony import */ var _pipes_category_split_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./pipes/category-split.pipe */ "rJkM");


















Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["registerLocaleData"])(_angular_common_locales_fr__WEBPACK_IMPORTED_MODULE_7___default.a);
let SharedModule = class SharedModule {
};
SharedModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _pipes_safe_url_pipe__WEBPACK_IMPORTED_MODULE_4__["SafeUrlPipe"],
            _components_shared_button_shared_button_component__WEBPACK_IMPORTED_MODULE_8__["SharedButtonComponent"],
            _components_shared_input_shared_input_component__WEBPACK_IMPORTED_MODULE_9__["SharedInputComponent"],
            _components_shared_multiply_checker_shared_multiply_checker_component__WEBPACK_IMPORTED_MODULE_10__["SharedMultiplyCheckerComponent"],
            _components_shared_select_shared_select_component__WEBPACK_IMPORTED_MODULE_11__["SharedSelectComponent"],
            _components_shared_textarea_shared_textarea_component__WEBPACK_IMPORTED_MODULE_12__["SharedTextareaComponent"],
            _components_shared_form_error_shared_form_error_component__WEBPACK_IMPORTED_MODULE_14__["SharedFormErrorComponent"],
            _components_shared_image_slider_shared_image_slider_component__WEBPACK_IMPORTED_MODULE_15__["SharedImageSliderComponent"],
            _pipes_category_split_pipe__WEBPACK_IMPORTED_MODULE_16__["CategorySplitPipe"],
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            angular_svg_icon__WEBPACK_IMPORTED_MODULE_5__["AngularSvgIconModule"].forRoot(),
            _angular_forms__WEBPACK_IMPORTED_MODULE_13__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ReactiveFormsModule"],
        ],
        exports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            angular_svg_icon__WEBPACK_IMPORTED_MODULE_5__["AngularSvgIconModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClientModule"],
            _components_shared_button_shared_button_component__WEBPACK_IMPORTED_MODULE_8__["SharedButtonComponent"],
            _components_shared_input_shared_input_component__WEBPACK_IMPORTED_MODULE_9__["SharedInputComponent"],
            _components_shared_multiply_checker_shared_multiply_checker_component__WEBPACK_IMPORTED_MODULE_10__["SharedMultiplyCheckerComponent"],
            _components_shared_select_shared_select_component__WEBPACK_IMPORTED_MODULE_11__["SharedSelectComponent"],
            _components_shared_textarea_shared_textarea_component__WEBPACK_IMPORTED_MODULE_12__["SharedTextareaComponent"],
            _components_shared_form_error_shared_form_error_component__WEBPACK_IMPORTED_MODULE_14__["SharedFormErrorComponent"],
            _components_shared_image_slider_shared_image_slider_component__WEBPACK_IMPORTED_MODULE_15__["SharedImageSliderComponent"],
            _pipes_safe_url_pipe__WEBPACK_IMPORTED_MODULE_4__["SafeUrlPipe"],
            _pipes_category_split_pipe__WEBPACK_IMPORTED_MODULE_16__["CategorySplitPipe"],
        ]
    })
], SharedModule);



/***/ }),

/***/ "qCjG":
/*!***************************************************************!*\
  !*** ./src/app/@core/services/platform/status-bar.service.ts ***!
  \***************************************************************/
/*! exports provided: StatusBarService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StatusBarService", function() { return StatusBarService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ "gcOT");



const { StatusBar } = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"];
let StatusBarService = class StatusBarService {
    constructor() { }
    // TODO: add theme
    setDefault() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                yield StatusBar.setOverlaysWebView({ overlay: true });
                yield StatusBar.show();
                yield StatusBar.setStyle({ style: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["StatusBarStyle"].Light });
                yield StatusBar.setBackgroundColor({ color: '#ffffff' });
            }
            catch (e) {
                console.warn('StatusBar Error', e);
            }
        });
    }
    hide() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            try {
                yield StatusBar.hide();
            }
            catch (e) {
                console.warn('StatusBar Error', e);
            }
        });
    }
};
StatusBarService.ctorParameters = () => [];
StatusBarService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], StatusBarService);



/***/ }),

/***/ "qWzX":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-multiply-checker/shared-multiply-checker.component.html ***!
  \*****************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"checker\" [class.checker__active]=\"isActive\">\n  <svg-icon class=\"checker__icon\" src=\"assets/icon/svg/check.svg\"></svg-icon>\n</div>\n");

/***/ }),

/***/ "rJkM":
/*!******************************************************!*\
  !*** ./src/app/@shared/pipes/category-split.pipe.ts ***!
  \******************************************************/
/*! exports provided: CategorySplitPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategorySplitPipe", function() { return CategorySplitPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


let CategorySplitPipe = class CategorySplitPipe {
    transform(value) {
        const categoryArray = value.split('/');
        return categoryArray[categoryArray.length - 1];
    }
};
CategorySplitPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'categorySplit'
    })
], CategorySplitPipe);



/***/ }),

/***/ "tTdR":
/*!*****************************************************!*\
  !*** ./src/app/@core/services/user-info.service.ts ***!
  \*****************************************************/
/*! exports provided: UserInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserInfoService", function() { return UserInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _api_api_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api/api-user.service */ "lA1K");
/* harmony import */ var _app_token_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-token.service */ "gcGz");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "e8h1");
/* harmony import */ var _api_api_file_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./api/api-file.service */ "0SLh");







let UserInfoService = class UserInfoService {
    constructor(apiUserService, apiFileService, tokenService, storage) {
        this.apiUserService = apiUserService;
        this.apiFileService = apiFileService;
        this.tokenService = tokenService;
        this.storage = storage;
        this.initialGenderPath = 'initial-gender';
        this.genderReference = {
            male: 'Мужской',
            female: 'Женский',
        };
        this.authUser$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](null);
        this.selectedPreFavourites = [];
        this.isAnonUser = (user) => {
            return !(!!(user === null || user === void 0 ? void 0 : user.email) || !!user.name);
        };
        // this.tokenService.debugClear();
    }
    getAllArticles() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const articles = yield this.apiUserService.getAllArticles();
            articles
                .map(x => x.jsonContent)
                .map(x => x.blocks)
                .forEach(x => x.filter(k => k.type === 'photo').forEach(k => k.urls = k.urls.map(u => this.apiFileService.getArticlePhoto(u))));
            articles.forEach(x => {
                x.title = x.jsonContent.title;
                x.imageUrl = x.jsonContent.blocks.find(b => b.type === 'photo').urls[0];
            });
            return articles;
        });
    }
    setInitialGender(value) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            value = value !== null && value !== void 0 ? value : 'female';
            yield this.storage.set(this.initialGenderPath, value);
        });
    }
    getInitialGender() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const value = yield this.storage.get(this.initialGenderPath);
            return value !== null && value !== void 0 ? value : 'female';
        });
    }
    updateUser(user) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let res = yield this.apiUserService.userUpdate(user);
            res = res !== null && res !== void 0 ? res : Object.assign({}, this.authUser$.getValue());
            this.authUser$.next(res);
            return res;
        });
    }
    setUser(user) {
        if (!user) {
            return;
        }
        this.authUser$.next(Object.assign({}, user));
        if (!!(user === null || user === void 0 ? void 0 : user.token)) {
            this.tokenService.userTokenAuth = user.token;
        }
    }
    clearUser() {
        this.authUser$.next(null);
        this.tokenService.userToken = null;
    }
    init() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!!this.authUser$.getValue()) {
                return;
            }
            const user = yield this.getUserFromStorage();
            if (!user || this.isAnonUser(user)) {
                if (!this.tokenService.userToken) {
                    yield this.anonymousRegister();
                }
                return;
            }
            this.setUser(user);
        });
    }
    getUserFromStorage() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.apiUserService.userCurrent();
        });
    }
    anonymousRegister() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const gender = yield this.getInitialGender();
            const anonUser = yield this.apiUserService.userAnonymousRegister(gender, new Date(), this.selectedPreFavourites);
            if (!anonUser) {
                return;
            }
            this.tokenService.userToken = anonUser === null || anonUser === void 0 ? void 0 : anonUser.token;
        });
    }
};
UserInfoService.ctorParameters = () => [
    { type: _api_api_user_service__WEBPACK_IMPORTED_MODULE_3__["ApiUserService"] },
    { type: _api_api_file_service__WEBPACK_IMPORTED_MODULE_6__["ApiFileService"] },
    { type: _app_token_service__WEBPACK_IMPORTED_MODULE_4__["AppTokenService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] }
];
UserInfoService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UserInfoService);



/***/ }),

/***/ "ue9h":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/@shared/components/shared-select/shared-select.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-item>\n  <ion-label position=\"floating\"> {{ label }} </ion-label>\n  <ion-select *ngIf=\"formControl\" [formControl]=\"formControl\" cancelText=\"Отмена\" mode=\"md\" interface=\"action-sheet\">\n    <ion-select-option *ngFor=\"let value of values\" [value]=\"value.value\"> {{ value.title }} </ion-select-option>\n  </ion-select>\n</ion-item>\n");

/***/ }),

/***/ "v/Ss":
/*!*************************************************************************************************!*\
  !*** ./src/app/@shared/components/shared-multiply-checker/shared-multiply-checker.component.ts ***!
  \*************************************************************************************************/
/*! exports provided: SharedMultiplyCheckerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedMultiplyCheckerComponent", function() { return SharedMultiplyCheckerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_multiply_checker_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-multiply-checker.component.html */ "qWzX");
/* harmony import */ var _shared_multiply_checker_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-multiply-checker.component.scss */ "ZmEp");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedMultiplyCheckerComponent = class SharedMultiplyCheckerComponent {
    constructor() {
        this.isActive = false;
    }
    ngOnInit() {
    }
};
SharedMultiplyCheckerComponent.ctorParameters = () => [];
SharedMultiplyCheckerComponent.propDecorators = {
    isActive: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedMultiplyCheckerComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-multiply-checker',
        template: _raw_loader_shared_multiply_checker_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_multiply_checker_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedMultiplyCheckerComponent);



/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _core_guards_authentication_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./@core/guards/authentication.guard */ "vbgO");




const routes = [
    {
        path: 'preview',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-page-preview-page-preview-module */ "pages-page-preview-page-preview-module").then(__webpack_require__.bind(null, /*! ./pages/page-preview/page-preview.module */ "1XnR")).then(m => m.PagePreviewModule),
        canActivate: [_core_guards_authentication_guard__WEBPACK_IMPORTED_MODULE_3__["AuthenticationGuard"]],
    },
    {
        path: 'user_init',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-page-user-init-page-user-init-module */ "pages-page-user-init-page-user-init-module").then(__webpack_require__.bind(null, /*! ./pages/page-user-init/page-user-init.module */ "VzqC")).then(m => m.PageUserInitModule)
    },
    {
        path: 'pre_favorites',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-page-prefavorites-page-prefavorites-module */ "pages-page-prefavorites-page-prefavorites-module").then(__webpack_require__.bind(null, /*! ./pages/page-prefavorites/page-prefavorites.module */ "LZbA")).then(m => m.PagePrefavoritesModule)
    },
    {
        path: 'main',
        loadChildren: () => __webpack_require__.e(/*! import() | main-main-module */ "main-main-module").then(__webpack_require__.bind(null, /*! ./main/main.module */ "XpXM")).then(m => m.MainModule),
    },
    {
        path: '**',
        redirectTo: 'preview',
        pathMatch: 'full',
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["NoPreloading"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "vbgO":
/*!******************************************************!*\
  !*** ./src/app/@core/guards/authentication.guard.ts ***!
  \******************************************************/
/*! exports provided: AuthenticationGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthenticationGuard", function() { return AuthenticationGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_app_token_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/app-token.service */ "gcGz");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");




let AuthenticationGuard = class AuthenticationGuard {
    constructor(tokenService, navCtrl) {
        this.tokenService = tokenService;
        this.navCtrl = navCtrl;
    }
    canActivate(route, state) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // return true;
            if (this.tokenService.userToken) {
                this.navCtrl.navigateRoot('/main').then();
                return false;
            }
            else {
                return true;
            }
        });
    }
};
AuthenticationGuard.ctorParameters = () => [
    { type: _services_app_token_service__WEBPACK_IMPORTED_MODULE_2__["AppTokenService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] }
];
AuthenticationGuard = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthenticationGuard);



/***/ }),

/***/ "ynWL":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".camera-preview {\n  height: 100%;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0FBQ0YiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhbWVyYS1wcmV2aWV3IHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbn1cbiJdfQ== */");

/***/ }),

/***/ "zHSy":
/*!***************************************************************************!*\
  !*** ./src/app/@shared/components/shared-input/shared-input.component.ts ***!
  \***************************************************************************/
/*! exports provided: SharedInputComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedInputComponent", function() { return SharedInputComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_input_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-input.component.html */ "9jvt");
/* harmony import */ var _shared_input_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-input.component.scss */ "TtwI");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedInputComponent = class SharedInputComponent {
    constructor() {
        this.value = '';
        this.valueChange = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.label = '';
        this.type = 'text';
    }
    ngOnInit() {
    }
};
SharedInputComponent.ctorParameters = () => [];
SharedInputComponent.propDecorators = {
    formControl: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    value: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    valueChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    type: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedInputComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-input',
        template: _raw_loader_shared_input_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_input_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedInputComponent);



/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "a3Wg");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");
/* harmony import */ var _ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/pwa-elements/loader */ "2Zi2");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));
// Call the element loader after the platform has been bootstrapped
Object(_ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_4__["defineCustomElements"])(window).then(r => r);


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map