(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-page-user-init-page-user-init-module"],{

/***/ "/Aik":
/*!*************************************************************************************************************!*\
  !*** ./src/app/pages/page-user-init/page-user-init-round-button/page-user-init-round-button.component.scss ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  height: 7.29vh;\n  width: 23vh;\n  margin: 0 auto;\n  background: #F3F7FA;\n  border-radius: 6.07vh;\n}\n\nspan {\n  margin: auto;\n  font-weight: 700;\n  font-size: 2.2vh;\n  color: #6B7683;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtdXNlci1pbml0LXJvdW5kLWJ1dHRvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFDRiIsImZpbGUiOiJwYWdlLXVzZXItaW5pdC1yb3VuZC1idXR0b24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiA3LjI5dmg7XG4gIHdpZHRoOiAyM3ZoO1xuICBtYXJnaW46IDAgYXV0bztcbiAgYmFja2dyb3VuZDogI0YzRjdGQTtcbiAgYm9yZGVyLXJhZGl1czogNi4wN3ZoO1xufVxuXG5zcGFuIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LXNpemU6IDIuMnZoO1xuICBjb2xvcjogIzZCNzY4Mztcbn1cbiJdfQ== */");

/***/ }),

/***/ "GYat":
/*!***************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-user-init/page-user-init-round-button/page-user-init-round-button.component.html ***!
  \***************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect></ion-ripple-effect>\n  <span>\n    <ng-content></ng-content>\n  </span>\n</div>\n");

/***/ }),

/***/ "VzqC":
/*!***************************************************************!*\
  !*** ./src/app/pages/page-user-init/page-user-init.module.ts ***!
  \***************************************************************/
/*! exports provided: PageUserInitModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageUserInitModule", function() { return PageUserInitModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _page_user_init_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-user-init.component */ "dvbq");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../@shared/shared.module */ "pk6O");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _page_user_init_round_button_page_user_init_round_button_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./page-user-init-round-button/page-user-init-round-button.component */ "X0NH");







let PageUserInitModule = class PageUserInitModule {
};
PageUserInitModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_user_init_component__WEBPACK_IMPORTED_MODULE_3__["PageUserInitComponent"], _page_user_init_round_button_page_user_init_round_button_component__WEBPACK_IMPORTED_MODULE_6__["PageUserInitRoundButtonComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([{ path: '', component: _page_user_init_component__WEBPACK_IMPORTED_MODULE_3__["PageUserInitComponent"] }]),
        ]
    })
], PageUserInitModule);



/***/ }),

/***/ "X0NH":
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/page-user-init/page-user-init-round-button/page-user-init-round-button.component.ts ***!
  \***********************************************************************************************************/
/*! exports provided: PageUserInitRoundButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageUserInitRoundButtonComponent", function() { return PageUserInitRoundButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_user_init_round_button_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-user-init-round-button.component.html */ "GYat");
/* harmony import */ var _page_user_init_round_button_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-user-init-round-button.component.scss */ "/Aik");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let PageUserInitRoundButtonComponent = class PageUserInitRoundButtonComponent {
    constructor() {
        this.label = '-';
    }
};
PageUserInitRoundButtonComponent.ctorParameters = () => [];
PageUserInitRoundButtonComponent.propDecorators = {
    label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageUserInitRoundButtonComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-user-init-round-button',
        template: _raw_loader_page_user_init_round_button_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_user_init_round_button_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageUserInitRoundButtonComponent);



/***/ }),

/***/ "ZKNG":
/*!********************************************************************!*\
  !*** ./src/app/pages/page-user-init/page-user-init.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  padding: 3.7vh 20px 20px 20px;\n  box-sizing: border-box;\n  background: white;\n}\n\n.logo-wrapper {\n  display: flex;\n}\n\n.logo-wrapper .logo {\n  margin: auto;\n  height: 2.46vh;\n  width: 7.39vh;\n}\n\n.logo-wrapper .logo__icon {\n  color: #001424;\n  width: 100%;\n  height: 100%;\n}\n\n.main-wrapper {\n  display: flex;\n  flex-flow: column;\n  justify-content: center;\n  gap: 2.5vh;\n  flex-grow: 1;\n}\n\n.main-wrapper .label-text {\n  margin: 0 auto;\n  font-size: 3vh;\n  font-weight: 700;\n  color: #202D3D;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BhZ2UtdXNlci1pbml0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSw2QkFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7QUFDRjs7QUFDRTtFQUNFLFlBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQUNKOztBQUNJO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQ047O0FBSUE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBREY7O0FBR0U7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQURKIiwiZmlsZSI6InBhZ2UtdXNlci1pbml0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBwYWRkaW5nOiAzLjd2aCAyMHB4IDIwcHggMjBweDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5sb2dvLXdyYXBwZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuXG4gIC5sb2dvIHtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgaGVpZ2h0OiAyLjQ2dmg7XG4gICAgd2lkdGg6IDcuMzl2aDtcblxuICAgICZfX2ljb24ge1xuICAgICAgY29sb3I6ICMwMDE0MjQ7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICB9XG4gIH1cbn1cblxuLm1haW4td3JhcHBlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgZ2FwOiAyLjV2aDtcbiAgZmxleC1ncm93OiAxO1xuXG4gIC5sYWJlbC10ZXh0IHtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBmb250LXNpemU6IDN2aDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGNvbG9yOiAjMjAyRDNEO1xuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "cCKa":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-user-init/page-user-init.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"logo-wrapper\">\n    <div class=\"logo\">\n      <svg-icon class=\"logo__icon\" src=\"assets/icon/svg/luc-logo.svg\"></svg-icon>\n    </div>\n  </div>\n  <div class=\"main-wrapper\">\n    <span class=\"label-text\"> Я </span>\n    <app-page-user-init-round-button (click)=\"chooseCategory('male')\"> Мужчина </app-page-user-init-round-button>\n    <app-page-user-init-round-button (click)=\"chooseCategory('female')\"> Женщина </app-page-user-init-round-button>\n  </div>\n</div>\n");

/***/ }),

/***/ "dvbq":
/*!******************************************************************!*\
  !*** ./src/app/pages/page-user-init/page-user-init.component.ts ***!
  \******************************************************************/
/*! exports provided: PageUserInitComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageUserInitComponent", function() { return PageUserInitComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_user_init_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-user-init.component.html */ "cCKa");
/* harmony import */ var _page_user_init_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-user-init.component.scss */ "ZKNG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../@core/services/user-info.service */ "tTdR");






let PageUserInitComponent = class PageUserInitComponent {
    constructor(navCtrl, userInfoService) {
        this.navCtrl = navCtrl;
        this.userInfoService = userInfoService;
        this.nextRouteUrl = '/pre_favorites';
    }
    ngOnInit() {
    }
    chooseCategory(gender) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.userInfoService.setInitialGender(gender);
            yield this.navCtrl.navigateRoot(this.nextRouteUrl);
        });
    }
};
PageUserInitComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _core_services_user_info_service__WEBPACK_IMPORTED_MODULE_5__["UserInfoService"] }
];
PageUserInitComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-user-init',
        template: _raw_loader_page_user_init_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_user_init_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageUserInitComponent);



/***/ })

}]);
//# sourceMappingURL=pages-page-user-init-page-user-init-module-es2015.js.map