(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-page-scan-page-scan-module"],{

/***/ "+9lk":
/*!*****************************************************************!*\
  !*** ./src/app/popups/shared-filter/data/shared-filter.mock.ts ***!
  \*****************************************************************/
/*! exports provided: DATA_SOURCE_MAIN, DATA_SOURCE_COLORS, DATA_SOURCE_BRANDS, DATA_SOURCE_PRICES */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DATA_SOURCE_MAIN", function() { return DATA_SOURCE_MAIN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DATA_SOURCE_COLORS", function() { return DATA_SOURCE_COLORS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DATA_SOURCE_BRANDS", function() { return DATA_SOURCE_BRANDS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DATA_SOURCE_PRICES", function() { return DATA_SOURCE_PRICES; });
/* harmony import */ var _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../models/shared-filter.model */ "OnPs");

const DATA_SOURCE_MAIN = [
    {
        label: 'Бренд',
        type: _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_0__["SharedFilterTypes"].Brand,
    },
    {
        label: 'Цвет',
        type: _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_0__["SharedFilterTypes"].Color,
    },
    {
        label: 'Цена',
        type: _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_0__["SharedFilterTypes"].Price,
    },
];
const DATA_SOURCE_COLORS = [
    {
        id: 1,
        color: 'red',
        count: 23,
        label: 'красный',
    },
    {
        id: 2,
        color: 'blue',
        count: 123,
        label: 'синий',
    },
    {
        id: 3,
        color: 'green',
        count: 5,
        label: 'зеленый',
    },
];
const DATA_SOURCE_BRANDS = [
    {
        id: 1,
        label: 'Брэнд 1',
    },
    {
        id: 2,
        label: 'Брэнд 2',
    },
    {
        id: 3,
        label: 'Брэнд 3',
    },
];
const DATA_SOURCE_PRICES = [
    {
        id: 1,
        label: 'от 1079 до 2000',
        lowerPrice: 1079,
        higherPrice: 2000,
    },
    {
        id: 2,
        label: 'от 2000 до 4000',
        lowerPrice: 2000,
        higherPrice: 4000,
    },
    {
        id: 3,
        label: 'от 4000 до 7000',
        lowerPrice: 4000,
        higherPrice: 7000,
    },
    {
        id: 4,
        label: 'от 7000 до 44000',
        lowerPrice: 7000,
        higherPrice: 44000,
    },
];


/***/ }),

/***/ "0Fvf":
/*!********************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/shared-filter/components/shared-filter-brand-item/shared-filter-brand-item.component.html ***!
  \********************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect class=\"ion-ripple-color\"></ion-ripple-effect>\n  <div class=\"titles\">\n    <div class=\"titles__main\"> {{ data.label }} </div>\n  </div>\n  <div class=\"icon-wrapper\">\n    <svg-icon class=\"icon\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n  </div>\n</div>\n");

/***/ }),

/***/ "0ZA9":
/*!******************************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-color-item/shared-filter-color-item.component.scss ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  gap: 7vw;\n  width: inherit;\n  height: inherit;\n  padding: 5.3vw;\n  box-sizing: border-box;\n}\n.container > * {\n  margin: auto 0;\n}\n.container .ion-ripple-color {\n  color: lightgray;\n}\n.container .color {\n  width: 2.46vh;\n  height: 2.46vh;\n  border-radius: 50%;\n}\n.container .titles {\n  flex-grow: 1;\n  display: flex;\n  justify-content: left;\n  gap: 4vw;\n  font-size: 2vh;\n}\n.container .titles__main {\n  font-weight: 500;\n  color: #222222;\n}\n.container .titles__sub {\n  font-weight: 400;\n  color: #99A0AB;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NoYXJlZC1maWx0ZXItY29sb3ItaXRlbS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7QUFDRjtBQUNFO0VBQ0UsY0FBQTtBQUNKO0FBRUU7RUFDRSxnQkFBQTtBQUFKO0FBR0U7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBREo7QUFJRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EscUJBQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtBQUZKO0FBSUk7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUFGTjtBQUtJO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FBSE4iLCJmaWxlIjoic2hhcmVkLWZpbHRlci1jb2xvci1pdGVtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGdhcDogN3Z3O1xuICB3aWR0aDogaW5oZXJpdDtcbiAgaGVpZ2h0OiBpbmhlcml0O1xuICBwYWRkaW5nOiA1LjN2dztcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcblxuICAmID4gKiB7XG4gICAgbWFyZ2luOiBhdXRvIDA7XG4gIH1cblxuICAuaW9uLXJpcHBsZS1jb2xvciB7XG4gICAgY29sb3I6IGxpZ2h0Z3JheTtcbiAgfVxuXG4gIC5jb2xvciB7XG4gICAgd2lkdGg6IDIuNDZ2aDtcbiAgICBoZWlnaHQ6IDIuNDZ2aDtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIH1cblxuICAudGl0bGVzIHtcbiAgICBmbGV4LWdyb3c6IDE7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGxlZnQ7XG4gICAgZ2FwOiA0dnc7XG4gICAgZm9udC1zaXplOiAydmg7XG5cbiAgICAmX19tYWluIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBjb2xvcjogIzIyMjIyMjtcbiAgICB9XG5cbiAgICAmX19zdWIge1xuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICAgIGNvbG9yOiAjOTlBMEFCO1xuICAgIH1cbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "3Vnj":
/*!****************************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-menu-item/shared-filter-menu-item.component.scss ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  gap: 1vh;\n  width: inherit;\n  height: inherit;\n  padding: 5.3vw;\n  box-sizing: border-box;\n}\n.container .ion-ripple-color {\n  color: lightgray;\n}\n.container .titles {\n  flex-grow: 1;\n  display: flex;\n  flex-flow: column;\n  justify-content: center;\n  gap: 0.5vh;\n}\n.container .titles__main {\n  font-size: 1.97vh;\n  font-weight: 500;\n  color: #222222;\n}\n.container .titles__sub {\n  font-size: 1.72vh;\n  font-weight: 400;\n  color: #99A0AB;\n}\n.container .icon-wrapper {\n  width: 1.43vh;\n  height: 1.43vh;\n  margin: auto 0;\n  transform: scaleX(-1);\n}\n.container .icon-wrapper .icon {\n  color: #6B7683;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NoYXJlZC1maWx0ZXItbWVudS1pdGVtLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLFFBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxzQkFBQTtBQUNGO0FBQ0U7RUFDRSxnQkFBQTtBQUNKO0FBRUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxVQUFBO0FBQUo7QUFFSTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBQU47QUFHSTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBRE47QUFLRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLHFCQUFBO0FBSEo7QUFLSTtFQUNFLGNBQUE7QUFITiIsImZpbGUiOiJzaGFyZWQtZmlsdGVyLW1lbnUtaXRlbS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBnYXA6IDF2aDtcbiAgd2lkdGg6IGluaGVyaXQ7XG4gIGhlaWdodDogaW5oZXJpdDtcbiAgcGFkZGluZzogNS4zdnc7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG5cbiAgLmlvbi1yaXBwbGUtY29sb3Ige1xuICAgIGNvbG9yOiBsaWdodGdyYXk7XG4gIH1cblxuICAudGl0bGVzIHtcbiAgICBmbGV4LWdyb3c6IDE7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBnYXA6IDAuNXZoO1xuXG4gICAgJl9fbWFpbiB7XG4gICAgICBmb250LXNpemU6IDEuOTd2aDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBjb2xvcjogIzIyMjIyMjtcbiAgICB9XG5cbiAgICAmX19zdWIge1xuICAgICAgZm9udC1zaXplOiAxLjcydmg7XG4gICAgICBmb250LXdlaWdodDogNDAwO1xuICAgICAgY29sb3I6ICM5OUEwQUI7XG4gICAgfVxuICB9XG5cbiAgLmljb24td3JhcHBlciB7XG4gICAgd2lkdGg6IDEuNDN2aDtcbiAgICBoZWlnaHQ6IDEuNDN2aDtcbiAgICBtYXJnaW46IGF1dG8gMDtcbiAgICB0cmFuc2Zvcm06IHNjYWxlWCgtMSk7XG5cbiAgICAuaWNvbiB7XG4gICAgICBjb2xvcjogIzZCNzY4MztcbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "49fW":
/*!****************************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-price-item/shared-filter-price-item.component.ts ***!
  \****************************************************************************************************************/
/*! exports provided: SharedFilterPriceItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFilterPriceItemComponent", function() { return SharedFilterPriceItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_filter_price_item_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-filter-price-item.component.html */ "tD9w");
/* harmony import */ var _shared_filter_price_item_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-filter-price-item.component.scss */ "u0Lq");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedFilterPriceItemComponent = class SharedFilterPriceItemComponent {
    constructor() {
        this.data = null;
        this.isActive = false;
    }
    ngOnInit() {
    }
};
SharedFilterPriceItemComponent.ctorParameters = () => [];
SharedFilterPriceItemComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    isActive: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedFilterPriceItemComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-filter-price-item',
        template: _raw_loader_shared_filter_price_item_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_filter_price_item_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedFilterPriceItemComponent);



/***/ }),

/***/ "5g21":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/page-scan/page-scan-product/page-scan-product.component.ts ***!
  \**********************************************************************************/
/*! exports provided: PageScanProductComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageScanProductComponent", function() { return PageScanProductComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_scan_product_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-scan-product.component.html */ "mbl6");
/* harmony import */ var _page_scan_product_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-scan-product.component.scss */ "VvVI");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "kU1M");






let PageScanProductComponent = class PageScanProductComponent {
    constructor() {
        this.dataSource$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](null);
        this.dataSourceShared = this.dataSource$.asObservable();
        this.isSaleMode = this.dataSource$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(x => !!(x === null || x === void 0 ? void 0 : x.oldPrice)));
    }
    set data(value) {
        this.dataSource$.next(value);
    }
    ngOnInit() { }
};
PageScanProductComponent.ctorParameters = () => [];
PageScanProductComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PageScanProductComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-scan-product',
        template: _raw_loader_page_scan_product_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_scan_product_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageScanProductComponent);



/***/ }),

/***/ "EiOU":
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/shared-filter/components/shared-filter-menu-item/shared-filter-menu-item.component.html ***!
  \******************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect class=\"ion-ripple-color\"></ion-ripple-effect>\n  <div class=\"titles\">\n    <div class=\"titles__main\"> {{(data$ | async)?.label}} </div>\n    <div *ngIf=\"!!(subValueObserver | async)\" class=\"titles__sub\"> {{ subValueObserver | async }} </div>\n  </div>\n  <div class=\"icon-wrapper\">\n    <svg-icon class=\"icon\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n  </div>\n</div>\n");

/***/ }),

/***/ "MmPM":
/*!****************************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-color-item/shared-filter-color-item.component.ts ***!
  \****************************************************************************************************************/
/*! exports provided: SharedFilterColorItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFilterColorItemComponent", function() { return SharedFilterColorItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_filter_color_item_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-filter-color-item.component.html */ "PWiX");
/* harmony import */ var _shared_filter_color_item_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-filter-color-item.component.scss */ "0ZA9");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedFilterColorItemComponent = class SharedFilterColorItemComponent {
    constructor() {
        this.data = null;
        this.isActive = false;
    }
    ngOnInit() {
    }
};
SharedFilterColorItemComponent.ctorParameters = () => [];
SharedFilterColorItemComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    isActive: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedFilterColorItemComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-filter-color-item',
        template: _raw_loader_shared_filter_color_item_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_filter_color_item_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedFilterColorItemComponent);



/***/ }),

/***/ "NKYn":
/*!*******************************************************************!*\
  !*** ./src/app/popups/shared-filter/shared-filter.component.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  padding: 3.7vh 0 0 0;\n  box-sizing: border-box;\n  background: white;\n  overflow: hidden;\n  gap: 2.37vh;\n}\n.container .header {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n  padding: 0 2.2vh;\n  box-sizing: border-box;\n}\n.container .header .icon {\n  width: 2.43vh;\n  height: 2.43vh;\n  z-index: 1;\n}\n.container .header .icon__back {\n  color: #3A83F1;\n}\n.container .header .title {\n  position: absolute;\n  left: 0;\n  right: 0;\n  text-align: center;\n  font-weight: 600;\n  font-size: 2.1vh;\n  color: #222222;\n}\n.container .header .reset-button {\n  font-size: 1.97vh;\n  color: #3A83F1;\n  z-index: 1;\n}\n.container .scroll-wrapper {\n  flex-grow: 1;\n  width: 100%;\n  overflow: auto;\n}\n.container .content {\n  height: 100%;\n  width: 100%;\n}\n.container .content .menu-item {\n  width: 100%;\n  height: 7.88vh;\n}\n.container .content .search-container {\n  padding: 0 5.3vw;\n  box-sizing: border-box;\n}\n.container .footer {\n  padding: 0 5.3vw 5.3vw 5.3vw;\n  box-sizing: border-box;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NoYXJlZC1maWx0ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtBQUNGO0FBQ0U7RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtBQUNKO0FBQ0k7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7QUFDTjtBQUNNO0VBQ0UsY0FBQTtBQUNSO0FBR0k7RUFDRSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUROO0FBSUk7RUFDRSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0FBRk47QUFNRTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtBQUpKO0FBT0U7RUFDRSxZQUFBO0VBQ0EsV0FBQTtBQUxKO0FBT0k7RUFDRSxXQUFBO0VBQ0EsY0FBQTtBQUxOO0FBUUk7RUFDRSxnQkFBQTtFQUNBLHNCQUFBO0FBTk47QUFVRTtFQUNFLDRCQUFBO0VBQ0Esc0JBQUE7QUFSSiIsImZpbGUiOiJzaGFyZWQtZmlsdGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBwYWRkaW5nOiAzLjd2aCAwIDAgMDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGdhcDogMi4zN3ZoO1xuXG4gIC5oZWFkZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIHBhZGRpbmc6IDAgMi4ydmg7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcblxuICAgIC5pY29uIHtcbiAgICAgIHdpZHRoOiAyLjQzdmg7XG4gICAgICBoZWlnaHQ6IDIuNDN2aDtcbiAgICAgIHotaW5kZXg6IDE7XG5cbiAgICAgICZfX2JhY2sge1xuICAgICAgICBjb2xvcjogIzNBODNGMTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAudGl0bGUge1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgbGVmdDogMDtcbiAgICAgIHJpZ2h0OiAwO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIGZvbnQtc2l6ZTogMi4xdmg7XG4gICAgICBjb2xvcjogIzIyMjIyMjtcbiAgICB9XG5cbiAgICAucmVzZXQtYnV0dG9uIHtcbiAgICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgICAgY29sb3I6ICMzQTgzRjE7XG4gICAgICB6LWluZGV4OiAxO1xuICAgIH1cbiAgfVxuXG4gIC5zY3JvbGwtd3JhcHBlciB7XG4gICAgZmxleC1ncm93OiAxO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG92ZXJmbG93OiBhdXRvO1xuICB9XG5cbiAgLmNvbnRlbnQge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIC5tZW51LWl0ZW0ge1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBoZWlnaHQ6IDcuODh2aDtcbiAgICB9XG5cbiAgICAuc2VhcmNoLWNvbnRhaW5lciB7XG4gICAgICBwYWRkaW5nOiAwIDUuM3Z3O1xuICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICB9XG4gIH1cblxuICAuZm9vdGVyIHtcbiAgICBwYWRkaW5nOiAwIDUuM3Z3IDUuM3Z3IDUuM3Z3O1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "OnPs":
/*!***********************************************!*\
  !*** ./src/app/models/shared-filter.model.ts ***!
  \***********************************************/
/*! exports provided: SharedFilterTypes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFilterTypes", function() { return SharedFilterTypes; });
var SharedFilterTypes;
(function (SharedFilterTypes) {
    SharedFilterTypes[SharedFilterTypes["Main"] = 0] = "Main";
    SharedFilterTypes[SharedFilterTypes["Color"] = 1] = "Color";
    SharedFilterTypes[SharedFilterTypes["Brand"] = 2] = "Brand";
    SharedFilterTypes[SharedFilterTypes["Price"] = 3] = "Price";
})(SharedFilterTypes || (SharedFilterTypes = {}));


/***/ }),

/***/ "PWiX":
/*!********************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/shared-filter/components/shared-filter-color-item/shared-filter-color-item.component.html ***!
  \********************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect class=\"ion-ripple-color\"></ion-ripple-effect>\n  <div [style.background]=\"data.color\" class=\"color\"></div>\n  <div class=\"titles\">\n    <div class=\"titles__main\"> {{data.label}} </div>\n    <div class=\"titles__sub\"> {{data.count}}</div>\n  </div>\n  <app-shared-multiply-checker [isActive]=\"isActive\"></app-shared-multiply-checker>\n</div>\n");

/***/ }),

/***/ "Q/L6":
/*!**********************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-search/shared-filter-search.component.scss ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  width: inherit;\n  height: 4.43vh;\n  gap: 2vh;\n  padding: 0 3.2vw;\n  box-sizing: border-box;\n  border-radius: 1.23vh;\n  background: #F0F2F5;\n}\n.container > * {\n  margin: auto 0;\n}\n.container .icon {\n  position: relative;\n  width: 2vh;\n  height: 2vh;\n}\n.container .icon__search {\n  color: #99A0AB;\n}\n.container .input {\n  font-size: 1.8vh;\n  color: #99A0AB;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NoYXJlZC1maWx0ZXItc2VhcmNoLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0EsUUFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7QUFDRTtFQUNFLGNBQUE7QUFDSjtBQUVFO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQUFKO0FBRUk7RUFDRSxjQUFBO0FBQU47QUFJRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQUZKIiwiZmlsZSI6InNoYXJlZC1maWx0ZXItc2VhcmNoLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiBpbmhlcml0O1xuICBoZWlnaHQ6IDQuNDN2aDtcbiAgZ2FwOiAydmg7XG4gIHBhZGRpbmc6IDAgMy4ydnc7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJvcmRlci1yYWRpdXM6IDEuMjN2aDtcbiAgYmFja2dyb3VuZDogI0YwRjJGNTtcblxuICAmID4gKiB7XG4gICAgbWFyZ2luOiBhdXRvIDA7XG4gIH1cblxuICAuaWNvbiB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAydmg7XG4gICAgaGVpZ2h0OiAydmg7XG5cbiAgICAmX19zZWFyY2gge1xuICAgICAgY29sb3I6ICM5OUEwQUI7XG4gICAgfVxuICB9XG5cbiAgLmlucHV0IHtcbiAgICBmb250LXNpemU6IDEuOHZoO1xuICAgIGNvbG9yOiAjOTlBMEFCO1xuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "TeEr":
/*!********************************************************!*\
  !*** ./src/app/pages/page-scan/page-scan.component.ts ***!
  \********************************************************/
/*! exports provided: PageScanComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageScanComponent", function() { return PageScanComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_page_scan_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./page-scan.component.html */ "Yzfo");
/* harmony import */ var _page_scan_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-scan.component.scss */ "hCkK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _popups_shared_filter_shared_filter_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../popups/shared-filter/shared-filter.component */ "on7q");
/* harmony import */ var _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../page-product/page-product.component */ "8jGz");
/* harmony import */ var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../@core/services/recognition-info.service */ "7mVc");
/* harmony import */ var _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../@core/services/api/api-recognition.service */ "p0lb");












let PageScanComponent = class PageScanComponent {
    constructor(navCtrl, location, modalController, recognitionInfoService, apiRecognitionService, platform) {
        this.navCtrl = navCtrl;
        this.location = location;
        this.modalController = modalController;
        this.recognitionInfoService = recognitionInfoService;
        this.apiRecognitionService = apiRecognitionService;
        this.platform = platform;
        this.defaultProducts = new Array(6);
        this.products$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](this.defaultProducts);
        this.productsShared = this.products$.asObservable();
        this.isProductEmpty = this.productsShared.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["map"])(x => !((x === null || x === void 0 ? void 0 : x.length) > 0)));
        this.goToPreviousRoute = () => {
            this.location.back();
        };
    }
    ngOnInit() {
        this.getData().then();
        this.platform.backButton.subscribeWithPriority(9999, () => {
            this.closePage();
        });
    }
    chooseProduct(product) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (!product) {
                return;
            }
            this.recognitionInfoService.recognitionFeedFunction = () => this.apiRecognitionService.getFullItem(product.id);
            yield this.presentModalInfo();
        });
    }
    closePage() {
        this.goToPreviousRoute();
    }
    openFilter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // TODO: add true filters and clear return
            return;
            yield this.presentModalFilter();
        });
    }
    getData() {
        var _a, _b, _c, _d;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = yield ((_b = (_a = this.recognitionInfoService).recognitionSaveFunction) === null || _b === void 0 ? void 0 : _b.call(_a));
            (_c = res === null || res === void 0 ? void 0 : res.previews) === null || _c === void 0 ? void 0 : _c.forEach(x => { var _a; return x.category = (_a = x === null || x === void 0 ? void 0 : x.type) === null || _a === void 0 ? void 0 : _a.split('/').reverse()[0]; });
            this.products$.next((_d = res === null || res === void 0 ? void 0 : res.previews) !== null && _d !== void 0 ? _d : []);
        });
    }
    presentModalFilter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _popups_shared_filter_shared_filter_component__WEBPACK_IMPORTED_MODULE_8__["SharedFilterComponent"],
            });
            return yield modal.present();
        });
    }
    presentModalInfo() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_9__["PageProductComponent"],
            });
            return yield modal.present();
        });
    }
};
PageScanComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["Location"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_10__["RecognitionInfoService"] },
    { type: _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_11__["ApiRecognitionService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"] }
];
PageScanComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-scan',
        template: _raw_loader_page_scan_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_page_scan_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PageScanComponent);



/***/ }),

/***/ "Ujui":
/*!**************************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-menu-item/shared-filter-menu-item.component.ts ***!
  \**************************************************************************************************************/
/*! exports provided: SharedFilterMenuItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFilterMenuItemComponent", function() { return SharedFilterMenuItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_filter_menu_item_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-filter-menu-item.component.html */ "EiOU");
/* harmony import */ var _shared_filter_menu_item_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-filter-menu-item.component.scss */ "3Vnj");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../models/shared-filter.model */ "OnPs");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "kU1M");







let SharedFilterMenuItemComponent = class SharedFilterMenuItemComponent {
    constructor() {
        this.data$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"](null);
        this.subValueObserver = this.data$.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["map"])((x) => {
            if (!(x === null || x === void 0 ? void 0 : x.value)) {
                return null;
            }
            switch (x.type) {
                case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_4__["SharedFilterTypes"].Brand:
                case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_4__["SharedFilterTypes"].Price:
                    return x.value.label;
                case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_4__["SharedFilterTypes"].Color:
                    if (!x.value || !x.value.length) {
                        return null;
                    }
                    else {
                        return x.value
                            .map(item => item.label)
                            .reduce((acc, val) => `${acc}, ${val}`);
                    }
            }
        }));
    }
    set data(val) {
        this.data$.next(val);
    }
    ngOnInit() {
    }
};
SharedFilterMenuItemComponent.ctorParameters = () => [];
SharedFilterMenuItemComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedFilterMenuItemComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-filter-menu-item',
        template: _raw_loader_shared_filter_menu_item_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_filter_menu_item_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedFilterMenuItemComponent);



/***/ }),

/***/ "VvVI":
/*!************************************************************************************!*\
  !*** ./src/app/pages/page-scan/page-scan-product/page-scan-product.component.scss ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  flex-flow: column;\n  gap: 0.5vh;\n  max-width: 18.95vh;\n}\n.container .price__normal {\n  font-weight: bold;\n  font-size: 1.72vh;\n  line-height: 1.97vh;\n  color: #202D3D;\n}\n.container .price__old {\n  font-weight: 500;\n  font-size: 1.48vh;\n  line-height: 1.72vh;\n  -webkit-text-decoration-line: line-through;\n          text-decoration-line: line-through;\n  color: #6B7683;\n}\n.container .price__sale {\n  font-weight: bold;\n  font-size: 1.72vh;\n  line-height: 1.97vh;\n  color: #3A83F1;\n}\n.container .label__brand {\n  font-size: 1.48vh;\n  line-height: 1.72vh;\n  color: #2F3441;\n}\n.container .label__category {\n  font-size: 1.48vh;\n  line-height: 1.72vh;\n  color: #6B7683;\n}\n.container .photo {\n  width: 18.95vh;\n  height: 25.52vh;\n  border-radius: 1.45vh;\n  margin-bottom: 1vh;\n  overflow: hidden;\n  background: #DCE0EB;\n}\n.image {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2Utc2Nhbi1wcm9kdWN0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0FBQ0Y7QUFHSTtFQUNFLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUFETjtBQUlJO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7VUFBQSxrQ0FBQTtFQUNBLGNBQUE7QUFGTjtBQUtJO0VBQ0UsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQUhOO0FBU0k7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQVBOO0FBVUk7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQVJOO0FBWUU7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBVko7QUFjQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQVhGIiwiZmlsZSI6InBhZ2Utc2Nhbi1wcm9kdWN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBnYXA6IDAuNXZoO1xuICBtYXgtd2lkdGg6IDE4Ljk1dmg7XG5cbiAgLnByaWNlIHtcblxuICAgICZfX25vcm1hbCB7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIGZvbnQtc2l6ZTogMS43MnZoO1xuICAgICAgbGluZS1oZWlnaHQ6IDEuOTd2aDtcbiAgICAgIGNvbG9yOiAjMjAyRDNEO1xuICAgIH1cblxuICAgICZfX29sZCB7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgZm9udC1zaXplOiAxLjQ4dmg7XG4gICAgICBsaW5lLWhlaWdodDogMS43MnZoO1xuICAgICAgdGV4dC1kZWNvcmF0aW9uLWxpbmU6IGxpbmUtdGhyb3VnaDtcbiAgICAgIGNvbG9yOiAjNkI3NjgzO1xuICAgIH1cblxuICAgICZfX3NhbGUge1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICBmb250LXNpemU6IDEuNzJ2aDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjk3dmg7XG4gICAgICBjb2xvcjogIzNBODNGMTtcbiAgICB9XG4gIH1cblxuICAubGFiZWwge1xuXG4gICAgJl9fYnJhbmQge1xuICAgICAgZm9udC1zaXplOiAxLjQ4dmg7XG4gICAgICBsaW5lLWhlaWdodDogMS43MnZoO1xuICAgICAgY29sb3I6ICMyRjM0NDFcbiAgICB9XG5cbiAgICAmX19jYXRlZ29yeSB7XG4gICAgICBmb250LXNpemU6IDEuNDh2aDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjcydmg7XG4gICAgICBjb2xvcjogIzZCNzY4MztcbiAgICB9XG4gIH1cblxuICAucGhvdG8ge1xuICAgIHdpZHRoOiAxOC45NXZoO1xuICAgIGhlaWdodDogMjUuNTJ2aDtcbiAgICBib3JkZXItcmFkaXVzOiAxLjQ1dmg7XG4gICAgbWFyZ2luLWJvdHRvbTogMXZoO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgYmFja2dyb3VuZDogI0RDRTBFQjtcbiAgfVxufVxuXG4uaW1hZ2Uge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvYmplY3QtZml0OiBjb3Zlcjtcbn1cbiJdfQ== */");

/***/ }),

/***/ "YKaR":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/shared-filter/shared-filter.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"header\">\n    <svg-icon (click)=\"close()\" class=\"icon icon__back\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n    <span class=\"title\"> Фильтр </span>\n    <span (click)=\"clearFilter()\" class=\"reset-button\"> Сбросить </span>\n  </div>\n  <div class=\"scroll-wrapper\">\n    <div class=\"content\">\n      <ng-container [ngSwitch]=\"type$ | async\">\n        <div *ngSwitchCase=\"SharedFilterTypes.Main\" [@enterTrigger]=\"'fadeIn'\">\n          <app-shared-filter-menu-item\n            *ngFor=\"let item of (main$ | async)\"\n            [data]=\"item\"\n            (click)=\"selectMenu(item.type)\"\n          ></app-shared-filter-menu-item>\n        </div>\n        <div *ngSwitchCase=\"SharedFilterTypes.Color\" [@enterTrigger]=\"'fadeIn'\">\n          <app-shared-filter-color-item\n            *ngFor=\"let item of colors$ | async\"\n            [data]=\"item\"\n            [isActive]=\"isActiveFilter(item.id, SharedFilterTypes.Color) | async\"\n            (click)=\"selectFilter(item, SharedFilterTypes.Color)\"\n          ></app-shared-filter-color-item>\n        </div>\n        <div *ngSwitchCase=\"SharedFilterTypes.Brand\" [@enterTrigger]=\"'fadeIn'\">\n          <div class=\"search-container\">\n            <app-shared-filter-search></app-shared-filter-search>\n          </div>\n          <app-shared-filter-brand-item\n            *ngFor=\"let item of brands$ | async\"\n            [data]=\"item\"\n            (click)=\"selectFilter(item, SharedFilterTypes.Brand)\"\n          ></app-shared-filter-brand-item>\n        </div>\n        <div *ngSwitchCase=\"SharedFilterTypes.Price\" [@enterTrigger]=\"'fadeIn'\">\n          <app-shared-filter-price-item\n            *ngFor=\"let item of prices$ | async\"\n            [data]=\"item\"\n            [isActive]=\"isActiveFilter(item.id, SharedFilterTypes.Price) | async\"\n            (click)=\"selectFilter(item, SharedFilterTypes.Price)\"\n          ></app-shared-filter-price-item>\n        </div>\n      </ng-container>\n    </div>\n  </div>\n  <div class=\"footer\">\n    <app-shared-button type=\"main\" style=\"width: 100%\">\n      Готово\n    </app-shared-button>\n  </div>\n</div>\n");

/***/ }),

/***/ "Yzfo":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-scan/page-scan.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <div class=\"header\">\n    <svg-icon (click)=\"closePage()\" class=\"icon icon__back\" src=\"assets/icon/svg/back.svg\"></svg-icon>\n    <svg-icon (click)=\"openFilter()\" class=\"icon icon__filter\" src=\"assets/icon/svg/filter-list.svg\"></svg-icon>\n  </div>\n  <div class=\"scroll-wrapper\">\n    <div class=\"product-container\">\n      <ng-container *ngIf=\"!(isProductEmpty | async); else productContainerEmpty\">\n        <app-page-scan-product\n          *ngFor=\"let product of (productsShared | async)\"\n          [data]=\"product\"\n          (click)=\"chooseProduct(product)\"\n        ></app-page-scan-product>\n      </ng-container>\n    </div>\n  </div>\n</div>\n\n<ng-template #productContainerEmpty>\n  <span class=\"text-empty\"> К сожалению, поиск не дал результатов </span>\n</ng-template>\n");

/***/ }),

/***/ "c2vx":
/*!*****************************************************!*\
  !*** ./src/app/pages/page-scan/page-scan.module.ts ***!
  \*****************************************************/
/*! exports provided: PageScanModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageScanModule", function() { return PageScanModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _page_scan_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page-scan.component */ "TeEr");
/* harmony import */ var _page_scan_product_page_scan_product_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page-scan-product/page-scan-product.component */ "5g21");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../@shared/shared.module */ "pk6O");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _popups_shared_filter_shared_filter_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../popups/shared-filter/shared-filter.module */ "djxn");
/* harmony import */ var _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../page-product/page-product.module */ "A6qN");









let PageScanModule = class PageScanModule {
};
PageScanModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_scan_component__WEBPACK_IMPORTED_MODULE_3__["PageScanComponent"], _page_scan_product_page_scan_product_component__WEBPACK_IMPORTED_MODULE_4__["PageScanProductComponent"]],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
            _popups_shared_filter_shared_filter_module__WEBPACK_IMPORTED_MODULE_7__["SharedFilterModule"],
            _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_8__["PageProductModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"].forChild([{ path: '', component: _page_scan_component__WEBPACK_IMPORTED_MODULE_3__["PageScanComponent"] }]),
        ]
    })
], PageScanModule);



/***/ }),

/***/ "djxn":
/*!**************************************************************!*\
  !*** ./src/app/popups/shared-filter/shared-filter.module.ts ***!
  \**************************************************************/
/*! exports provided: SharedFilterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFilterModule", function() { return SharedFilterModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _shared_filter_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shared-filter.component */ "on7q");
/* harmony import */ var _components_shared_filter_menu_item_shared_filter_menu_item_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/shared-filter-menu-item/shared-filter-menu-item.component */ "Ujui");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../@shared/shared.module */ "pk6O");
/* harmony import */ var _components_shared_filter_color_item_shared_filter_color_item_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/shared-filter-color-item/shared-filter-color-item.component */ "MmPM");
/* harmony import */ var _components_shared_filter_brand_item_shared_filter_brand_item_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/shared-filter-brand-item/shared-filter-brand-item.component */ "q/Dt");
/* harmony import */ var _components_shared_filter_price_item_shared_filter_price_item_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/shared-filter-price-item/shared-filter-price-item.component */ "49fW");
/* harmony import */ var _components_shared_filter_search_shared_filter_search_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/shared-filter-search/shared-filter-search.component */ "iDiU");










let SharedFilterModule = class SharedFilterModule {
};
SharedFilterModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _shared_filter_component__WEBPACK_IMPORTED_MODULE_3__["SharedFilterComponent"],
            _components_shared_filter_menu_item_shared_filter_menu_item_component__WEBPACK_IMPORTED_MODULE_4__["SharedFilterMenuItemComponent"],
            _components_shared_filter_color_item_shared_filter_color_item_component__WEBPACK_IMPORTED_MODULE_6__["SharedFilterColorItemComponent"],
            _components_shared_filter_brand_item_shared_filter_brand_item_component__WEBPACK_IMPORTED_MODULE_7__["SharedFilterBrandItemComponent"],
            _components_shared_filter_price_item_shared_filter_price_item_component__WEBPACK_IMPORTED_MODULE_8__["SharedFilterPriceItemComponent"],
            _components_shared_filter_search_shared_filter_search_component__WEBPACK_IMPORTED_MODULE_9__["SharedFilterSearchComponent"],
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
        ]
    })
], SharedFilterModule);



/***/ }),

/***/ "hCkK":
/*!**********************************************************!*\
  !*** ./src/app/pages/page-scan/page-scan.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-flow: column;\n  padding: 3.7vh 0 0 0;\n  box-sizing: border-box;\n  background: white;\n  overflow: hidden;\n  gap: 2.37vh;\n}\n.container .header {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n  padding: 0 2.2vh;\n  box-sizing: border-box;\n}\n.container .header .icon {\n  width: 2.43vh;\n  height: 2.43vh;\n}\n.container .header .icon__back {\n  color: #2CB172;\n}\n.container .header .icon__filter {\n  color: #DADADA;\n}\n.container .scroll-wrapper {\n  flex-grow: 1;\n  overflow: auto;\n}\n.container .product-container {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: space-evenly;\n  row-gap: 3vh;\n  -moz-column-gap: 3vw;\n       column-gap: 3vw;\n  padding: 2vh 3vw;\n}\n.container .product-container .text-empty {\n  color: #6B7683;\n  font-size: 1.5vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3BhZ2Utc2Nhbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0FBQ0Y7QUFDRTtFQUNFLGFBQUE7RUFDQSxXQUFBO0VBQ0EsOEJBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0FBQ0o7QUFDSTtFQUNFLGFBQUE7RUFDQSxjQUFBO0FBQ047QUFDTTtFQUNFLGNBQUE7QUFDUjtBQUVNO0VBQ0UsY0FBQTtBQUFSO0FBS0U7RUFDRSxZQUFBO0VBQ0EsY0FBQTtBQUhKO0FBTUU7RUFDRSxhQUFBO0VBQ0EsZUFBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO09BQUEsZUFBQTtFQUNBLGdCQUFBO0FBSko7QUFNSTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtBQUpOIiwiZmlsZSI6InBhZ2Utc2Nhbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgcGFkZGluZzogMy43dmggMCAwIDA7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBnYXA6IDIuMzd2aDtcblxuICAuaGVhZGVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBwYWRkaW5nOiAwIDIuMnZoO1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG5cbiAgICAuaWNvbiB7XG4gICAgICB3aWR0aDogMi40M3ZoO1xuICAgICAgaGVpZ2h0OiAyLjQzdmg7XG5cbiAgICAgICZfX2JhY2sge1xuICAgICAgICBjb2xvcjogIzJDQjE3MjtcbiAgICAgIH1cblxuICAgICAgJl9fZmlsdGVyIHtcbiAgICAgICAgY29sb3I6ICNEQURBREE7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLnNjcm9sbC13cmFwcGVyIHtcbiAgICBmbGV4LWdyb3c6IDE7XG4gICAgb3ZlcmZsb3c6IGF1dG87XG4gIH1cblxuICAucHJvZHVjdC1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC13cmFwOiB3cmFwO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICAgIHJvdy1nYXA6IDN2aDtcbiAgICBjb2x1bW4tZ2FwOiAzdnc7XG4gICAgcGFkZGluZzogMnZoIDN2dztcblxuICAgIC50ZXh0LWVtcHR5IHtcbiAgICAgIGNvbG9yOiAjNkI3NjgzO1xuICAgICAgZm9udC1zaXplOiAxLjV2aDtcbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "iDiU":
/*!********************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-search/shared-filter-search.component.ts ***!
  \********************************************************************************************************/
/*! exports provided: SharedFilterSearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFilterSearchComponent", function() { return SharedFilterSearchComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_filter_search_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-filter-search.component.html */ "x+bJ");
/* harmony import */ var _shared_filter_search_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-filter-search.component.scss */ "Q/L6");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedFilterSearchComponent = class SharedFilterSearchComponent {
    constructor() {
    }
    ngOnInit() {
    }
};
SharedFilterSearchComponent.ctorParameters = () => [];
SharedFilterSearchComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-filter-search',
        template: _raw_loader_shared_filter_search_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_shared_filter_search_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedFilterSearchComponent);



/***/ }),

/***/ "jSaA":
/*!*********************************************************!*\
  !*** ./src/app/@shared/functions/deep-copy.function.ts ***!
  \*********************************************************/
/*! exports provided: deepCopy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deepCopy", function() { return deepCopy; });
// TODO: change to real deep copy
const deepCopy = (ref) => {
    return JSON.parse(JSON.stringify(ref));
};


/***/ }),

/***/ "mbl6":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-scan/page-scan-product/page-scan-product.component.html ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngIf=\"!!(dataSourceShared | async); else pageScanProductSkeleton\">\n  <div class=\"container\">\n    <div class=\"photo\">\n      <img class=\"image\" alt=\"\" [src]=\"(dataSourceShared | async).imageUrl\">\n    </div>\n    <div class=\"price\">\n      <ng-container *ngIf=\"isSaleMode | async; else normalPriceMode\">\n        <span class=\"price__old\"> {{ ((dataSourceShared | async)?.oldPrice | number:'':'fr-FR') || 0 }} </span>\n        <span class=\"price__sale\"> {{ ((dataSourceShared | async)?.price | number:'':'fr-FR') || 0 }} </span>\n      </ng-container>\n      <ng-template #normalPriceMode>\n        <span class=\"price__normal\"> {{ ((dataSourceShared | async)?.price | number:'':'fr-FR') || 0}} </span>\n      </ng-template>\n    </div>\n    <div class=\"label\">\n      <span class=\"label__brand\"> {{ (dataSourceShared | async)?.brand || 'Brand' }} / </span>\n      <span class=\"label__category\"> {{ (dataSourceShared | async)?.category  || 'Category' }} </span>\n    </div>\n  </div>\n</ng-container>\n\n<ng-template #pageScanProductSkeleton>\n  <div class=\"container\">\n    <div class=\"photo\">\n    </div>\n    <ion-skeleton-text animated style=\"width:40%; height: 1.23vh\"></ion-skeleton-text>\n    <ion-skeleton-text animated style=\"width:60%; height: 1.23vh\"></ion-skeleton-text>\n  </div>\n</ng-template>\n");

/***/ }),

/***/ "on7q":
/*!*****************************************************************!*\
  !*** ./src/app/popups/shared-filter/shared-filter.component.ts ***!
  \*****************************************************************/
/*! exports provided: SharedFilterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFilterComponent", function() { return SharedFilterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_filter_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-filter.component.html */ "YKaR");
/* harmony import */ var _shared_filter_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-filter.component.scss */ "NKYn");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/animations */ "R0Ic");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../models/shared-filter.model */ "OnPs");
/* harmony import */ var _data_shared_filter_mock__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./data/shared-filter.mock */ "+9lk");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _shared_functions_deep_copy_function__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../@shared/functions/deep-copy.function */ "jSaA");











let SharedFilterComponent = class SharedFilterComponent {
    constructor(modalCtrl) {
        this.modalCtrl = modalCtrl;
        this.SharedFilterTypes = _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"];
        this.type$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"](_models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Main);
        this.main$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([]);
        this.colors$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([]);
        this.brands$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([]);
        this.prices$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([]);
    }
    ngOnInit() {
        this.main$.next(Object(_shared_functions_deep_copy_function__WEBPACK_IMPORTED_MODULE_10__["deepCopy"])(_data_shared_filter_mock__WEBPACK_IMPORTED_MODULE_8__["DATA_SOURCE_MAIN"]));
        setTimeout(() => this.colors$.next(Object(_shared_functions_deep_copy_function__WEBPACK_IMPORTED_MODULE_10__["deepCopy"])(_data_shared_filter_mock__WEBPACK_IMPORTED_MODULE_8__["DATA_SOURCE_COLORS"])), 0);
        setTimeout(() => this.brands$.next(Object(_shared_functions_deep_copy_function__WEBPACK_IMPORTED_MODULE_10__["deepCopy"])(_data_shared_filter_mock__WEBPACK_IMPORTED_MODULE_8__["DATA_SOURCE_BRANDS"])), 0);
        setTimeout(() => this.prices$.next(Object(_shared_functions_deep_copy_function__WEBPACK_IMPORTED_MODULE_10__["deepCopy"])(_data_shared_filter_mock__WEBPACK_IMPORTED_MODULE_8__["DATA_SOURCE_PRICES"])), 0);
    }
    close() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.type$.value === _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Main) {
                yield this.modalCtrl.dismiss();
            }
            else {
                this.type$.next(_models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Main);
            }
        });
    }
    selectMenu(type) {
        setTimeout(() => this.type$.next(type), 100);
    }
    clearFilter() {
        // TODO: wtf copy
        const main = this.main$.getValue().map(x => (Object.assign({}, x)));
        const type = this.type$.value;
        switch (type) {
            case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Main:
                main.forEach(x => x.value = null);
                break;
            case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Brand:
                main.find(x => x.type === type).value = null;
                this.close().then();
                break;
            default:
                main.find(x => x.type === type).value = null;
                break;
        }
        this.main$.next(main);
    }
    selectFilter(item, type) {
        const main = this.main$.value;
        let mainValue = main.find(x => x.type === type).value;
        switch (type) {
            case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Brand:
                mainValue = item;
                this.close().then();
                break;
            case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Price:
                mainValue = item;
                break;
            case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Color:
                if (!mainValue) {
                    mainValue = [item];
                }
                else {
                    if (mainValue.includes(item)) {
                        mainValue.splice(main.find(x => x.type === type).value.findIndex(x => x === item), 1);
                    }
                    else {
                        mainValue.push(item);
                    }
                }
                break;
        }
        main.find(x => x.type === type).value = mainValue;
        this.main$.next(main);
    }
    isActiveFilter(id, type) {
        return this.main$.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(x => { var _a; return (_a = x.find(el => el.type === type)) === null || _a === void 0 ? void 0 : _a.value; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["map"])(x => {
            var _a, _b;
            if (!x) {
                return false;
            }
            switch (type) {
                case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Brand:
                case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Price:
                    return ((_a = x) === null || _a === void 0 ? void 0 : _a.id) === id;
                case _models_shared_filter_model__WEBPACK_IMPORTED_MODULE_7__["SharedFilterTypes"].Color:
                    return !!((_b = x) === null || _b === void 0 ? void 0 : _b.find(c => (c === null || c === void 0 ? void 0 : c.id) === id));
            }
        }));
    }
};
SharedFilterComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
SharedFilterComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-filter',
        template: _raw_loader_shared_filter_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        animations: [
            Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["trigger"])('enterTrigger', [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["transition"])('void => *', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["style"])({ position: 'absolute', opacity: 0, transform: 'translateX(-100%)' }),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["animate"])('150ms', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["style"])({ position: 'absolute', width: '100%', opacity: 1, transform: 'translateX(0%)' }))
                ]),
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["transition"])('* => void', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["style"])({ position: 'absolute', opacity: 1 }),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["animate"])('150ms', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["style"])({ position: 'absolute', opacity: 0, transform: 'translateX(100%)' }))
                ]),
            ])
        ],
        styles: [_shared_filter_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedFilterComponent);



/***/ }),

/***/ "q/Dt":
/*!****************************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-brand-item/shared-filter-brand-item.component.ts ***!
  \****************************************************************************************************************/
/*! exports provided: SharedFilterBrandItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedFilterBrandItemComponent", function() { return SharedFilterBrandItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_shared_filter_brand_item_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./shared-filter-brand-item.component.html */ "0Fvf");
/* harmony import */ var _shared_filter_brand_item_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared-filter-brand-item.component.scss */ "tYQq");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SharedFilterBrandItemComponent = class SharedFilterBrandItemComponent {
    constructor() {
        this.data = null;
    }
    ngOnInit() {
    }
};
SharedFilterBrandItemComponent.ctorParameters = () => [];
SharedFilterBrandItemComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
SharedFilterBrandItemComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-shared-filter-brand-item',
        template: _raw_loader_shared_filter_brand_item_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_shared_filter_brand_item_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SharedFilterBrandItemComponent);



/***/ }),

/***/ "tD9w":
/*!********************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/shared-filter/components/shared-filter-price-item/shared-filter-price-item.component.html ***!
  \********************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container ion-activatable ripple-parent\">\n  <ion-ripple-effect class=\"ion-ripple-color\"></ion-ripple-effect>\n  <div class=\"titles\">\n    <div class=\"titles__main\"> {{ data.label }} </div>\n  </div>\n  <div class=\"checker\" [class.checker__active]=\"isActive\">\n    <div class=\"checker__internal\" [class.checker__internal__active]=\"isActive\"></div>\n  </div>\n</div>\n");

/***/ }),

/***/ "tYQq":
/*!******************************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-brand-item/shared-filter-brand-item.component.scss ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  gap: 1vh;\n  width: inherit;\n  height: inherit;\n  padding: 5.3vw;\n  box-sizing: border-box;\n}\n.container .ion-ripple-color {\n  color: lightgray;\n}\n.container .titles {\n  flex-grow: 1;\n  display: flex;\n  flex-flow: column;\n  justify-content: center;\n  gap: 0.5vh;\n}\n.container .titles__main {\n  font-size: 1.97vh;\n  font-weight: 500;\n  color: #222222;\n}\n.container .icon-wrapper {\n  width: 1.43vh;\n  height: 1.43vh;\n  margin: auto 0;\n  transform: scaleX(-1);\n}\n.container .icon-wrapper .icon {\n  color: #6B7683;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NoYXJlZC1maWx0ZXItYnJhbmQtaXRlbS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7QUFDRjtBQUNFO0VBQ0UsZ0JBQUE7QUFDSjtBQUVFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsVUFBQTtBQUFKO0FBRUk7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUFOO0FBSUU7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtBQUZKO0FBSUk7RUFDRSxjQUFBO0FBRk4iLCJmaWxlIjoic2hhcmVkLWZpbHRlci1icmFuZC1pdGVtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGdhcDogMXZoO1xuICB3aWR0aDogaW5oZXJpdDtcbiAgaGVpZ2h0OiBpbmhlcml0O1xuICBwYWRkaW5nOiA1LjN2dztcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcblxuICAuaW9uLXJpcHBsZS1jb2xvciB7XG4gICAgY29sb3I6IGxpZ2h0Z3JheTtcbiAgfVxuXG4gIC50aXRsZXMge1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZmxvdzogY29sdW1uO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGdhcDogMC41dmg7XG5cbiAgICAmX19tYWluIHtcbiAgICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGNvbG9yOiAjMjIyMjIyO1xuICAgIH1cbiAgfVxuXG4gIC5pY29uLXdyYXBwZXIge1xuICAgIHdpZHRoOiAxLjQzdmg7XG4gICAgaGVpZ2h0OiAxLjQzdmg7XG4gICAgbWFyZ2luOiBhdXRvIDA7XG4gICAgdHJhbnNmb3JtOiBzY2FsZVgoLTEpO1xuXG4gICAgLmljb24ge1xuICAgICAgY29sb3I6ICM2Qjc2ODM7XG4gICAgfVxuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "u0Lq":
/*!******************************************************************************************************************!*\
  !*** ./src/app/popups/shared-filter/components/shared-filter-price-item/shared-filter-price-item.component.scss ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  display: flex;\n  gap: 1vh;\n  width: inherit;\n  height: inherit;\n  padding: 5.3vw;\n  box-sizing: border-box;\n}\n.container .ion-ripple-color {\n  color: lightgray;\n}\n.container .titles {\n  flex-grow: 1;\n  display: flex;\n  flex-flow: column;\n  justify-content: center;\n  gap: 0.5vh;\n}\n.container .titles__main {\n  font-size: 1.97vh;\n  font-weight: 500;\n  color: #222222;\n}\n.container .checker {\n  display: flex;\n  width: 2.43vh;\n  height: 2.43vh;\n  border: solid 0.25vh #2F3441;\n  border-radius: 50%;\n  box-sizing: border-box;\n}\n.container .checker__internal {\n  margin: auto;\n  width: 65%;\n  height: 65%;\n  border-radius: 50%;\n  background: transparent;\n  transition: 0.3s;\n}\n.container .checker__internal__active {\n  background: #2F3441;\n  transition: 0.3s;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NoYXJlZC1maWx0ZXItcHJpY2UtaXRlbS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7QUFDRjtBQUNFO0VBQ0UsZ0JBQUE7QUFDSjtBQUVFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsVUFBQTtBQUFKO0FBRUk7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUFOO0FBSUU7RUFDRSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUFGSjtBQUlJO0VBQ0UsWUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBRk47QUFJTTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7QUFGUiIsImZpbGUiOiJzaGFyZWQtZmlsdGVyLXByaWNlLWl0ZW0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZ2FwOiAxdmg7XG4gIHdpZHRoOiBpbmhlcml0O1xuICBoZWlnaHQ6IGluaGVyaXQ7XG4gIHBhZGRpbmc6IDUuM3Z3O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuXG4gIC5pb24tcmlwcGxlLWNvbG9yIHtcbiAgICBjb2xvcjogbGlnaHRncmF5O1xuICB9XG5cbiAgLnRpdGxlcyB7XG4gICAgZmxleC1ncm93OiAxO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1mbG93OiBjb2x1bW47XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgZ2FwOiAwLjV2aDtcblxuICAgICZfX21haW4ge1xuICAgICAgZm9udC1zaXplOiAxLjk3dmg7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgY29sb3I6ICMyMjIyMjI7XG4gICAgfVxuICB9XG5cbiAgLmNoZWNrZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgd2lkdGg6IDIuNDN2aDtcbiAgICBoZWlnaHQ6IDIuNDN2aDtcbiAgICBib3JkZXI6IHNvbGlkIDAuMjV2aCAjMkYzNDQxO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuXG4gICAgJl9faW50ZXJuYWwge1xuICAgICAgbWFyZ2luOiBhdXRvO1xuICAgICAgd2lkdGg6IDY1JTtcbiAgICAgIGhlaWdodDogNjUlO1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICB0cmFuc2l0aW9uOiAuM3M7XG5cbiAgICAgICZfX2FjdGl2ZSB7XG4gICAgICAgIGJhY2tncm91bmQ6ICMyRjM0NDE7XG4gICAgICAgIHRyYW5zaXRpb246IC4zcztcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "x+bJ":
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/popups/shared-filter/components/shared-filter-search/shared-filter-search.component.html ***!
  \************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container\">\n  <svg-icon [svgStyle]=\"{'position': 'absolute'}\" class=\"icon icon__search\" src=\"assets/icon/svg/search.svg\"></svg-icon>\n  <ion-input\n    #searchInput\n    class=\"input\"\n    placeholder=\"Введите поисковый запрос...\"\n    type=\"search\">\n  </ion-input>\n</div>\n");

/***/ })

}]);
//# sourceMappingURL=pages-page-scan-page-scan-module-es2015.js.map