(function () {
  function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

  function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

  function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["page-tabs-tinder-page-tabs-tinder-module"], {
    /***/
    "A8BH":
    /*!**********************************************************!*\
      !*** ./src/app/@core/services/api/api-tinder.service.ts ***!
      \**********************************************************/

    /*! exports provided: ApiTinderService */

    /***/
    function A8BH(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiTinderService", function () {
        return ApiTinderService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../platform/app-config.service */
      "ophu");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");

      var ApiTinderService = /*#__PURE__*/function () {
        function ApiTinderService(appConfigService, http) {
          _classCallCheck(this, ApiTinderService);

          this.http = http;
          this.restUrl = appConfigService.recognitionUrl;
        }

        _createClass(ApiTinderService, [{
          key: "getNextTinder",
          value: function getNextTinder() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.http.get("".concat(this.restUrl, "/api/Tinder/next")).toPromise();

                    case 2:
                      return _context.abrupt("return", _context.sent);

                    case 3:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return ApiTinderService;
      }();

      ApiTinderService.ctorParameters = function () {
        return [{
          type: _platform_app_config_service__WEBPACK_IMPORTED_MODULE_2__["AppConfigService"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
        }];
      };

      ApiTinderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ApiTinderService);
      /***/
    },

    /***/
    "Ds04":
    /*!************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-tinder/page-tabs-tinder.component.html ***!
      \************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Ds04(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container\">\n  <div class=\"header\">\n    <span>Лукич</span>\n    <span class=\"filter-icon\"><svg-icon src=\"assets/icon/svg/filter-list.svg\"></svg-icon></span>\n  </div>\n  <div class=\"subheader\"> Выбирай лучшее, то что тебе нравится, а LUC найдет для тебя это </div>\n  <div class=\"card-container\">\n<!--    <div class=\"card\" #tinderCard><app-page-tabs-tinder-card [imgSrc]=\"currentImg$ | async\"></app-page-tabs-tinder-card></div>-->\n<!--    <div class=\"card card__pseudo\"> <div class=\"shadow\"></div> <img alt=\"\" [src]=\"nextImg$ | async\" /> </div>-->\n    <ion-slides (ionSlideDidChange)=\"slideDetectChange()\" style=\"width: 100%; height: 100%\" #ionSlides>\n      <ion-slide *ngFor=\"let card of cards$ | async\">\n        <app-page-tabs-tinder-card class=\"card\" [data]=\"card\"></app-page-tabs-tinder-card>\n      </ion-slide>\n    </ion-slides>\n  </div>\n</div>\n";
      /***/
    },

    /***/
    "KNm0":
    /*!*****************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-tinder/page-tabs-tinder.module.ts ***!
      \*****************************************************************************/

    /*! exports provided: PageTabsTinderModule */

    /***/
    function KNm0(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsTinderModule", function () {
        return PageTabsTinderModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _page_tabs_tinder_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./page-tabs-tinder.component */
      "qiOo");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _components_page_tabs_tinder_card_page_tabs_tinder_card_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./components/page-tabs-tinder-card/page-tabs-tinder-card.component */
      "sRNJ");
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../../@shared/shared.module */
      "pk6O");
      /* harmony import */


      var _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../page-product/page-product.module */
      "A6qN");

      var PageTabsTinderModule = function PageTabsTinderModule() {
        _classCallCheck(this, PageTabsTinderModule);
      };

      PageTabsTinderModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_page_tabs_tinder_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsTinderComponent"], _components_page_tabs_tinder_card_page_tabs_tinder_card_component__WEBPACK_IMPORTED_MODULE_5__["PageTabsTinderCardComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
          path: '',
          component: _page_tabs_tinder_component__WEBPACK_IMPORTED_MODULE_3__["PageTabsTinderComponent"]
        }]), _shared_shared_module__WEBPACK_IMPORTED_MODULE_6__["SharedModule"], _page_product_page_product_module__WEBPACK_IMPORTED_MODULE_7__["PageProductModule"]]
      })], PageTabsTinderModule);
      /***/
    },

    /***/
    "Qoyy":
    /*!**********************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-tinder/page-tabs-tinder.component.scss ***!
      \**********************************************************************************/

    /*! exports provided: default */

    /***/
    function Qoyy(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  display: flex;\n  flex-flow: column;\n  width: 100%;\n  height: 100%;\n  gap: 1.97vh;\n  padding: 0 4.27vw;\n  box-sizing: border-box;\n  overflow: hidden;\n  background: white;\n}\n.container .header {\n  font-size: 2.71vh;\n  font-weight: 700;\n  color: #222222;\n  margin-top: 2.46vh;\n}\n.container .header .filter-icon {\n  float: right;\n  width: 5vw;\n  color: #546173;\n}\n.container .subheader {\n  margin-bottom: 3.5vh;\n  font-size: 1.9vh;\n  font-weight: 400;\n  color: #222222;\n}\n.container .card-container {\n  position: relative;\n  width: 100%;\n  flex-grow: 1;\n  margin-bottom: 2vh;\n}\n.container .card-container .card {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n  border-radius: 1.97vh;\n  z-index: 1;\n}\n.container .card-container .card__pseudo {\n  position: absolute;\n  background: #EAEDF5;\n  z-index: 0;\n}\n.container .card-container .card__pseudo img {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.container .card-container .card__pseudo .shadow {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  z-index: 1;\n  box-shadow: inset 0px -5px 20px -5px rgba(0, 0, 0, 0.4);\n  background: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy10aW5kZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUNGO0FBQ0U7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQ0o7QUFDSTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQUNOO0FBR0U7RUFDRSxvQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBREo7QUFJRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUZKO0FBSUk7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLFVBQUE7QUFGTjtBQUlNO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7QUFGUjtBQUlRO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBRlY7QUFLUTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsdURBQUE7RUFDQSxnQkFBQTtBQUhWIiwiZmlsZSI6InBhZ2UtdGFicy10aW5kZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1mbG93OiBjb2x1bW47XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGdhcDogMS45N3ZoO1xuICBwYWRkaW5nOiAwIDQuMjd2dztcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG5cbiAgLmhlYWRlciB7XG4gICAgZm9udC1zaXplOiAyLjcxdmg7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgICBtYXJnaW4tdG9wOiAyLjQ2dmg7XG5cbiAgICAuZmlsdGVyLWljb24ge1xuICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgd2lkdGg6IDV2dztcbiAgICAgIGNvbG9yOiAjNTQ2MTczO1xuICAgIH1cbiAgfVxuXG4gIC5zdWJoZWFkZXIge1xuICAgIG1hcmdpbi1ib3R0b206IDMuNXZoO1xuICAgIGZvbnQtc2l6ZTogMS45dmg7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBjb2xvcjogIzIyMjIyMjtcbiAgfVxuXG4gIC5jYXJkLWNvbnRhaW5lciB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBtYXJnaW4tYm90dG9tOiAydmg7XG5cbiAgICAuY2FyZCB7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB3aWR0aDogMTAwJTtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICBib3JkZXItcmFkaXVzOiAxLjk3dmg7XG4gICAgICB6LWluZGV4OiAxO1xuXG4gICAgICAmX19wc2V1ZG8ge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGJhY2tncm91bmQ6ICNFQUVERjU7XG4gICAgICAgIHotaW5kZXg6IDA7XG5cbiAgICAgICAgaW1nIHtcbiAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgICAgIH1cblxuICAgICAgICAuc2hhZG93IHtcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICAgIHotaW5kZXg6IDE7XG4gICAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMHB4IC01cHggMjBweCAtNXB4IHJnYmEoMCwgMCwgMCwgLjQpO1xuICAgICAgICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "ljS3":
    /*!************************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-tinder/components/page-tabs-tinder-card/page-tabs-tinder-card.component.scss ***!
      \************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function ljS3(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container {\n  display: flex;\n  flex-flow: column;\n  justify-content: space-between;\n  position: relative;\n  width: 100%;\n  height: 100%;\n  background: #EAEDF5;\n}\n.container .shadow {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  z-index: 1;\n  box-shadow: inset 0px -5px 20px -5px rgba(0, 0, 0, 0.4);\n  pointer-events: none;\n}\n.container img {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.container .rights {\n  position: relative;\n  display: flex;\n  width: 6.4vw;\n  height: 6.4vw;\n  margin: 3.7vw 3.7vw 3.7vw auto;\n  border-radius: 50%;\n  background: rgba(49, 55, 65, 0.5);\n  z-index: 1;\n  color: #FFFFFF;\n  font-size: 1.97vh;\n  transition: 0.3s;\n}\n.container .rights span {\n  margin: auto;\n}\n.container .rights .info {\n  position: absolute;\n  padding: 1.23vh;\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n  right: 0;\n  top: 3.5vh;\n  background: #313741;\n  border-radius: 0.64vh;\n  pointer-events: none;\n  opacity: 0;\n  transition: 0.3s;\n}\n.container .rights__active {\n  background: #313741;\n  transition: 0.3s;\n}\n.container .rights__active .info {\n  opacity: 1;\n  transition: 0.3s;\n}\n.container .interface {\n  display: flex;\n  justify-content: space-between;\n  width: 100%;\n  padding: 0 6.9vw;\n  margin-bottom: 2.46vh;\n  z-index: 1;\n}\n.container .shop {\n  width: 11.7vw;\n  height: 11.7vw;\n  margin: auto 0;\n  padding: 3vw;\n  border-radius: 50%;\n  background: #2CB172;\n  color: #FFFFFF;\n}\n.container .button {\n  width: 16vw;\n  height: 16vw;\n  padding: 5.3vw;\n  border-radius: 50%;\n  background: rgba(49, 55, 65, 0.5);\n}\n.container .button svg-icon {\n  color: #DDDFE3;\n}\n.container .button__favorite svg-icon {\n  color: #FF3B30;\n}\n.container ion-spinner {\n  margin: auto;\n  --color: #2CB172;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3BhZ2UtdGFicy10aW5kZXItY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBQ0Y7QUFDRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsdURBQUE7RUFDQSxvQkFBQTtBQUNKO0FBRUU7RUFDRSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBQUo7QUFHRTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBREo7QUFHSTtFQUNFLFlBQUE7QUFETjtBQUlJO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0EsMEJBQUE7RUFBQSx1QkFBQTtFQUFBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUFGTjtBQUtJO0VBQ0UsbUJBQUE7RUFDQSxnQkFBQTtBQUhOO0FBS007RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7QUFIUjtBQVFFO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxVQUFBO0FBTko7QUFTRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQVBKO0FBVUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGlDQUFBO0FBUko7QUFVSTtFQUNFLGNBQUE7QUFSTjtBQVlNO0VBQ0UsY0FBQTtBQVZSO0FBZ0JFO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0FBZEoiLCJmaWxlIjoicGFnZS10YWJzLXRpbmRlci1jYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZmxvdzogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZDogI0VBRURGNTtcblxuICAuc2hhZG93IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHotaW5kZXg6IDE7XG4gICAgYm94LXNoYWRvdzogaW5zZXQgMHB4IC01cHggMjBweCAtNXB4IHJnYmEoMCwgMCwgMCwgLjQpO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICB9XG5cbiAgaW1nIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICB0b3A6IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICB9XG5cbiAgLnJpZ2h0cyB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgd2lkdGg6IDYuNHZ3O1xuICAgIGhlaWdodDogNi40dnc7XG4gICAgbWFyZ2luOiAzLjd2dyAzLjd2dyAzLjd2dyBhdXRvO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKCMzMTM3NDEsIC41KTtcbiAgICB6LWluZGV4OiAxO1xuICAgIGNvbG9yOiAjRkZGRkZGO1xuICAgIGZvbnQtc2l6ZTogMS45N3ZoO1xuICAgIHRyYW5zaXRpb246IC4zcztcblxuICAgIHNwYW4ge1xuICAgICAgbWFyZ2luOiBhdXRvO1xuICAgIH1cblxuICAgIC5pbmZvIHtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHBhZGRpbmc6IDEuMjN2aDtcbiAgICAgIHdpZHRoOiBtYXgtY29udGVudDtcbiAgICAgIHJpZ2h0OiAwO1xuICAgICAgdG9wOiAzLjV2aDtcbiAgICAgIGJhY2tncm91bmQ6ICMzMTM3NDE7XG4gICAgICBib3JkZXItcmFkaXVzOiAuNjR2aDtcbiAgICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgICAgb3BhY2l0eTogMDtcbiAgICAgIHRyYW5zaXRpb246IC4zcztcbiAgICB9XG5cbiAgICAmX19hY3RpdmUge1xuICAgICAgYmFja2dyb3VuZDogIzMxMzc0MTtcbiAgICAgIHRyYW5zaXRpb246IC4zcztcblxuICAgICAgLmluZm8ge1xuICAgICAgICBvcGFjaXR5OiAxO1xuICAgICAgICB0cmFuc2l0aW9uOiAuM3M7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLmludGVyZmFjZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZzogMCA2Ljl2dztcbiAgICBtYXJnaW4tYm90dG9tOiAyLjQ2dmg7XG4gICAgei1pbmRleDogMTtcbiAgfVxuXG4gIC5zaG9wIHtcbiAgICB3aWR0aDogMTEuN3Z3O1xuICAgIGhlaWdodDogMTEuN3Z3O1xuICAgIG1hcmdpbjogYXV0byAwO1xuICAgIHBhZGRpbmc6IDN2dztcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgYmFja2dyb3VuZDogIzJDQjE3MjtcbiAgICBjb2xvcjogI0ZGRkZGRjtcbiAgfVxuXG4gIC5idXR0b24ge1xuICAgIHdpZHRoOiAxNnZ3O1xuICAgIGhlaWdodDogMTZ2dztcbiAgICBwYWRkaW5nOiA1LjN2dztcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgYmFja2dyb3VuZDogcmdiYSg0OSw1NSw2NSwuNSk7XG5cbiAgICBzdmctaWNvbiB7XG4gICAgICBjb2xvcjogI0REREZFMztcbiAgICB9XG5cbiAgICAmX19mYXZvcml0ZSB7XG4gICAgICBzdmctaWNvbiB7XG4gICAgICAgIGNvbG9yOiAjRkYzQjMwO1xuICAgICAgfVxuICAgIH1cblxuICB9XG5cbiAgaW9uLXNwaW5uZXIge1xuICAgIG1hcmdpbjogYXV0bztcbiAgICAtLWNvbG9yOiAjMkNCMTcyO1xuICB9XG59XG4iXX0= */";
      /***/
    },

    /***/
    "qiOo":
    /*!********************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-tinder/page-tabs-tinder.component.ts ***!
      \********************************************************************************/

    /*! exports provided: PageTabsTinderComponent */

    /***/
    function qiOo(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsTinderComponent", function () {
        return PageTabsTinderComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_tinder_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-tinder.component.html */
      "Ds04");
      /* harmony import */


      var _page_tabs_tinder_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-tinder.component.scss */
      "Qoyy");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _core_services_api_api_tinder_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../../@core/services/api/api-tinder.service */
      "A8BH");

      var PageTabsTinderComponent = /*#__PURE__*/function () {
        function PageTabsTinderComponent(apiTinderService, gestureCtrl, platform) {
          var _this = this;

          _classCallCheck(this, PageTabsTinderComponent);

          this.apiTinderService = apiTinderService;
          this.gestureCtrl = gestureCtrl;
          this.platform = platform;
          this.tabName = 'blocks';
          this.cards$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["BehaviorSubject"]([function () {
            return _this.getNextImage();
          }, function () {
            return _this.getNextImage();
          }, function () {
            return _this.getNextImage();
          }]);

          this.action = function (actionType) {
            console.log('tinder-action', actionType);
          };
        }

        _createClass(PageTabsTinderComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ngAfterViewInit",
          value: function ngAfterViewInit() {
            this.useTinderSwipe(this.tinderCard, this.platform.width());
          }
        }, {
          key: "useTinderSwipe",
          value: function useTinderSwipe(card, screenWidth) {
            var _this2 = this;

            if (!(card === null || card === void 0 ? void 0 : card.nativeElement)) {
              return;
            }

            var gesture = this.gestureCtrl.create({
              el: card.nativeElement,
              gestureName: 'tinder-swipe',
              onStart: function onStart(e) {
                card.nativeElement.style.transition = "none";
              },
              onMove: function onMove(e) {
                card.nativeElement.style.transform = "translateX(".concat(e.deltaX, "px)"); // card.nativeElement.style.transform = `translateX(${e.deltaX}px) rotate(${e.deltaX / 8}deg)`;
              },
              onEnd: function onEnd(e) {
                var transform = "translateX(0px) rotate(0deg)";

                if (e.deltaX > screenWidth / 2) {
                  transform = "translateX(".concat(+screenWidth * 2, "px)"); // transform = `translateX(${+screenWidth * 2}px) rotate(${e.deltaX / 2}deg)`;

                  _this2.action('like');
                } else if (e.deltaX < -screenWidth / 2) {
                  transform = "translateX(".concat(-screenWidth * 2, "px)"); // transform = `translateX(${-screenWidth * 2}px) rotate(${e.deltaX / 2}deg)`;

                  _this2.action('dislike');
                }

                card.nativeElement.style.transition = ".5s ease-out";
                card.nativeElement.style.transform = transform;
              }
            });
            gesture.enable(true);
          }
        }, {
          key: "slideDetectChange",
          value: function slideDetectChange() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this3 = this;

              var cards, currentIdx;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      cards = this.cards$.getValue();
                      _context2.next = 3;
                      return this.ionSlide.getActiveIndex();

                    case 3:
                      currentIdx = _context2.sent;

                      if (cards.length - (currentIdx + 1) < 1) {
                        this.cards$.next([].concat(_toConsumableArray(cards), [function () {
                          return _this3.getNextImage();
                        }]));
                      }

                    case 5:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "getNextImage",
          value: function getNextImage() {
            return this.apiTinderService.getNextTinder();
          }
        }]);

        return PageTabsTinderComponent;
      }();

      PageTabsTinderComponent.ctorParameters = function () {
        return [{
          type: _core_services_api_api_tinder_service__WEBPACK_IMPORTED_MODULE_6__["ApiTinderService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["GestureController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
        }];
      };

      PageTabsTinderComponent.propDecorators = {
        tinderCard: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"],
          args: ['tinderCard']
        }],
        ionSlide: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"],
          args: ['ionSlides']
        }]
      };
      PageTabsTinderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-tinder',
        template: _raw_loader_page_tabs_tinder_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_tinder_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsTinderComponent);
      /***/
    },

    /***/
    "sRNJ":
    /*!**********************************************************************************************************************!*\
      !*** ./src/app/pages/page-tabs/page-tabs-tinder/components/page-tabs-tinder-card/page-tabs-tinder-card.component.ts ***!
      \**********************************************************************************************************************/

    /*! exports provided: PageTabsTinderCardComponent */

    /***/
    function sRNJ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PageTabsTinderCardComponent", function () {
        return PageTabsTinderCardComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_page_tabs_tinder_card_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./page-tabs-tinder-card.component.html */
      "z8zC");
      /* harmony import */


      var _page_tabs_tinder_card_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./page-tabs-tinder-card.component.scss */
      "ljS3");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../../../../@shared/functions/base64-file.function */
      "JJls");
      /* harmony import */


      var _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../../../../@core/services/loading.service */
      "IpGr");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../../../../@core/services/api/api-recognition.service */
      "p0lb");
      /* harmony import */


      var _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../../../../@core/services/recognition-info.service */
      "7mVc");
      /* harmony import */


      var _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ../../../../page-product/page-product.component */
      "8jGz");
      /* harmony import */


      var _shared_classes_favorites_class__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ../../../../../@shared/classes/favorites.class */
      "mVaD");
      /* harmony import */


      var _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! ../../../../../@core/services/api/api-user.service */
      "lA1K");
      /* harmony import */


      var _core_services_api_api_file_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ../../../../../@core/services/api/api-file.service */
      "0SLh");

      var PageTabsTinderCardComponent = /*#__PURE__*/function () {
        function PageTabsTinderCardComponent(navCtrl, loadingService, apiRecognitionService, modalController, recognitionInfoService, apiUserService, apiFileService) {
          _classCallCheck(this, PageTabsTinderCardComponent);

          this.navCtrl = navCtrl;
          this.loadingService = loadingService;
          this.apiRecognitionService = apiRecognitionService;
          this.modalController = modalController;
          this.recognitionInfoService = recognitionInfoService;
          this.apiUserService = apiUserService;
          this.apiFileService = apiFileService;
          this.data$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](null);
          this.isFavorite$ = this.data$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["map"])(function (x) {
            var _a;

            return (_a = x === null || x === void 0 ? void 0 : x.feedPreview) === null || _a === void 0 ? void 0 : _a.isFavorite;
          }));
          this.shopUrl$ = this.data$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["filter"])(function (x) {
            return x.type === 'feed';
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["map"])(function (x) {
            return x.feedId;
          }));
          this.isInfo$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](false);
          this.nextRouteUrl = '/main/camera';
          this.favoritesController = new _shared_classes_favorites_class__WEBPACK_IMPORTED_MODULE_12__["FavoritesController"](apiUserService);
        }

        _createClass(PageTabsTinderCardComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "toggleInfo",
          value: function toggleInfo() {
            this.isInfo$.next(!this.isInfo$.value);
          }
        }, {
          key: "search",
          value: function search() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var img;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      if (this.data$.getValue()) {
                        _context3.next = 2;
                        break;
                      }

                      return _context3.abrupt("return");

                    case 2:
                      _context3.next = 4;
                      return this.loadingService.startLoading();

                    case 4:
                      _context3.next = 6;
                      return Object(_shared_functions_base64_file_function__WEBPACK_IMPORTED_MODULE_6__["urlToDataUrl"])(this.data$.value.imageUrl);

                    case 6:
                      img = _context3.sent;
                      _context3.next = 9;
                      return this.loadingService.stopLoading();

                    case 9:
                      _context3.next = 11;
                      return this.navCtrl.navigateForward(this.nextRouteUrl, {
                        queryParams: {
                          img: img
                        }
                      });

                    case 11:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "openProduct",
          value: function openProduct() {
            var _a;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var _this4 = this;

              var productId;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      productId = (_a = this.data$.getValue()) === null || _a === void 0 ? void 0 : _a.feedId;

                      if (productId) {
                        _context4.next = 3;
                        break;
                      }

                      return _context4.abrupt("return");

                    case 3:
                      this.recognitionInfoService.recognitionFeedFunction = function () {
                        return _this4.apiRecognitionService.getFullItem(productId);
                      };

                      _context4.next = 6;
                      return this.presentModalInfo();

                    case 6:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "setFavorite",
          value: function setFavorite() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var data;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      data = this.data$.getValue();

                      if (data.feedPreview) {
                        _context5.next = 3;
                        break;
                      }

                      return _context5.abrupt("return");

                    case 3:
                      _context5.next = 5;
                      return this.favoritesController.setFavourite(data.feedId, !data.feedPreview.isFavorite);

                    case 5:
                      data.feedPreview.isFavorite = _context5.sent;
                      this.data$.next(Object.assign({}, data));

                    case 7:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "disableInfo",
          value: function disableInfo() {
            this.isInfo$.next(false);
          }
        }, {
          key: "presentModalInfo",
          value: function presentModalInfo() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var modal;
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      _context6.next = 2;
                      return this.modalController.create({
                        component: _page_product_page_product_component__WEBPACK_IMPORTED_MODULE_11__["PageProductComponent"]
                      });

                    case 2:
                      modal = _context6.sent;
                      _context6.next = 5;
                      return modal.present();

                    case 5:
                      return _context6.abrupt("return", _context6.sent);

                    case 6:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "data",
          set: function set(method) {
            var _this5 = this;

            this.disableInfo();
            method().then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this5, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
                return regeneratorRuntime.wrap(function _callee7$(_context7) {
                  while (1) {
                    switch (_context7.prev = _context7.next) {
                      case 0:
                        if (res) {
                          _context7.next = 2;
                          break;
                        }

                        return _context7.abrupt("return");

                      case 2:
                        res.imageUrl = res.type !== 'tinderItem' ? res.imageUrl : this.apiFileService.getTinderPhotoById(res.tinderId);

                        if (!(res.type === 'feed')) {
                          _context7.next = 7;
                          break;
                        }

                        _context7.next = 6;
                        return this.apiRecognitionService.getFullItem(res.feedId);

                      case 6:
                        res.feedPreview = _context7.sent;

                      case 7:
                        this.data$.next(res);

                      case 8:
                      case "end":
                        return _context7.stop();
                    }
                  }
                }, _callee7, this);
              }));
            });
          }
        }]);

        return PageTabsTinderCardComponent;
      }();

      PageTabsTinderCardComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
        }, {
          type: _core_services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"]
        }, {
          type: _core_services_api_api_recognition_service__WEBPACK_IMPORTED_MODULE_9__["ApiRecognitionService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }, {
          type: _core_services_recognition_info_service__WEBPACK_IMPORTED_MODULE_10__["RecognitionInfoService"]
        }, {
          type: _core_services_api_api_user_service__WEBPACK_IMPORTED_MODULE_13__["ApiUserService"]
        }, {
          type: _core_services_api_api_file_service__WEBPACK_IMPORTED_MODULE_14__["ApiFileService"]
        }];
      };

      PageTabsTinderCardComponent.propDecorators = {
        data: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      PageTabsTinderCardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-page-tabs-tinder-card',
        template: _raw_loader_page_tabs_tinder_card_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectionStrategy"].OnPush,
        styles: [_page_tabs_tinder_card_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PageTabsTinderCardComponent);
      /***/
    },

    /***/
    "z8zC":
    /*!**************************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/page-tabs/page-tabs-tinder/components/page-tabs-tinder-card/page-tabs-tinder-card.component.html ***!
      \**************************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function z8zC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container\">\n  <div class=\"shadow\"></div>\n  <ng-container *ngIf=\"!!(data$ | async); else loader\">\n    <img alt=\"\" [src]=\"(data$ | async).imageUrl\"/>\n    <div\n      [ngStyle]=\"{visibility: !(shopUrl$ | async) ? 'visible' : 'hidden'}\"\n      (click)=\"toggleInfo()\"\n      class=\"rights\"\n      [class.rights__active]=\"isInfo$ | async\"\n    >\n      <span> © </span>\n      <div class=\"info\"> Источник: pinterest.ru </div>\n    </div>\n    <div class=\"interface\">\n      <div\n        [ngStyle]=\"{visibility: !!(shopUrl$ | async) ? 'visible' : 'hidden'}\"\n        class=\"button\" [class.button__favorite]=\"isFavorite$ | async\"\n        (click)=\"setFavorite()\"\n      >\n        <svg-icon src=\"assets/icon/svg/favorite.svg\"></svg-icon>\n      </div>\n      <div *ngIf=\"!!(shopUrl$ | async)\" (click)=\"openProduct()\" class=\"shop\">\n        <svg-icon src=\"assets/icon/svg/shopping-cart.svg\"></svg-icon>\n      </div>\n      <div (click)=\"search()\" class=\"button\">\n        <svg-icon src=\"assets/icon/svg/search.svg\"></svg-icon>\n      </div>\n    </div>\n  </ng-container>\n  <ng-template #loader>\n    <ion-spinner name=\"dots\"></ion-spinner>\n  </ng-template>\n</div>\n";
      /***/
    }
  }]);
})();
//# sourceMappingURL=page-tabs-tinder-page-tabs-tinder-module-es5.js.map